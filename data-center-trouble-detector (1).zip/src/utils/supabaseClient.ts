import { createClient } from '@supabase/supabase-js';
import { ActivityLog, DetectedTrouble, UploadDataset, User } from '../types';

export const SUPABASE_PROJECT_ID = 'ctyxrwzmugfgvjxqwpzv';
export const SUPABASE_URL =
  (import.meta.env.VITE_SUPABASE_URL as string) || `https://${SUPABASE_PROJECT_ID}.supabase.co`;
export const SUPABASE_ANON_KEY =
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string) ||
  'sb_publishable_WnAQ8t0QQ-3C1umS_hOR8g_CK1hNK-P';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export interface SupabaseHealth {
  connected: boolean;
  status: 'connected' | 'checking' | 'tables_missing' | 'error';
  latencyMs: number;
  message: string;
  projectId: string;
  url: string;
  tablesFound?: string[];
}

/**
 * Checks connection status to Supabase backend
 */
export async function testSupabaseConnection(): Promise<SupabaseHealth> {
  const start = performance.now();
  try {
    // Attempt ping to Supabase auth/REST endpoint
    const res = await fetch(`${SUPABASE_URL}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      },
    });

    const latencyMs = Math.round(performance.now() - start);

    if (res.ok || res.status === 200 || res.status === 404) {
      // Test if application tables exist
      const { data: usersData, error: usersErr } = await supabase
        .from('dc_users')
        .select('id')
        .limit(1);

      if (usersErr && usersErr.code === '42P01') {
        // Table does not exist in Supabase yet
        return {
          connected: true,
          status: 'tables_missing',
          latencyMs,
          message: 'Connected to Supabase! Tables need to be initialized in SQL Editor.',
          projectId: SUPABASE_PROJECT_ID,
          url: SUPABASE_URL,
        };
      }

      return {
        connected: true,
        status: 'connected',
        latencyMs,
        message: 'Successfully linked and authenticated with Supabase backend.',
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
      };
    } else {
      return {
        connected: false,
        status: 'error',
        latencyMs,
        message: `HTTP ${res.status}: Failed to reach Supabase API. Check credentials.`,
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
      };
    }
  } catch (err: any) {
    const latencyMs = Math.round(performance.now() - start);
    return {
      connected: false,
      status: 'error',
      latencyMs,
      message: err?.message || 'Could not connect to Supabase.',
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
    };
  }
}

// -------------------------------------------------------------
// Supabase Data Access Functions
// -------------------------------------------------------------

export async function supabaseUpsertUser(user: User): Promise<boolean> {
  try {
    const { error } = await supabase.from('dc_users').upsert(
      {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        organization: user.organization || null,
        status: user.status,
        created_at: user.createdAt,
        last_login_at: user.lastLoginAt,
      },
      { onConflict: 'email' }
    );
    if (error) {
      console.warn('[Supabase] upsert user error:', error.message);
      return false;
    }
    return true;
  } catch (e) {
    console.warn('[Supabase] upsert user exception:', e);
    return false;
  }
}

export async function supabaseFetchUsers(): Promise<User[] | null> {
  try {
    const { data, error } = await supabase
      .from('dc_users')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data) return null;

    return data.map((d: any) => ({
      id: d.id,
      email: d.email,
      name: d.name,
      role: d.role,
      organization: d.organization,
      status: d.status,
      createdAt: d.created_at,
      lastLoginAt: d.last_login_at,
    }));
  } catch {
    return null;
  }
}

export async function supabaseInsertActivity(activity: ActivityLog): Promise<boolean> {
  try {
    const { error } = await supabase.from('dc_activity_logs').insert({
      id: activity.id,
      timestamp: activity.timestamp,
      user_id: activity.userId,
      user_email: activity.userEmail,
      user_name: activity.userName,
      user_role: activity.userRole,
      action_type: activity.actionType,
      details: activity.details,
      severity: activity.severity,
      facility_id: activity.facilityId || null,
      metadata: activity.metadata || null,
    });
    if (error) {
      console.warn('[Supabase] insert activity error:', error.message);
      return false;
    }
    return true;
  } catch (e) {
    console.warn('[Supabase] insert activity exception:', e);
    return false;
  }
}

export async function supabaseFetchActivities(): Promise<ActivityLog[] | null> {
  try {
    const { data, error } = await supabase
      .from('dc_activity_logs')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(200);

    if (error || !data) return null;

    return data.map((d: any) => ({
      id: d.id,
      timestamp: d.timestamp,
      userId: d.user_id,
      userEmail: d.user_email,
      userName: d.user_name,
      userRole: d.user_role,
      actionType: d.action_type,
      details: d.details,
      severity: d.severity,
      facilityId: d.facility_id,
      metadata: d.metadata,
    }));
  } catch {
    return null;
  }
}

export async function supabaseInsertDataset(dataset: UploadDataset): Promise<boolean> {
  try {
    const { error } = await supabase.from('dc_datasets').upsert({
      id: dataset.id,
      file_name: dataset.fileName,
      uploaded_at: dataset.uploadedAt,
      uploaded_by: dataset.uploadedBy,
      uploaded_by_name: dataset.uploadedByName,
      facility: dataset.facility,
      row_count: dataset.rowCount,
      critical_count: dataset.criticalCount,
      warning_count: dataset.warningCount,
      healthy_count: dataset.healthyCount,
      health_score: dataset.healthScore,
      records: dataset.records,
      troubles: dataset.troubles,
    });
    if (error) {
      console.warn('[Supabase] insert dataset error:', error.message);
      return false;
    }
    return true;
  } catch (e) {
    console.warn('[Supabase] insert dataset exception:', e);
    return false;
  }
}

export async function supabaseFetchDatasets(): Promise<UploadDataset[] | null> {
  try {
    const { data, error } = await supabase
      .from('dc_datasets')
      .select('*')
      .order('uploaded_at', { ascending: false });

    if (error || !data) return null;

    return data.map((d: any) => ({
      id: d.id,
      fileName: d.file_name,
      uploadedAt: d.uploaded_at,
      uploadedBy: d.uploaded_by,
      uploadedByName: d.uploaded_by_name,
      facility: d.facility,
      rowCount: d.row_count,
      criticalCount: d.critical_count,
      warningCount: d.warning_count,
      healthyCount: d.healthy_count,
      healthScore: d.health_score,
      records: d.records,
      troubles: d.troubles,
    }));
  } catch {
    return null;
  }
}

export async function supabaseUpdateTrouble(
  datasetId: string,
  troubleId: string,
  status: string,
  notes: string,
  resolvedBy?: string
): Promise<boolean> {
  try {
    // Fetch dataset, update nested troubles array, then save back
    const { data, error } = await supabase
      .from('dc_datasets')
      .select('troubles')
      .eq('id', datasetId)
      .single();

    if (error || !data || !data.troubles) return false;

    const updatedTroubles = data.troubles.map((t: DetectedTrouble) => {
      if (t.id === troubleId) {
        return {
          ...t,
          status,
          resolutionNotes: notes,
          resolvedAt: status === 'resolved' ? new Date().toISOString() : t.resolvedAt,
          resolvedBy: status === 'resolved' ? resolvedBy : t.resolvedBy,
        };
      }
      return t;
    });

    const { error: updateErr } = await supabase
      .from('dc_datasets')
      .update({ troubles: updatedTroubles })
      .eq('id', datasetId);

    return !updateErr;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// SQL Migration Script for Supabase SQL Editor
// -------------------------------------------------------------
export const SUPABASE_SQL_SCHEMA = `-- ============================================================
-- DATA CENTER TROUBLE DETECTOR - SUPABASE SCHEMA SETUP
-- Project ID: ctyxrwzmugfgvjxqwpzv
-- Paste and run this script in the Supabase SQL Editor:
-- https://supabase.com/dashboard/project/ctyxrwzmugfgvjxqwpzv/sql
-- ============================================================

-- 1. Users Table
CREATE TABLE IF NOT EXISTS public.dc_users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'customer',
    organization TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_login_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Activity Logs Table (Admin Auditing)
CREATE TABLE IF NOT EXISTS public.dc_activity_logs (
    id TEXT PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    user_id TEXT NOT NULL,
    user_email TEXT NOT NULL,
    user_name TEXT NOT NULL,
    user_role TEXT NOT NULL,
    action_type TEXT NOT NULL,
    details TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info',
    facility_id TEXT,
    metadata JSONB
);

-- 3. Telemetry Datasets & Analyzed Troubles Table
CREATE TABLE IF NOT EXISTS public.dc_datasets (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    uploaded_at TIMESTAMPTZ DEFAULT NOW(),
    uploaded_by TEXT NOT NULL,
    uploaded_by_name TEXT NOT NULL,
    facility TEXT NOT NULL,
    row_count INTEGER NOT NULL DEFAULT 0,
    critical_count INTEGER NOT NULL DEFAULT 0,
    warning_count INTEGER NOT NULL DEFAULT 0,
    healthy_count INTEGER NOT NULL DEFAULT 0,
    health_score INTEGER NOT NULL DEFAULT 100,
    records JSONB NOT NULL DEFAULT '[]'::jsonb,
    troubles JSONB NOT NULL DEFAULT '[]'::jsonb
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.dc_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dc_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dc_datasets ENABLE ROW LEVEL SECURITY;

-- Allow public / anon read and write for this application
CREATE POLICY "Public Read dc_users" ON public.dc_users FOR SELECT USING (true);
CREATE POLICY "Public Insert dc_users" ON public.dc_users FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Update dc_users" ON public.dc_users FOR UPDATE USING (true);

CREATE POLICY "Public Read dc_activity_logs" ON public.dc_activity_logs FOR SELECT USING (true);
CREATE POLICY "Public Insert dc_activity_logs" ON public.dc_activity_logs FOR INSERT WITH CHECK (true);

CREATE POLICY "Public Read dc_datasets" ON public.dc_datasets FOR SELECT USING (true);
CREATE POLICY "Public Insert dc_datasets" ON public.dc_datasets FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Update dc_datasets" ON public.dc_datasets FOR UPDATE USING (true);
CREATE POLICY "Public Delete dc_datasets" ON public.dc_datasets FOR DELETE USING (true);

-- Seed Administrator User
INSERT INTO public.dc_users (id, email, name, role, organization, status, created_at)
VALUES (
    'usr-admin-bharathesh',
    'bharathesh.admin@datacenter.gov',
    'Bharathesh Gowda M R',
    'admin',
    'Global Command Center',
    'active',
    NOW()
)
ON CONFLICT (email) DO NOTHING;
`;
