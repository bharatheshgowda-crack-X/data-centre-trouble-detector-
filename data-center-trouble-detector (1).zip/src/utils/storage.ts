import { ActivityLog, DetectedTrouble, UploadDataset, User, UserRole } from '../types';
import { SAMPLE_DATASETS, parseCSV } from './csvParser';
import { analyzeTelemetryRecords } from './detectionEngine';
import {
  supabaseFetchActivities,
  supabaseFetchDatasets,
  supabaseFetchUsers,
  supabaseInsertActivity,
  supabaseInsertDataset,
  supabaseUpdateTrouble,
  supabaseUpsertUser,
} from './supabaseClient';

const STORAGE_KEYS = {
  USERS: 'dc_trouble_detector_users',
  CURRENT_USER: 'dc_trouble_detector_session',
  ACTIVITIES: 'dc_trouble_detector_activities',
  DATASETS: 'dc_trouble_detector_datasets',
  TROUBLE_OVERRIDES: 'dc_trouble_detector_troubles_status',
};

// Fixed admin credentials as requested in prompt
export const ADMIN_CREDENTIALS = {
  username: 'Bharathesh Gowda M R',
  password: 'bharath2008',
  email: 'bharathesh.admin@datacenter.gov',
  name: 'Bharathesh Gowda M R',
};

const DEFAULT_USERS: User[] = [
  {
    id: 'usr-admin-bharathesh',
    email: ADMIN_CREDENTIALS.email,
    name: ADMIN_CREDENTIALS.name,
    role: 'admin',
    createdAt: '2026-01-15T08:00:00Z',
    lastLoginAt: new Date().toISOString(),
    status: 'active',
    organization: 'Global Data Center Command Center',
  },
  {
    id: 'usr-cust-alex',
    email: 'operator@datacenter.net',
    name: 'Alex Mercer',
    role: 'customer',
    createdAt: '2026-05-10T11:20:00Z',
    lastLoginAt: '2026-10-28T08:15:00Z',
    status: 'active',
    organization: 'Apex Colocation Services',
  },
  {
    id: 'usr-cust-elena',
    email: 'facilities@cloudhub.io',
    name: 'Elena Rostova',
    role: 'customer',
    createdAt: '2026-07-22T14:40:00Z',
    lastLoginAt: '2026-10-27T19:30:00Z',
    status: 'active',
    organization: 'CloudHub Modular DCs',
  },
];

function initSeedDatasets(): UploadDataset[] {
  // Pre-seed sample datasets so dashboards are instantly informative
  const initialDatasets: UploadDataset[] = [];

  // Seed 1: Critical Hyperscale for Alex Mercer
  const parsed1 = parseCSV(SAMPLE_DATASETS.CRITICAL_STRESS.csv);
  const det1 = analyzeTelemetryRecords(parsed1.records, 'seed-ds-1', SAMPLE_DATASETS.CRITICAL_STRESS.name);
  initialDatasets.push({
    id: 'seed-ds-1',
    fileName: SAMPLE_DATASETS.CRITICAL_STRESS.name,
    uploadedAt: '2026-10-28T08:20:00Z',
    uploadedBy: 'operator@datacenter.net',
    uploadedByName: 'Alex Mercer',
    facility: SAMPLE_DATASETS.CRITICAL_STRESS.facility,
    rowCount: parsed1.records.length,
    criticalCount: det1.criticalCount,
    warningCount: det1.warningCount,
    healthyCount: det1.healthyCount,
    healthScore: det1.healthScore,
    records: parsed1.records,
    troubles: det1.troubles,
  });

  // Seed 2: Edge Warning for Elena Rostova
  const parsed2 = parseCSV(SAMPLE_DATASETS.WARNING_EDGE.csv);
  const det2 = analyzeTelemetryRecords(parsed2.records, 'seed-ds-2', SAMPLE_DATASETS.WARNING_EDGE.name);
  initialDatasets.push({
    id: 'seed-ds-2',
    fileName: SAMPLE_DATASETS.WARNING_EDGE.name,
    uploadedAt: '2026-10-27T19:35:00Z',
    uploadedBy: 'facilities@cloudhub.io',
    uploadedByName: 'Elena Rostova',
    facility: SAMPLE_DATASETS.WARNING_EDGE.facility,
    rowCount: parsed2.records.length,
    criticalCount: det2.criticalCount,
    warningCount: det2.warningCount,
    healthyCount: det2.healthyCount,
    healthScore: det2.healthScore,
    records: parsed2.records,
    troubles: det2.troubles,
  });

  return initialDatasets;
}

function initSeedActivities(): ActivityLog[] {
  return [
    {
      id: 'act-1',
      timestamp: '2026-10-28T08:00:15Z',
      userId: 'usr-admin-bharathesh',
      userEmail: ADMIN_CREDENTIALS.email,
      userName: ADMIN_CREDENTIALS.name,
      userRole: 'admin',
      actionType: 'LOGIN',
      details: 'Administrator session authenticated via Secure Admin Portal.',
      severity: 'info',
    },
    {
      id: 'act-2',
      timestamp: '2026-10-28T08:15:22Z',
      userId: 'usr-cust-alex',
      userEmail: 'operator@datacenter.net',
      userName: 'Alex Mercer',
      userRole: 'customer',
      actionType: 'LOGIN',
      details: 'Customer authenticated into Facility Portal.',
      severity: 'info',
    },
    {
      id: 'act-3',
      timestamp: '2026-10-28T08:20:00Z',
      userId: 'usr-cust-alex',
      userEmail: 'operator@datacenter.net',
      userName: 'Alex Mercer',
      userRole: 'customer',
      actionType: 'UPLOAD_CSV',
      details: 'Uploaded telemetry CSV: Hyperscale_Facility_West_Critical.csv (8 metric time-slices)',
      severity: 'info',
      facilityId: 'Apex Hyperscale DC-04 (Oregon)',
    },
    {
      id: 'act-4',
      timestamp: '2026-10-28T08:20:05Z',
      userId: 'usr-cust-alex',
      userEmail: 'operator@datacenter.net',
      userName: 'Alex Mercer',
      userRole: 'customer',
      actionType: 'DETECTION_ALERT',
      details: 'Engine identified 14 issues: 8 CRITICAL thresholds breached (PUE 1.94, Temp 36.0°C, WUE 3.10 L/kWh).',
      severity: 'critical',
      facilityId: 'Apex Hyperscale DC-04 (Oregon)',
    },
    {
      id: 'act-5',
      timestamp: '2026-10-28T08:35:10Z',
      userId: 'usr-cust-alex',
      userEmail: 'operator@datacenter.net',
      userName: 'Alex Mercer',
      userRole: 'customer',
      actionType: 'APPLY_SOLUTION',
      details: 'Operator initiated recommended HVAC Setpoint mitigation (+1.5°C supply air & blanking panel inspection).',
      severity: 'success',
      facilityId: 'Apex Hyperscale DC-04 (Oregon)',
    },
  ];
}

// User management helpers
export function getUsers(): User[] {
  const raw = localStorage.getItem(STORAGE_KEYS.USERS);
  if (!raw) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(DEFAULT_USERS));
    return DEFAULT_USERS;
  }
  try {
    return JSON.parse(raw);
  } catch {
    return DEFAULT_USERS;
  }
}

export function saveUsers(users: User[]): void {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  // Async mirror to Supabase
  users.forEach((u) => {
    supabaseUpsertUser(u).catch(() => {});
  });
}

export function getCurrentUser(): User | null {
  const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function setCurrentUser(user: User | null): void {
  if (user) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
}

// Activity Logging
export function getActivityLogs(currentUser?: User | null): ActivityLog[] {
  let list: ActivityLog[] = [];
  const raw = localStorage.getItem(STORAGE_KEYS.ACTIVITIES);
  if (!raw) {
    list = initSeedActivities();
    localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(list));
  } else {
    try {
      list = JSON.parse(raw);
    } catch {
      list = initSeedActivities();
    }
  }

  // Security enforcement:
  // If user is customer, return ONLY their own activities!
  // If admin, return ALL user activities.
  if (currentUser && currentUser.role === 'customer') {
    return list.filter((a) => a.userEmail === currentUser.email);
  }

  return list;
}

export function logActivity(activity: Omit<ActivityLog, 'id' | 'timestamp'>): ActivityLog {
  const logs = getActivityLogs();
  const newLog: ActivityLog = {
    ...activity,
    id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString(),
  };

  const updated = [newLog, ...logs].slice(0, 300); // retain last 300 logs
  localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(updated));

  // Async mirror to Supabase backend
  supabaseInsertActivity(newLog).catch(() => {});

  return newLog;
}

// Dataset storage
export function getDatasets(currentUser?: User | null): UploadDataset[] {
  let datasets: UploadDataset[] = [];
  const raw = localStorage.getItem(STORAGE_KEYS.DATASETS);
  if (!raw) {
    datasets = initSeedDatasets();
    localStorage.setItem(STORAGE_KEYS.DATASETS, JSON.stringify(datasets));
  } else {
    try {
      datasets = JSON.parse(raw);
    } catch {
      datasets = initSeedDatasets();
    }
  }

  // Security enforcement:
  // Customer views only their own datasets. Admin sees all.
  if (currentUser && currentUser.role === 'customer') {
    return datasets.filter((d) => d.uploadedBy === currentUser.email);
  }

  return datasets;
}

export function saveDataset(dataset: UploadDataset, user: User): void {
  const all = getDatasets(); // get all
  const updated = [dataset, ...all.filter((d) => d.id !== dataset.id)];
  localStorage.setItem(STORAGE_KEYS.DATASETS, JSON.stringify(updated));

  // Async mirror dataset to Supabase backend
  supabaseInsertDataset(dataset).catch(() => {});

  // Log activity
  logActivity({
    userId: user.id,
    userEmail: user.email,
    userName: user.name,
    userRole: user.role,
    actionType: 'UPLOAD_CSV',
    details: `Uploaded & analyzed "${dataset.fileName}" (${dataset.rowCount} rows, ${dataset.criticalCount} Critical, ${dataset.warningCount} Warning).`,
    severity: dataset.criticalCount > 0 ? 'critical' : dataset.warningCount > 0 ? 'warning' : 'success',
    facilityId: dataset.facility,
    metadata: {
      datasetId: dataset.id,
      healthScore: dataset.healthScore,
    },
  });

  if (dataset.criticalCount > 0 || dataset.warningCount > 0) {
    logActivity({
      userId: user.id,
      userEmail: user.email,
      userName: user.name,
      userRole: user.role,
      actionType: 'DETECTION_ALERT',
      details: `Trouble Engine triggered ${dataset.criticalCount} critical and ${dataset.warningCount} warning alerts for ${dataset.facility}.`,
      severity: dataset.criticalCount > 0 ? 'critical' : 'warning',
      facilityId: dataset.facility,
    });
  }
}

export function updateTroubleStatus(
  troubleId: string,
  newStatus: 'open' | 'in_progress' | 'resolved',
  note: string,
  user: User
): void {
  const datasets = getDatasets();
  let found = false;
  let targetDatasetId = '';

  for (const ds of datasets) {
    const trouble = ds.troubles.find((t) => t.id === troubleId);
    if (trouble) {
      trouble.status = newStatus;
      trouble.resolutionNotes = note;
      if (newStatus === 'resolved') {
        trouble.resolvedAt = new Date().toISOString();
        trouble.resolvedBy = `${user.name} (${user.role})`;
      }
      found = true;
      targetDatasetId = ds.id;
      break;
    }
  }

  if (found) {
    localStorage.setItem(STORAGE_KEYS.DATASETS, JSON.stringify(datasets));
    // Mirror update to Supabase
    if (targetDatasetId) {
      supabaseUpdateTrouble(
        targetDatasetId,
        troubleId,
        newStatus,
        note,
        `${user.name} (${user.role})`
      ).catch(() => {});
    }

    logActivity({
      userId: user.id,
      userEmail: user.email,
      userName: user.name,
      userRole: user.role,
      actionType: newStatus === 'resolved' ? 'RESOLVE_ALERT' : 'APPLY_SOLUTION',
      details: `Alert "${troubleId}" status updated to [${newStatus.toUpperCase()}] by ${user.name}. Note: "${note}"`,
      severity: newStatus === 'resolved' ? 'success' : 'info',
    });
  }
}

export function deleteDataset(datasetId: string, user: User): void {
  const all = getDatasets();
  const filtered = all.filter((d) => d.id !== datasetId);
  localStorage.setItem(STORAGE_KEYS.DATASETS, JSON.stringify(filtered));

  logActivity({
    userId: user.id,
    userEmail: user.email,
    userName: user.name,
    userRole: user.role,
    actionType: 'MANAGE_USER',
    details: `Dataset ID "${datasetId}" was deleted by ${user.name}.`,
    severity: 'warning',
  });
}

/**
 * Downloads records from Supabase into local cache if available
 */
export async function syncFromSupabase(): Promise<{
  usersSynced: number;
  activitiesSynced: number;
  datasetsSynced: number;
}> {
  let usersSynced = 0;
  let activitiesSynced = 0;
  let datasetsSynced = 0;

  try {
    const remoteUsers = await supabaseFetchUsers();
    if (remoteUsers && remoteUsers.length > 0) {
      const local = getUsers();
      const mergedMap = new Map<string, User>();
      local.forEach((u) => mergedMap.set(u.email.toLowerCase(), u));
      remoteUsers.forEach((u) => mergedMap.set(u.email.toLowerCase(), u));
      const merged = Array.from(mergedMap.values());
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(merged));
      usersSynced = remoteUsers.length;
    }

    const remoteActs = await supabaseFetchActivities();
    if (remoteActs && remoteActs.length > 0) {
      const local = getActivityLogs();
      const mergedMap = new Map<string, ActivityLog>();
      local.forEach((a) => mergedMap.set(a.id, a));
      remoteActs.forEach((a) => mergedMap.set(a.id, a));
      const merged = Array.from(mergedMap.values()).sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
      localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(merged.slice(0, 300)));
      activitiesSynced = remoteActs.length;
    }

    const remoteDatasets = await supabaseFetchDatasets();
    if (remoteDatasets && remoteDatasets.length > 0) {
      const local = getDatasets();
      const mergedMap = new Map<string, UploadDataset>();
      local.forEach((d) => mergedMap.set(d.id, d));
      remoteDatasets.forEach((d) => mergedMap.set(d.id, d));
      const merged = Array.from(mergedMap.values());
      localStorage.setItem(STORAGE_KEYS.DATASETS, JSON.stringify(merged));
      datasetsSynced = remoteDatasets.length;
    }
  } catch (err) {
    console.warn('[Supabase sync error]', err);
  }

  return { usersSynced, activitiesSynced, datasetsSynced };
}

/**
 * Pushes all current local users, activities, datasets to Supabase
 */
export async function pushAllToSupabase(): Promise<{
  usersPushed: number;
  activitiesPushed: number;
  datasetsPushed: number;
}> {
  const users = getUsers();
  const activities = getActivityLogs();
  const datasets = getDatasets();

  let usersPushed = 0;
  let activitiesPushed = 0;
  let datasetsPushed = 0;

  for (const u of users) {
    const ok = await supabaseUpsertUser(u);
    if (ok) usersPushed++;
  }

  for (const a of activities) {
    const ok = await supabaseInsertActivity(a);
    if (ok) activitiesPushed++;
  }

  for (const d of datasets) {
    const ok = await supabaseInsertDataset(d);
    if (ok) datasetsPushed++;
  }

  return { usersPushed, activitiesPushed, datasetsPushed };
}

