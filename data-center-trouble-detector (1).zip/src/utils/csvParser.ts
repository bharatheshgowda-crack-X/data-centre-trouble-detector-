import { TelemetryRecord } from '../types';

export interface ParseResult {
  records: TelemetryRecord[];
  facilityName: string;
  errors: string[];
}

function normalizeHeader(header: string): string {
  return header
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_');
}

export function parseCSV(csvContent: string): ParseResult {
  const lines = csvContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !l.startsWith('#'));

  const errors: string[] = [];
  if (lines.length < 2) {
    return {
      records: [],
      facilityName: 'Unknown Facility',
      errors: ['CSV file is empty or does not contain a header row and at least one data row.'],
    };
  }

  // Parse header
  const rawHeaders = splitCSVLine(lines[0]);
  const headers = rawHeaders.map(normalizeHeader);

  // Index finders
  const findIdx = (possibleKeys: string[]): number => {
    return headers.findIndex((h) => possibleKeys.some((k) => h === k || h.includes(k)));
  };

  const idIdx = findIdx(['id', 'record_id', 'recordid']);
  const timestampIdx = findIdx(['timestamp', 'time', 'date', 'datetime']);
  const facilityIdx = findIdx(['facility', 'datacenter', 'site', 'location', 'dc_name']);
  const rackIdx = findIdx(['rack_id', 'rackid', 'rack', 'cabinet', 'row_id']);
  const pueIdx = findIdx(['pue', 'power_usage_effectiveness']);
  const wueIdx = findIdx(['wue', 'water_usage_effectiveness', 'water_usage']);
  const idlePowerIdx = findIdx(['idle_power', 'idle_server', 'idle_server_power', 'idle_pct']);
  const gridThdIdx = findIdx(['grid_thd', 'thd', 'harmonic_distortion', 'grid_distortion']);
  const tempIdx = findIdx(['inlet_temp', 'server_inlet', 'temp', 'temperature', 'inlet_temperature']);
  const tenantIdIdx = findIdx(['tenant_id', 'tenant', 'customer_id', 'client_id']);
  const tenantStorageIdx = findIdx(['tenant_storage', 'storage_pct', 'storage_usage', 'disk_usage']);
  const tenantPowerIdx = findIdx(['tenant_power', 'tenant_kw', 'rack_power', 'power_kw']);
  const tenantPowerLimitIdx = findIdx(['tenant_power_limit', 'power_limit', 'contracted_kw']);
  const tenantTempIdx = findIdx(['tenant_temp', 'rack_temp', 'cabinet_temp']);
  const tenantBwIdx = findIdx(['tenant_bandwidth', 'bandwidth_gbps', 'network_gbps', 'uplink_gbps']);
  const tenantBwLimitIdx = findIdx(['bandwidth_limit', 'network_limit', 'port_limit_gbps']);

  if (pueIdx === -1 && tempIdx === -1 && wueIdx === -1) {
    errors.push('Warning: Expected at least PUE, WUE, or Server Inlet Temperature columns. Generic matching will attempt to parse.');
  }

  const records: TelemetryRecord[] = [];
  let detectedFacility = 'Data Center Facility';

  for (let i = 1; i < lines.length; i++) {
    const rawCols = splitCSVLine(lines[i]);
    if (rawCols.length === 0 || rawCols.every((c) => c.trim() === '')) continue;

    const rowFac = facilityIdx !== -1 && rawCols[facilityIdx] ? rawCols[facilityIdx].trim() : detectedFacility;
    if (i === 1 && rowFac) detectedFacility = rowFac;

    const pueVal = pueIdx !== -1 ? parseFloat(rawCols[pueIdx]) : 1.25;
    const wueVal = wueIdx !== -1 ? parseFloat(rawCols[wueIdx]) : 1.1;
    const idleVal = idlePowerIdx !== -1 ? parseFloat(rawCols[idlePowerIdx]) : 25;
    const thdVal = gridThdIdx !== -1 ? parseFloat(rawCols[gridThdIdx]) : 3.2;
    const tempVal = tempIdx !== -1 ? parseFloat(rawCols[tempIdx]) : 23.5;

    // Optional tenant values
    const tenantId = tenantIdIdx !== -1 && rawCols[tenantIdIdx] ? rawCols[tenantIdIdx].trim() : undefined;
    const tenantStorage = tenantStorageIdx !== -1 && !isNaN(parseFloat(rawCols[tenantStorageIdx]))
      ? parseFloat(rawCols[tenantStorageIdx])
      : undefined;
    const tenantPower = tenantPowerIdx !== -1 && !isNaN(parseFloat(rawCols[tenantPowerIdx]))
      ? parseFloat(rawCols[tenantPowerIdx])
      : undefined;
    const tenantPowerLimit = tenantPowerLimitIdx !== -1 && !isNaN(parseFloat(rawCols[tenantPowerLimitIdx]))
      ? parseFloat(rawCols[tenantPowerLimitIdx])
      : 10.0;
    const tenantTemp = tenantTempIdx !== -1 && !isNaN(parseFloat(rawCols[tenantTempIdx]))
      ? parseFloat(rawCols[tenantTempIdx])
      : undefined;
    const tenantBw = tenantBwIdx !== -1 && !isNaN(parseFloat(rawCols[tenantBwIdx]))
      ? parseFloat(rawCols[tenantBwIdx])
      : undefined;
    const tenantBwLimit = tenantBwLimitIdx !== -1 && !isNaN(parseFloat(rawCols[tenantBwLimitIdx]))
      ? parseFloat(rawCols[tenantBwLimitIdx])
      : 40.0;

    const record: TelemetryRecord = {
      id: idIdx !== -1 && rawCols[idIdx] ? rawCols[idIdx].trim() : `rec-${i}`,
      timestamp:
        timestampIdx !== -1 && rawCols[timestampIdx]
          ? rawCols[timestampIdx].trim()
          : new Date(Date.now() - (lines.length - i) * 60000).toISOString(),
      facility: rowFac,
      rackId: rackIdx !== -1 && rawCols[rackIdx] ? rawCols[rackIdx].trim() : `R-${String(i).padStart(2, '0')}`,
      pue: isNaN(pueVal) ? 1.2 : pueVal,
      wue: isNaN(wueVal) ? 1.0 : wueVal,
      idlePowerPct: isNaN(idleVal) ? 20 : idleVal,
      gridThd: isNaN(thdVal) ? 3.0 : thdVal,
      serverInletTemp: isNaN(tempVal) ? 22.0 : tempVal,
      tenantId,
      tenantStoragePct: tenantStorage,
      tenantPowerKw: tenantPower,
      tenantPowerLimitKw: tenantPowerLimit,
      tenantTempC: tenantTemp,
      tenantBandwidthGbps: tenantBw,
      tenantBandwidthLimitGbps: tenantBwLimit,
    };

    records.push(record);
  }

  return {
    records,
    facilityName: detectedFacility,
    errors,
  };
}

function splitCSVLine(line: string): string[] {
  const result: string[] = [];
  let insideQuotes = false;
  let current = '';

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"' || char === "'") {
      insideQuotes = !insideQuotes;
    } else if (char === ',' && !insideQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

// Built-in downloadable / quick-load sample CSV files
export const SAMPLE_DATASETS = {
  CRITICAL_STRESS: {
    id: 'sample-critical-hyperscale',
    name: 'Hyperscale_Facility_West_Critical.csv',
    description: 'High PUE (1.92), WUE surge (2.85 L/kWh), Inlet Temp (34.5°C), Tenant Overdraw',
    facility: 'Apex Hyperscale DC-04 (Oregon)',
    csv: `timestamp,facility,rack_id,pue,wue,idle_server_power_pct,grid_thd_pct,server_inlet_temp_c,tenant_id,tenant_storage_pct,tenant_power_kw,tenant_power_limit_kw,tenant_temp_c,tenant_bandwidth_gbps,tenant_bandwidth_limit_gbps
2026-10-28 08:00:00,Apex Hyperscale DC-04,Rack-A1,1.94,2.82,44.2,6.1,33.4,Acme-AI,96.8,11.8,10.0,33.8,42.4,40.0
2026-10-28 08:15:00,Apex Hyperscale DC-04,Rack-A2,1.86,2.65,65.8,5.4,34.2,Fintech-Core,88.4,12.4,10.0,31.5,39.1,40.0
2026-10-28 08:30:00,Apex Hyperscale DC-04,Rack-A3,1.91,2.90,62.0,11.2,35.1,StreamMedia,92.1,9.8,10.0,34.6,41.2,40.0
2026-10-28 08:45:00,Apex Hyperscale DC-04,Rack-B1,1.72,1.95,38.5,8.2,29.3,GovCloud-Sec,74.5,8.2,10.0,26.4,22.0,40.0
2026-10-28 09:00:00,Apex Hyperscale DC-04,Rack-B2,1.88,2.70,58.4,7.8,32.8,Acme-AI,97.2,12.9,10.0,33.9,43.0,40.0
2026-10-28 09:15:00,Apex Hyperscale DC-04,Rack-B3,1.55,1.75,48.0,4.6,28.2,BioGenomics,91.0,9.4,10.0,28.9,35.6,40.0
2026-10-28 09:30:00,Apex Hyperscale DC-04,Rack-C1,1.98,3.10,68.5,12.4,36.0,HPC-Quantum,94.2,13.2,10.0,35.2,44.5,40.0
2026-10-28 09:45:00,Apex Hyperscale DC-04,Rack-C2,1.64,1.85,42.0,5.8,28.9,DevCluster,82.0,8.7,10.0,27.8,28.5,40.0`,
  },

  WARNING_EDGE: {
    id: 'sample-warning-edge',
    name: 'Edge_Modular_Colo_Warning.csv',
    description: 'Grid THD harmonics (7.8%), High Idle Server draw (52%), Tenant Storage 92%',
    facility: 'MetroEdge Modular Pod-12 (Frankfurt)',
    csv: `timestamp,facility,rack_id,pue,wue,idle_server_power_pct,grid_thd_pct,server_inlet_temp_c,tenant_id,tenant_storage_pct,tenant_power_kw,tenant_power_limit_kw,tenant_temp_c,tenant_bandwidth_gbps,tenant_bandwidth_limit_gbps
2026-10-28 07:00:00,MetroEdge Pod-12,Edge-01,1.48,1.35,45.2,7.4,26.5,LogiTrans,91.5,8.8,10.0,27.2,28.4,40.0
2026-10-28 07:30:00,MetroEdge Pod-12,Edge-02,1.54,1.62,54.0,8.2,27.8,UrbanSmart,93.4,9.2,10.0,28.5,36.8,40.0
2026-10-28 08:00:00,MetroEdge Pod-12,Edge-03,1.58,1.70,51.8,6.9,28.1,AutonomousDrive,89.0,9.5,10.0,29.1,38.2,40.0
2026-10-28 08:30:00,MetroEdge Pod-12,Edge-04,1.42,1.28,42.5,7.8,25.9,LogiTrans,92.0,8.6,10.0,26.8,31.0,40.0
2026-10-28 09:00:00,MetroEdge Pod-12,Edge-05,1.52,1.65,58.4,8.5,27.6,UrbanSmart,94.1,9.6,10.0,28.7,37.5,40.0`,
  },

  OPTIMAL_GREEN: {
    id: 'sample-optimal-green',
    name: 'Green_Tier_IV_Optimal.csv',
    description: 'Gold Standard: PUE 1.18, WUE 0.38 L/kWh, Idle 18%, Inlet Temp 21.5°C, Zero Alerts',
    facility: 'Nordic EcoData Tier-IV (Reykjavik)',
    csv: `timestamp,facility,rack_id,pue,wue,idle_server_power_pct,grid_thd_pct,server_inlet_temp_c,tenant_id,tenant_storage_pct,tenant_power_kw,tenant_power_limit_kw,tenant_temp_c,tenant_bandwidth_gbps,tenant_bandwidth_limit_gbps
2026-10-28 06:00:00,Nordic EcoData,Eco-01,1.16,0.32,18.4,1.8,21.2,GlobalBanking,64.2,6.8,12.0,22.0,18.4,50.0
2026-10-28 07:00:00,Nordic EcoData,Eco-02,1.18,0.35,16.2,1.9,21.5,HealthCloud,58.0,7.1,12.0,22.4,22.1,50.0
2026-10-28 08:00:00,Nordic EcoData,Eco-03,1.19,0.38,19.5,2.1,22.0,ResearchAI,71.5,8.2,12.0,23.1,26.5,50.0
2026-10-28 09:00:00,Nordic EcoData,Eco-04,1.17,0.34,17.8,1.7,21.8,GlobalBanking,68.0,7.0,12.0,22.6,20.0,50.0`,
  },
};

export function generateTemplateCSV(): string {
  return `# Data Center Metrics Telemetry Template
# PUE Thresholds: Warning > 1.5, Critical > 1.8
# WUE Thresholds: Warning > 1.5 L/kWh, Critical > 2.5 L/kWh
# Idle Power Thresholds: Warning > 40%, Critical > 60%
# Grid THD Thresholds: Warning > 5%, Critical > 10%
# Server Inlet Temp: Warning > 27°C, Critical > 32°C
# Tenant Overuse: Storage > 90%, Power > Limit, Temp > 28°C, Network > 90%
timestamp,facility,rack_id,pue,wue,idle_server_power_pct,grid_thd_pct,server_inlet_temp_c,tenant_id,tenant_storage_pct,tenant_power_kw,tenant_power_limit_kw,tenant_temp_c,tenant_bandwidth_gbps,tenant_bandwidth_limit_gbps
2026-10-28 10:00:00,My Enterprise DC,Rack-01,1.38,1.20,28.5,3.2,24.0,AcmeTenant,75.0,7.5,10.0,25.0,25.0,40.0
2026-10-28 10:15:00,My Enterprise DC,Rack-02,1.55,1.65,42.0,5.4,28.5,BetaCorp,91.5,9.4,10.0,29.2,38.0,40.0
2026-10-28 10:30:00,My Enterprise DC,Rack-03,1.88,2.75,64.0,10.5,33.0,GammaLogistics,96.0,11.5,10.0,33.5,41.5,40.0`;
}
