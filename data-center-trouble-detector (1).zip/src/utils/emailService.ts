import {
  BackendNotificationRecord,
  DetectedTrouble,
  EmailDeliveryStatus,
  EmailNotificationRecord,
  EmailSettings,
  User,
} from '../types';
import { logActivity } from './storage';

const EMAIL_STORAGE_KEY = 'dc_trouble_detector_email_history';
const EMAIL_SETTINGS_PREFIX = 'dc_trouble_detector_email_settings_';

export function getEmailSettings(user?: User | null): EmailSettings {
  const fallbackEmail = user?.email || 'bbharatheshgowdamr@gmail.com';
  if (!user) {
    return {
      primaryEmail: fallbackEmail,
      additionalEmails: '',
      notifyOnCritical: true,
      notifyOnWarning: true,
      autoSendOnUpload: true,
    };
  }

  const raw = localStorage.getItem(`${EMAIL_SETTINGS_PREFIX}${user.id}`);
  if (!raw) {
    return {
      primaryEmail: user.email || fallbackEmail,
      additionalEmails: user.role === 'admin' ? 'bbharatheshgowdamr@gmail.com' : '',
      notifyOnCritical: true,
      notifyOnWarning: true,
      autoSendOnUpload: true,
    };
  }

  try {
    return JSON.parse(raw);
  } catch {
    return {
      primaryEmail: user.email || fallbackEmail,
      additionalEmails: '',
      notifyOnCritical: true,
      notifyOnWarning: true,
      autoSendOnUpload: true,
    };
  }
}

export function saveEmailSettings(user: User, settings: EmailSettings): void {
  localStorage.setItem(`${EMAIL_SETTINGS_PREFIX}${user.id}`, JSON.stringify(settings));
}

export function getEmailHistory(user?: User | null): EmailNotificationRecord[] {
  const raw = localStorage.getItem(EMAIL_STORAGE_KEY);
  if (!raw) return [];
  try {
    const list: EmailNotificationRecord[] = JSON.parse(raw);
    if (user && user.role === 'customer') {
      return list.filter((e) => e.recipientEmail === user.email);
    }
    return list;
  } catch {
    return [];
  }
}

/**
 * Builds rich text for plain text email clients and mailto links
 */
export function generateAlertEmailText(trouble: DetectedTrouble, facility: string): string {
  return `DATA CENTER TROUBLE DETECTOR - SYSTEM INCIDENT NOTIFICATION
============================================================
ALERT STATUS: ${trouble.severity.toUpperCase()}
FACILITY: ${facility}
AFFECTED TARGET: ${trouble.rackOrTenant}
METRIC: ${trouble.metricName}
OBSERVED READING: ${trouble.observedValue} ${trouble.unit}
SAFE THRESHOLD: > ${trouble.thresholdValue} ${trouble.unit}
TIMESTAMP: ${new Date(trouble.timestamp).toUTCString()}
TICKET ID: ${trouble.id}

PROBLEM DESCRIPTION & TELEMETRY ANOMALY:
----------------------------------------
${trouble.problemDescription}

RECOMMENDED CORRECTIVE ACTION & REMEDIATION PLAN:
------------------------------------------------
${trouble.recommendedSolution}

POTENTIAL CONSEQUENCES IF IGNORED:
----------------------------------
${trouble.potentialConsequences}

============================================================
Dispatched by Data Center Trouble Detector System
Mission-Critical Telemetry & Automated Diagnostic Gateway
`;
}

/**
 * Builds a styled HTML email template
 */
export function generateAlertEmailHTML(
  trouble: DetectedTrouble,
  facility: string,
  recipientEmail: string
): string {
  const isCrit = trouble.severity === 'critical';
  const headerBg = isCrit ? '#7f1d1d' : '#78350f';
  const badgeColor = isCrit ? '#ef4444' : '#f59e0b';
  const badgeText = isCrit ? 'CRITICAL INCIDENT' : 'WARNING CEILING';

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${trouble.problemTitle}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #0b0f19; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f1f5f9;">
  <div style="max-width: 640px; margin: 24px auto; background-color: #0f172a; border-radius: 16px; border: 1px solid #1e293b; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
    
    <!-- Top Brand Bar -->
    <div style="background-color: #020617; padding: 18px 24px; border-bottom: 1px solid #1e293b; display: flex; align-items: center; justify-content: space-between;">
      <div>
        <span style="font-size: 13px; font-weight: 800; color: #38bdf8; letter-spacing: 0.1em; text-transform: uppercase;">DATA CENTER TROUBLE DETECTOR</span>
        <div style="font-size: 11px; color: #94a3b8; font-family: monospace; margin-top: 2px;">AUTOMATED TELEMETRY NOTIFICATION GATEWAY</div>
      </div>
      <div style="background-color: ${headerBg}; color: #ffffff; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; font-family: monospace;">
        ${badgeText}
      </div>
    </div>

    <!-- Incident Header Banner -->
    <div style="padding: 24px; border-bottom: 1px solid #1e293b; background: linear-gradient(180deg, rgba(15,23,42,0.8) 0%, rgba(2,6,23,0.9) 100%);">
      <div style="color: ${badgeColor}; font-size: 12px; font-weight: 700; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
        FACILITY: ${facility} • TARGET: ${trouble.rackOrTenant}
      </div>
      <h1 style="margin: 0 0 12px 0; font-size: 20px; font-weight: 800; color: #ffffff; line-height: 1.3;">
        ${trouble.problemTitle}
      </h1>
      <p style="margin: 0; font-size: 13px; color: #cbd5e1; line-height: 1.6;">
        Our automated telemetry analysis detected that your data center subsystem has breached operational tolerances. Immediate engineering review is recommended.
      </p>
    </div>

    <!-- Telemetry Metric Comparison Box -->
    <div style="padding: 20px 24px;">
      <table style="width: 100%; border-collapse: separate; border-spacing: 8px 0; margin-bottom: 20px;">
        <tr>
          <td style="background-color: #020617; border: 1px solid #1e293b; border-radius: 10px; padding: 12px 14px; text-align: left; width: 33%;">
            <div style="font-size: 10px; color: #64748b; font-family: monospace; text-transform: uppercase;">MONITORED METRIC</div>
            <div style="font-size: 12px; font-weight: 700; color: #f8fafc; margin-top: 4px;">${trouble.metricName}</div>
          </td>
          <td style="background-color: #020617; border: 1px solid ${isCrit ? '#991b1b' : '#92400e'}; border-radius: 10px; padding: 12px 14px; text-align: left; width: 33%;">
            <div style="font-size: 10px; color: ${badgeColor}; font-family: monospace; text-transform: uppercase;">RECORDED VALUE</div>
            <div style="font-size: 16px; font-weight: 800; color: ${badgeColor}; margin-top: 4px; font-family: monospace;">${trouble.observedValue} ${trouble.unit}</div>
          </td>
          <td style="background-color: #020617; border: 1px solid #1e293b; border-radius: 10px; padding: 12px 14px; text-align: left; width: 33%;">
            <div style="font-size: 10px; color: #64748b; font-family: monospace; text-transform: uppercase;">THRESHOLD LIMIT</div>
            <div style="font-size: 13px; font-weight: 700; color: #cbd5e1; margin-top: 4px; font-family: monospace;">&gt; ${trouble.thresholdValue} ${trouble.unit}</div>
          </td>
        </tr>
      </table>

      <!-- Problem Description -->
      <div style="background-color: #020617; border: 1px solid #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 700; color: #94a3b8; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
          Problem Diagnostics & Analysis
        </div>
        <div style="font-size: 13px; color: #e2e8f0; line-height: 1.6;">
          ${trouble.problemDescription}
        </div>
      </div>

      <!-- Recommended Solution -->
      <div style="background-color: rgba(6, 182, 212, 0.08); border: 1px solid rgba(6, 182, 212, 0.35); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 700; color: #38bdf8; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
          ⚡ Recommended Engineering Action & Solution
        </div>
        <div style="font-size: 13px; color: #e0f2fe; line-height: 1.6; white-space: pre-line;">
          ${trouble.recommendedSolution}
        </div>
      </div>

      <!-- Consequences If Ignored -->
      <div style="background-color: rgba(239, 68, 68, 0.06); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 700; color: #f87171; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
          ⚠️ Potential Consequences if Left Unresolved
        </div>
        <div style="font-size: 13px; color: #fecaca; line-height: 1.6;">
          ${trouble.potentialConsequences}
        </div>
      </div>

      <!-- Notification Metadata -->
      <div style="background-color: #020617; border-radius: 8px; padding: 12px 16px; font-size: 11px; color: #64748b; font-family: monospace;">
        <div>Recipient Email: <span style="color: #94a3b8;">${recipientEmail}</span></div>
        <div>Diagnostic Incident ID: <span style="color: #94a3b8;">${trouble.id}</span></div>
        <div>Generated: <span style="color: #94a3b8;">${new Date().toUTCString()}</span></div>
      </div>
    </div>

    <!-- Footer -->
    <div style="background-color: #020617; border-top: 1px solid #1e293b; padding: 16px 24px; text-align: center; font-size: 11px; color: #64748b;">
      <p style="margin: 0 0 4px 0;">This is an automated engineering alert generated by your Data Center Trouble Detector platform.</p>
      <p style="margin: 0; color: #475569;">Standards: IEEE 519 & ASHRAE TC 9.9 Thermal Compliance Standards.</p>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Creates mailto URL for native email clients
 */
export function createMailtoLink(
  recipientEmail: string,
  trouble: DetectedTrouble,
  facility: string
): string {
  const subject = encodeURIComponent(
    `[${trouble.severity.toUpperCase()} ALERT] ${facility}: ${trouble.problemTitle}`
  );
  const body = encodeURIComponent(generateAlertEmailText(trouble, facility));
  return `mailto:${recipientEmail}?subject=${subject}&body=${body}`;
}

/**
 * Sends/dispatches an email notification for a trouble incident
 */
export function dispatchAlertEmail(
  trouble: DetectedTrouble,
  facility: string,
  recipientEmail: string,
  currentUser: User
): { success: boolean; record: EmailNotificationRecord; mailtoUrl: string } {
  const targetEmail = recipientEmail.trim() || currentUser.email;

  const record: EmailNotificationRecord = {
    id: `email-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    sentAt: new Date().toISOString(),
    recipientEmail: targetEmail,
    facility,
    troubleTitle: trouble.problemTitle,
    severity: trouble.severity,
    subject: `[${trouble.severity.toUpperCase()} ALERT] ${facility}: ${trouble.problemTitle}`,
    bodyPreview: `Measured ${trouble.observedValue} ${trouble.unit} (Limit: ${trouble.thresholdValue} ${trouble.unit}). Recommended Action: ${trouble.recommendedSolution.slice(0, 100)}...`,
    status: 'delivered',
    troubleId: trouble.id,
  };

  // Save to history
  const history = getEmailHistory();
  const updatedHistory = [record, ...history].slice(0, 200);
  localStorage.setItem(EMAIL_STORAGE_KEY, JSON.stringify(updatedHistory));

  // Log in system activity audit trail
  logActivity({
    userId: currentUser.id,
    userEmail: currentUser.email,
    userName: currentUser.name,
    userRole: currentUser.role,
    actionType: 'SEND_EMAIL_ALERT',
    details: `Alert notification email dispatched to "${targetEmail}" for [${trouble.severity.toUpperCase()}] ${trouble.problemTitle}.`,
    severity: trouble.severity === 'critical' ? 'critical' : 'warning',
    facilityId: facility,
    metadata: {
      emailId: record.id,
      recipient: targetEmail,
      troubleId: trouble.id,
    },
  });

  const mailtoUrl = createMailtoLink(targetEmail, trouble, facility);

  // Also notify backend in the background so it records the attempt in official audit logs
  sendIncidentNotificationToBackend(trouble, facility, currentUser, targetEmail).catch(() => {});

  return {
    success: true,
    record,
    mailtoUrl,
  };
}

/**
 * Maps trouble severity to standard email severity levels
 */
export function mapTroubleSeverity(severity: string): 'Critical' | 'High' | 'Medium' | 'Low' {
  const s = (severity || '').toLowerCase();
  if (s === 'critical') return 'Critical';
  if (s === 'warning' || s === 'high') return 'High';
  if (s === 'medium') return 'Medium';
  return 'Low';
}

/**
 * Checks email server configuration status (Resend or SendGrid)
 */
export async function fetchEmailServerConfig(): Promise<{
  configured: boolean;
  provider: 'Resend' | 'SendGrid' | 'None';
  from: string;
}> {
  try {
    const res = await fetch('/api/email/config');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const providerName: 'Resend' | 'SendGrid' | 'None' =
      data.provider === 'resend' || data.providerName === 'Resend'
        ? 'Resend'
        : data.provider === 'sendgrid' || data.providerName === 'SendGrid'
        ? 'SendGrid'
        : 'None';
    return {
      configured: !!data.configured,
      provider: providerName,
      from: data.fromAddress || data.from || '',
    };
  } catch (err) {
    return { configured: false, provider: 'None', from: '' };
  }
}

/**
 * Retrieves email notification history for administrators from server
 */
export async function fetchBackendNotificationHistory(): Promise<BackendNotificationRecord[]> {
  try {
    const res = await fetch('/api/email/history');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data.notifications || data.history || [];
  } catch (err) {
    console.warn('[EmailService] Could not fetch server email history:', err);
    return [];
  }
}

/**
 * Fetches status for a single incident
 */
export async function fetchIncidentEmailStatus(
  incidentId: string
): Promise<BackendNotificationRecord | null> {
  try {
    const res = await fetch(`/api/email/status/${encodeURIComponent(incidentId)}`);
    if (!res.ok) return null;
    const data = await res.json();
    return data.notification || null;
  } catch (err) {
    return null;
  }
}

/**
 * Fetches status for multiple incidents in a single batch request
 */
export async function fetchEmailStatusesBatch(
  incidentIds: string[]
): Promise<Record<string, BackendNotificationRecord>> {
  if (!incidentIds.length) return {};
  try {
    const res = await fetch('/api/email/status-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ incidentIds }),
    });
    if (!res.ok) return {};
    const data = await res.json();
    return data.statuses || {};
  } catch (err) {
    console.warn('[EmailService] Batch status fetch failed:', err);
    return {};
  }
}

/**
 * Sends automated incident notification to backend email router
 */
export async function sendIncidentNotificationToBackend(
  trouble: DetectedTrouble,
  facility: string,
  user: User,
  overrideRecipientEmail?: string
): Promise<{
  success: boolean;
  notification: BackendNotificationRecord;
  error?: string;
  duplicate?: boolean;
}> {
  const payload = {
    incidentId: trouble.id,
    troubleId: trouble.id,
    datasetId: trouble.datasetId,
    facility: facility || trouble.facility,
    rackOrTenant: trouble.rackOrTenant,
    tenantId: trouble.rackOrTenant.replace(/^Tenant:\s*/i, '').trim(),
    category: trouble.category,
    categoryLabel: trouble.categoryLabel,
    metricName: trouble.metricName,
    observedValue: trouble.observedValue,
    thresholdValue: trouble.thresholdValue,
    unit: trouble.unit,
    severity: mapTroubleSeverity(trouble.severity),
    problemTitle: trouble.problemTitle,
    problemDescription: trouble.problemDescription,
    potentialConsequences: trouble.potentialConsequences,
    recommendedSolution: trouble.recommendedSolution,
    timestamp: trouble.timestamp || new Date().toISOString(),
    customerEmail: overrideRecipientEmail || user.email,
    customerName: user.name,
  };

  try {
    const res = await fetch('/api/email/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const result = await res.json();
    return result;
  } catch (err: any) {
    return {
      success: false,
      notification: {
        id: `local-err-${Date.now()}`,
        incidentId: trouble.id,
        facility,
        customerEmail: overrideRecipientEmail || user.email,
        customerName: user.name,
        severity: mapTroubleSeverity(trouble.severity),
        problemTitle: trouble.problemTitle,
        status: 'Failed',
        provider: 'None',
        error: err.message || 'Network request to backend failed',
        attempts: 1,
        createdAt: new Date().toISOString(),
        lastAttemptAt: new Date().toISOString(),
      },
      error: err.message || 'Network request failed',
    };
  }
}

/**
 * Retries failed email notification safely on the backend
 */
export async function retryIncidentEmailNotification(
  incidentId: string
): Promise<{
  success: boolean;
  notification?: BackendNotificationRecord;
  error?: string;
}> {
  try {
    const res = await fetch('/api/email/retry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ incidentId }),
    });
    const result = await res.json();
    return result;
  } catch (err: any) {
    return {
      success: false,
      error: err.message || 'Retry request to server failed',
    };
  }
}

/**
 * Automatically dispatches notifications to the backend on anomaly detection
 */
export async function autoDispatchBackendEmailAlerts(
  troubles: DetectedTrouble[],
  facility: string,
  user: User
): Promise<{
  totalSent: number;
  totalFailed: number;
  results: Array<{ incidentId: string; status: EmailDeliveryStatus; error?: string }>;
}> {
  const results: Array<{ incidentId: string; status: EmailDeliveryStatus; error?: string }> = [];
  let totalSent = 0;
  let totalFailed = 0;

  for (const trouble of troubles) {
    try {
      const res = await sendIncidentNotificationToBackend(trouble, facility, user);
      const status: EmailDeliveryStatus = res.notification?.status || (res.success ? 'Sent' : 'Failed');
      if (status === 'Sent') {
        totalSent++;
      } else {
        totalFailed++;
      }
      results.push({
        incidentId: trouble.id,
        status,
        error: res.error || res.notification?.error,
      });
    } catch (err: any) {
      totalFailed++;
      results.push({
        incidentId: trouble.id,
        status: 'Failed',
        error: err.message,
      });
    }
  }

  return { totalSent, totalFailed, results };
}

/**
 * Dispatches automated batch notifications if settings permit
 */
export function autoDispatchUploadAlerts(
  troubles: DetectedTrouble[],
  facility: string,
  user: User
): { emailsDispatched: number } {
  // Trigger backend email automation asynchronously
  autoDispatchBackendEmailAlerts(troubles, facility, user).catch((err) => {
    console.warn('[EmailService] Automated backend email dispatch encountered error:', err);
  });

  const settings = getEmailSettings(user);
  if (!settings.autoSendOnUpload) return { emailsDispatched: 0 };

  const recipients = [
    settings.primaryEmail,
    ...settings.additionalEmails
      .split(',')
      .map((e) => e.trim())
      .filter((e) => e.length > 0 && e.includes('@')),
  ];

  let count = 0;
  for (const t of troubles) {
    if (t.severity === 'critical' && !settings.notifyOnCritical) continue;
    if (t.severity === 'warning' && !settings.notifyOnWarning) continue;

    for (const rec of recipients) {
      dispatchAlertEmail(t, facility, rec, user);
      count++;
    }
  }

  return { emailsDispatched: count };
}
