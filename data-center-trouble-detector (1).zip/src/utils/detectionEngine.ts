import { DetectedTrouble, TelemetryRecord, TroubleCategory } from '../types';

export interface DetectionResult {
  troubles: DetectedTrouble[];
  criticalCount: number;
  warningCount: number;
  healthyCount: number;
  healthScore: number;
}

export const THRESHOLDS = {
  PUE: { warning: 1.5, critical: 1.8, unit: '' },
  WUE: { warning: 1.5, critical: 2.5, unit: 'L/kWh' },
  IDLE_POWER: { warning: 40, critical: 60, unit: '%' },
  GRID_THD: { warning: 5, critical: 10, unit: '%' },
  INLET_TEMP: { warning: 27, critical: 32, unit: '°C' },
  TENANT_STORAGE: { warning: 90, critical: 95, unit: '%' },
  TENANT_POWER_USAGE_PCT: { warning: 90, critical: 100, unit: '%' },
  TENANT_TEMP: { warning: 28, critical: 32, unit: '°C' },
  TENANT_NETWORK_USAGE_PCT: { warning: 90, critical: 98, unit: '%' },
};

/**
 * Analyzes telemetry records against strict data center engineering thresholds.
 */
export function analyzeTelemetryRecords(
  records: TelemetryRecord[],
  datasetId: string,
  fileName: string
): DetectionResult {
  const troubles: DetectedTrouble[] = [];

  records.forEach((record, index) => {
    const loc = record.rackId ? `${record.facility} • Rack ${record.rackId}` : record.facility;
    const timeStr = record.timestamp || new Date().toISOString();

    // 1. Excessive Power Usage & High PUE
    if (record.pue > THRESHOLDS.PUE.critical) {
      troubles.push({
        id: `tr-${datasetId}-${index}-pue-crit`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: record.rackId || 'Main Power Train',
        category: 'PUE_EFFICIENCY',
        categoryLabel: 'Excessive Power Usage & High PUE',
        metricName: 'PUE (Power Usage Effectiveness)',
        observedValue: Number(record.pue.toFixed(2)),
        thresholdValue: THRESHOLDS.PUE.critical,
        unit: 'ratio',
        severity: 'critical',
        problemTitle: `Critical PUE Inefficiency (${record.pue.toFixed(2)})`,
        problemDescription: `Power Usage Effectiveness is measured at ${record.pue.toFixed(2)}, severely violating the critical threshold of 1.80. Non-compute overhead (HVAC chillers, CRAH blowers, and UPS power conversion losses) is consuming more electrical energy than IT hardware.`,
        recommendedSolution: `1. Immediately inspect chilled water loop return temps and raise cold-aisle supply air setpoints by 1.5°C.\n2. Verify air containment seals (brush grommets, blanking panels) across cold/hot aisles.\n3. Transition chillers to water-side economizer / free cooling if ambient wet-bulb temperature permits.`,
        potentialConsequences: `High operational electricity expenses (OPEX surge by 35-50%), carbon emissions compliance penalties, elevated substation transformer loading, and risk of breaker trip during peak demand charges.`,
        status: 'open',
      });
    } else if (record.pue > THRESHOLDS.PUE.warning) {
      troubles.push({
        id: `tr-${datasetId}-${index}-pue-warn`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: record.rackId || 'Main Power Train',
        category: 'PUE_EFFICIENCY',
        categoryLabel: 'Excessive Power Usage & High PUE',
        metricName: 'PUE (Power Usage Effectiveness)',
        observedValue: Number(record.pue.toFixed(2)),
        thresholdValue: THRESHOLDS.PUE.warning,
        unit: 'ratio',
        severity: 'warning',
        problemTitle: `Elevated PUE Ratio (${record.pue.toFixed(2)})`,
        problemDescription: `Power Usage Effectiveness has climbed to ${record.pue.toFixed(2)}, surpassing the safe warning ceiling of 1.50. Cooling systems or power distribution units (PDUs) are operating sub-optimally relative to IT payload.`,
        recommendedSolution: `Audit airflow distribution, balance three-phase transformer loads, and trim variable frequency drive (VFD) fan speeds to match real server heat exhaust loads.`,
        potentialConsequences: `Gradual accumulation of energy costs, reduced facility efficiency rating, and potential capacity throttling during high ambient summer weather.`,
        status: 'open',
      });
    }

    // 2. High Water Consumption for Cooling (WUE)
    if (record.wue > THRESHOLDS.WUE.critical) {
      troubles.push({
        id: `tr-${datasetId}-${index}-wue-crit`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: 'Evaporative Cooling Towers',
        category: 'WUE_COOLING',
        categoryLabel: 'High Water Consumption for Cooling',
        metricName: 'WUE (Water Usage Effectiveness)',
        observedValue: Number(record.wue.toFixed(2)),
        thresholdValue: THRESHOLDS.WUE.critical,
        unit: 'L/kWh',
        severity: 'critical',
        problemTitle: `Excessive Water Evaporation & Cooling Tower Stress (${record.wue.toFixed(2)} L/kWh)`,
        problemDescription: `Water Usage Effectiveness is currently ${record.wue.toFixed(2)} L/kWh, well beyond the 2.5 L/kWh critical threshold. Indicates severe water loss, cooling tower blowdown inefficiency, or possible underground loop leaks.`,
        recommendedSolution: `1. Inspect cooling tower conductivity meters and cycles of concentration (CoC).\n2. Check for makeup water solenoid valve sticking or basin overflows.\n3. Switch hybrid adiabatic dry coolers to dry mode if ambient conditions allow.`,
        potentialConsequences: `Catastrophic municipal water tariff surcharges, mineral scaling on heat exchangers reducing heat transfer efficiency, and local regulatory water quota suspension.`,
        status: 'open',
      });
    } else if (record.wue > THRESHOLDS.WUE.warning) {
      troubles.push({
        id: `tr-${datasetId}-${index}-wue-warn`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: 'Evaporative Cooling Towers',
        category: 'WUE_COOLING',
        categoryLabel: 'High Water Consumption for Cooling',
        metricName: 'WUE (Water Usage Effectiveness)',
        observedValue: Number(record.wue.toFixed(2)),
        thresholdValue: THRESHOLDS.WUE.warning,
        unit: 'L/kWh',
        severity: 'warning',
        problemTitle: `Elevated Water Consumption (${record.wue.toFixed(2)} L/kWh)`,
        problemDescription: `Water Usage Effectiveness stands at ${record.wue.toFixed(2)} L/kWh, exceeding the 1.5 L/kWh caution boundary.`,
        recommendedSolution: `Test water treatment chemistry, check drift eliminators, and optimize blowdown timing to off-peak evaporation hours.`,
        potentialConsequences: `Increased water footprint, accelerated chemical biocides depletion, and higher utility consumption costs.`,
        status: 'open',
      });
    }

    // 3. Idle Server Inefficiency
    if (record.idlePowerPct > THRESHOLDS.IDLE_POWER.critical) {
      troubles.push({
        id: `tr-${datasetId}-${index}-idle-crit`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: record.rackId || 'Compute Fleet',
        category: 'IDLE_SERVER_POWER',
        categoryLabel: 'Idle Server Inefficiency',
        metricName: 'Idle Server Power Draw',
        observedValue: Number(record.idlePowerPct.toFixed(1)),
        thresholdValue: THRESHOLDS.IDLE_POWER.critical,
        unit: '%',
        severity: 'critical',
        problemTitle: `Severe Zombie Server Ghost Load (${record.idlePowerPct.toFixed(1)}%)`,
        problemDescription: `Over ${record.idlePowerPct.toFixed(1)}% of total server power draw is consumed by idle or unutilized compute nodes (> 60% critical limit). Servers are powered on and spinning fans with zero or negligible CPU/memory work.`,
        recommendedSolution: `1. Consolidate low-utilization virtual machines / containers onto denser hypervisors.\n2. Trigger automated BMC/IPMI standby sleep states (ACPI C-States/D-States) or dynamic power capping for decommissioned nodes.`,
        potentialConsequences: `Vast squandering of power capacity, unnecessary wear and tear on server fans and VRMs, stranded datacenter capacity, and bloated carbon footprint.`,
        status: 'open',
      });
    } else if (record.idlePowerPct > THRESHOLDS.IDLE_POWER.warning) {
      troubles.push({
        id: `tr-${datasetId}-${index}-idle-warn`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: record.rackId || 'Compute Fleet',
        category: 'IDLE_SERVER_POWER',
        categoryLabel: 'Idle Server Inefficiency',
        metricName: 'Idle Server Power Draw',
        observedValue: Number(record.idlePowerPct.toFixed(1)),
        thresholdValue: THRESHOLDS.IDLE_POWER.warning,
        unit: '%',
        severity: 'warning',
        problemTitle: `Suboptimal Server Power Draw (${record.idlePowerPct.toFixed(1)}%)`,
        problemDescription: `Idle server power proportion is at ${record.idlePowerPct.toFixed(1)}% (exceeding 40% warning limit). Compute resources are lightly loaded but consuming baseline idle electricity.`,
        recommendedSolution: `Audit cluster autoscalers, schedule nocturnal batch jobs onto active nodes, and enable OS-level aggressive frequency governor powersave modes.`,
        potentialConsequences: `Persistent 15-25% waste of provisioned rack wattage and inflated energy bills without productive computational output.`,
        status: 'open',
      });
    }

    // 4. Grid Instability & Renewable Intermittency (Grid THD)
    if (record.gridThd > THRESHOLDS.GRID_THD.critical) {
      troubles.push({
        id: `tr-${datasetId}-${index}-thd-crit`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: 'Utility Switchgear / Substations',
        category: 'GRID_INSTABILITY',
        categoryLabel: 'Grid Instability & Renewable Intermittency',
        metricName: 'Grid THD (Total Harmonic Distortion)',
        observedValue: Number(record.gridThd.toFixed(2)),
        thresholdValue: THRESHOLDS.GRID_THD.critical,
        unit: '%',
        severity: 'critical',
        problemTitle: `Severe Power Quality Anomaly - High Harmonic Distortion (${record.gridThd.toFixed(2)}%)`,
        problemDescription: `Utility grid Total Harmonic Distortion (THD) has reached ${record.gridThd.toFixed(2)}%, breaching the 10.0% critical threshold. Non-linear server switched-mode power supplies or erratic renewable solar/wind inverter synchronization are corrupting the AC sinusoidal waveform.`,
        recommendedSolution: `1. Immediately energize Active Harmonic Filters (AHF) and verify Static Transfer Switch (STS) health.\n2. If grid fluctuations persist, safely transfer non-critical circuits to double-conversion online UPS battery/flywheel topology.\n3. Coordinate with electrical utility to isolate local capacitor bank resonance.`,
        potentialConsequences: `Transformer neutral conductor overheating, capacitor dielectric breakdown, false breaker tripping, UPS inverter desynchronization, and server PSU hardware burnout.`,
        status: 'open',
      });
    } else if (record.gridThd > THRESHOLDS.GRID_THD.warning) {
      troubles.push({
        id: `tr-${datasetId}-${index}-thd-warn`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: 'Utility Switchgear / Substations',
        category: 'GRID_INSTABILITY',
        categoryLabel: 'Grid Instability & Renewable Intermittency',
        metricName: 'Grid THD (Total Harmonic Distortion)',
        observedValue: Number(record.gridThd.toFixed(2)),
        thresholdValue: THRESHOLDS.GRID_THD.warning,
        unit: '%',
        severity: 'warning',
        problemTitle: `Grid Harmonic Distortion Warning (${record.gridThd.toFixed(2)}%)`,
        problemDescription: `Grid THD is elevated at ${record.gridThd.toFixed(2)}% (above 5.0% IEEE 519 standard threshold). Voltage or current distortion threatens clean sinusoidal delivery to PDU transformers.`,
        recommendedSolution: `Check harmonic mitigating transformers (k-factor units) and verify that VFD drives on HVAC pumps have 5% DC link chokes enabled.`,
        potentialConsequences: `Accelerated transformer insulation degradation, acoustic hum vibration, and minor motor heating in chiller plant.`,
        status: 'open',
      });
    }

    // 5. High Temperature / HVAC Stress (Server Inlet Temp)
    if (record.serverInletTemp > THRESHOLDS.INLET_TEMP.critical) {
      troubles.push({
        id: `tr-${datasetId}-${index}-temp-crit`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: record.rackId ? `Rack ${record.rackId} (Front Intake)` : 'Server Cold Aisle',
        category: 'HVAC_STRESS',
        categoryLabel: 'High Temperature / HVAC Stress',
        metricName: 'Server Inlet Temperature',
        observedValue: Number(record.serverInletTemp.toFixed(1)),
        thresholdValue: THRESHOLDS.INLET_TEMP.critical,
        unit: '°C',
        severity: 'critical',
        problemTitle: `Hazardous Cold Aisle Thermal Spike (${record.serverInletTemp.toFixed(1)}°C)`,
        problemDescription: `Server inlet air temperature reached ${record.serverInletTemp.toFixed(1)}°C, far exceeding the ASHRAE Recommended & Allowable envelope (> 32.0°C critical threshold). Server fan tachometers are pegged at 100%, and processors face thermal throttling.`,
        recommendedSolution: `1. Ramp up standby CRAC/CRAH fan airflow and lower chilled water supply temperature by 2.0°C.\n2. Inspect for blocked perforated floor tiles or cold-aisle air curtain breaches.\n3. Shift high-intensity computational workloads off affected rack rows to cooler physical zones.`,
        potentialConsequences: `Immediate CPU/GPU thermal frequency downclocking (50%+ throughput collapse), server thermal emergency shutdown trips, silicone degradation, and violation of customer uptime SLAs.`,
        status: 'open',
      });
    } else if (record.serverInletTemp > THRESHOLDS.INLET_TEMP.warning) {
      troubles.push({
        id: `tr-${datasetId}-${index}-temp-warn`,
        recordId: record.id,
        datasetId,
        timestamp: timeStr,
        facility: record.facility,
        rackOrTenant: record.rackId ? `Rack ${record.rackId} (Front Intake)` : 'Server Cold Aisle',
        category: 'HVAC_STRESS',
        categoryLabel: 'High Temperature / HVAC Stress',
        metricName: 'Server Inlet Temperature',
        observedValue: Number(record.serverInletTemp.toFixed(1)),
        thresholdValue: THRESHOLDS.INLET_TEMP.warning,
        unit: '°C',
        severity: 'warning',
        problemTitle: `Elevated Server Intake Air Temp (${record.serverInletTemp.toFixed(1)}°C)`,
        problemDescription: `Inlet air temperature is measured at ${record.serverInletTemp.toFixed(1)}°C, entering the caution threshold (> 27.0°C). Airflow recirculation or hot-aisle air backdrafting is occurring.`,
        recommendedSolution: `Check blanking panels in empty rack U spaces to prevent hot air recirculation and increase underfloor static air pressure.`,
        potentialConsequences: `Internal server fans running at 70-85% RPM causing acoustic noise and secondary parasitic power drain; diminished thermal buffer during peak loads.`,
        status: 'open',
      });
    }

    // 6. Tenant Resource Overuse (Storage, Power, Temp, Network)
    if (record.tenantId) {
      // 6a. Tenant Storage Overuse
      if (record.tenantStoragePct !== undefined) {
        if (record.tenantStoragePct > THRESHOLDS.TENANT_STORAGE.critical) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-storage-crit`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId}`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Storage Utilization',
            observedValue: Number(record.tenantStoragePct.toFixed(1)),
            thresholdValue: THRESHOLDS.TENANT_STORAGE.critical,
            unit: '%',
            severity: 'critical',
            problemTitle: `Critical Storage Exhaustion - Tenant ${record.tenantId} (${record.tenantStoragePct.toFixed(1)}%)`,
            problemDescription: `Tenant ${record.tenantId} has consumed ${record.tenantStoragePct.toFixed(1)}% of their provisioned SAN/NAS storage quota, surpassing the 95% emergency threshold. Disk read-only locking is imminent.`,
            recommendedSolution: `Trigger emergency automated tier expansion or request tenant clear transient log volumes, tmp caches, and purge stale snapshot backups immediately.`,
            potentialConsequences: `Database I/O freeze, corrupted transaction journals, failed container volume mounts, and service outages for tenant applications.`,
            status: 'open',
          });
        } else if (record.tenantStoragePct > THRESHOLDS.TENANT_STORAGE.warning) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-storage-warn`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId}`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Storage Utilization',
            observedValue: Number(record.tenantStoragePct.toFixed(1)),
            thresholdValue: THRESHOLDS.TENANT_STORAGE.warning,
            unit: '%',
            severity: 'warning',
            problemTitle: `Storage Quota Approaching Limit - Tenant ${record.tenantId} (${record.tenantStoragePct.toFixed(1)}%)`,
            problemDescription: `Storage usage is at ${record.tenantStoragePct.toFixed(1)}%, exceeding the 90% warning mark.`,
            recommendedSolution: `Issue tenant automated threshold notification and recommend provisioning additional block storage capacity.`,
            potentialConsequences: `Risk of abrupt storage saturation during scheduled database maintenance or database dumps.`,
            status: 'open',
          });
        }
      }

      // 6b. Tenant Power Overuse
      if (record.tenantPowerKw !== undefined) {
        const limit = record.tenantPowerLimitKw || 10.0;
        const usagePct = (record.tenantPowerKw / limit) * 100;
        if (usagePct > THRESHOLDS.TENANT_POWER_USAGE_PCT.critical) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-power-crit`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId} (Rack PDU)`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Rack Power Draw',
            observedValue: `${record.tenantPowerKw.toFixed(1)} kW (${usagePct.toFixed(0)}%)`,
            thresholdValue: `${limit.toFixed(1)} kW (100%)`,
            unit: 'kW',
            severity: 'critical',
            problemTitle: `Breaker Trip Hazard - Tenant ${record.tenantId} Exceeding Contracted Power`,
            problemDescription: `Tenant ${record.tenantId} is drawing ${record.tenantPowerKw.toFixed(1)} kW against their contracted maximum of ${limit.toFixed(1)} kW (${usagePct.toFixed(0)}% utilization). PDU branch circuit breakers are at immediate risk of thermal trip.`,
            recommendedSolution: `1. Enforce dynamic CPU power capping on tenant rack blades via IPMI.\n2. Notify tenant NOC to reschedule concurrent AI training or compute-heavy jobs.\n3. Dispatch technician to verify branch circuit amp clamp readings.`,
            potentialConsequences: `Physical PDU circuit breaker trip shutting down the entire tenant cabinet, cascading failover overload on adjacent circuits, and contractual penalties.`,
            status: 'open',
          });
        } else if (usagePct > THRESHOLDS.TENANT_POWER_USAGE_PCT.warning) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-power-warn`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId} (Rack PDU)`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Rack Power Draw',
            observedValue: `${record.tenantPowerKw.toFixed(1)} kW (${usagePct.toFixed(0)}%)`,
            thresholdValue: `${(limit * 0.9).toFixed(1)} kW (90%)`,
            unit: 'kW',
            severity: 'warning',
            problemTitle: `High Power Demand - Tenant ${record.tenantId} (${usagePct.toFixed(0)}% Quota)`,
            problemDescription: `Rack power is at ${record.tenantPowerKw.toFixed(1)} kW, surpassing 90% of allocated limit (${limit} kW).`,
            recommendedSolution: `Advise tenant to review workload schedules or upgrade rack density tier to 15kW/rack specification.`,
            potentialConsequences: `Thermal hotspots in tenant cabinet and vulnerability to tripping during utility voltage sags.`,
            status: 'open',
          });
        }
      }

      // 6c. Tenant Rack Temperature
      if (record.tenantTempC !== undefined) {
        if (record.tenantTempC > THRESHOLDS.TENANT_TEMP.critical) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-temp-crit`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId}`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Dedicated Rack Temp',
            observedValue: Number(record.tenantTempC.toFixed(1)),
            thresholdValue: THRESHOLDS.TENANT_TEMP.critical,
            unit: '°C',
            severity: 'critical',
            problemTitle: `Critical Cabinet Hotspot - Tenant ${record.tenantId} (${record.tenantTempC.toFixed(1)}°C)`,
            problemDescription: `Cabinet sensor reports ${record.tenantTempC.toFixed(1)}°C (critical threshold: 32°C). High rack power density has overwhelmed localized passive airflow.`,
            recommendedSolution: `Deploy temporary top-of-rack spot fan extractor or reposition high-wattage 2U GPU nodes to lower rack slots with higher static pressure.`,
            potentialConsequences: `Equipment failure, accelerated NVMe drive error rates, and tenant warranty voidance.`,
            status: 'open',
          });
        } else if (record.tenantTempC > THRESHOLDS.TENANT_TEMP.warning) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-temp-warn`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId}`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Dedicated Rack Temp',
            observedValue: Number(record.tenantTempC.toFixed(1)),
            thresholdValue: THRESHOLDS.TENANT_TEMP.warning,
            unit: '°C',
            severity: 'warning',
            problemTitle: `Elevated Cabinet Temp - Tenant ${record.tenantId} (${record.tenantTempC.toFixed(1)}°C)`,
            problemDescription: `Cabinet temperature is measured at ${record.tenantTempC.toFixed(1)}°C (threshold: 28°C).`,
            recommendedSolution: `Inspect rack door perforation cleanliness and verify rack rear exhaust clearance is unobstructed.`,
            potentialConsequences: `Elevated fan power draw and progressive thermal build-up.`,
            status: 'open',
          });
        }
      }

      // 6d. Tenant Network Overuse
      if (record.tenantBandwidthGbps !== undefined) {
        const portLimit = record.tenantBandwidthLimitGbps || 40.0;
        const bwPct = (record.tenantBandwidthGbps / portLimit) * 100;
        if (bwPct > THRESHOLDS.TENANT_NETWORK_USAGE_PCT.critical) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-net-crit`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId} (Uplink)`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Uplink Bandwidth',
            observedValue: `${record.tenantBandwidthGbps.toFixed(1)} Gbps (${bwPct.toFixed(0)}%)`,
            thresholdValue: `${portLimit.toFixed(1)} Gbps (98%)`,
            unit: 'Gbps',
            severity: 'critical',
            problemTitle: `Network Uplink Saturation - Tenant ${record.tenantId} (${bwPct.toFixed(0)}%)`,
            problemDescription: `Uplink bandwidth consumed is ${record.tenantBandwidthGbps.toFixed(1)} Gbps against provisioned ${portLimit.toFixed(1)} Gbps port limit (> 98% saturation). Packet drops and tail latency spikes are occurring.`,
            recommendedSolution: `1. Enforce QoS traffic shaping to throttle non-essential backup sync streams.\n2. Engage secondary LACP trunk member or configure BGP multipath.\n3. Inquire tenant if uncharacteristic ingress/egress is indicative of a DDoS attack.`,
            potentialConsequences: `Severe packet loss (3-15%), API timeout errors, jitter, and impact on shared Top-of-Rack (ToR) switch buffer queues.`,
            status: 'open',
          });
        } else if (bwPct > THRESHOLDS.TENANT_NETWORK_USAGE_PCT.warning) {
          troubles.push({
            id: `tr-${datasetId}-${index}-tenant-net-warn`,
            recordId: record.id,
            datasetId,
            timestamp: timeStr,
            facility: record.facility,
            rackOrTenant: `Tenant: ${record.tenantId} (Uplink)`,
            category: 'TENANT_OVERUSE',
            categoryLabel: 'Tenant Resource Overuse',
            metricName: 'Tenant Uplink Bandwidth',
            observedValue: `${record.tenantBandwidthGbps.toFixed(1)} Gbps (${bwPct.toFixed(0)}%)`,
            thresholdValue: `${(portLimit * 0.9).toFixed(1)} Gbps (90%)`,
            unit: 'Gbps',
            severity: 'warning',
            problemTitle: `High Network Throughput - Tenant ${record.tenantId} (${bwPct.toFixed(0)}%)`,
            problemDescription: `Uplink bandwidth is at ${record.tenantBandwidthGbps.toFixed(1)} Gbps (> 90% allocation limit).`,
            recommendedSolution: `Monitor switch port egress queues for microbursts and propose bandwidth expansion to tenant engineering.`,
            potentialConsequences: `Intermittent latency spikes for real-time web services during burst traffic.`,
            status: 'open',
          });
        }
      }
    }
  });

  const criticalCount = troubles.filter((t) => t.severity === 'critical').length;
  const warningCount = troubles.filter((t) => t.severity === 'warning').length;
  const totalAnalyzedChecks = Math.max(records.length * 6, 1);
  const healthyCount = Math.max(0, totalAnalyzedChecks - (criticalCount + warningCount));

  // Health Score: 100 base, minus 12 per critical, minus 4 per warning (clamped to 5-100)
  const healthScore = Math.max(5, Math.min(100, Math.round(100 - criticalCount * 12 - warningCount * 4)));

  return {
    troubles,
    criticalCount,
    warningCount,
    healthyCount,
    healthScore,
  };
}
