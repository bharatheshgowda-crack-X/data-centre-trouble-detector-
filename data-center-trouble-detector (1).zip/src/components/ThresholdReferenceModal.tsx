import React from 'react';
import { AlertTriangle, CheckCircle, Flame, Gauge, Info, Server, ShieldAlert, Waves, X, Zap } from 'lucide-react';
import { THRESHOLDS } from '../utils/detectionEngine';

interface ThresholdReferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ThresholdReferenceModal: React.FC<ThresholdReferenceModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 p-5 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Data Center Trouble Detection Standards</h2>
              <p className="text-xs text-slate-400">
                Engine threshold rules calibrated to ASHRAE TC 9.9, IEEE 519, and Green Grid specifications
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 1. PUE */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm flex items-center">
                  <Gauge className="w-4 h-4 text-cyan-400 mr-2" />
                  1. Power Usage Effectiveness (PUE)
                </span>
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
                  Total Energy / IT Energy
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Measures the multiplier of total facility energy consumed relative to IT workload. Baseline ideal is 1.1 - 1.2.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
                <div className="p-2 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300">
                  <div className="text-[10px] uppercase font-bold text-amber-400">Warning</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.PUE.warning}</div>
                </div>
                <div className="p-2 rounded bg-red-950/40 border border-red-800/40 text-red-300">
                  <div className="text-[10px] uppercase font-bold text-red-400">Critical</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.PUE.critical}</div>
                </div>
              </div>
            </div>

            {/* 2. WUE */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm flex items-center">
                  <Waves className="w-4 h-4 text-blue-400 mr-2" />
                  2. Water Usage Effectiveness (WUE)
                </span>
                <span className="text-[10px] font-mono bg-blue-950 text-blue-300 px-2 py-0.5 rounded border border-blue-800">
                  Liters / kWh
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Liters of cooling tower water evaporated or discharged per kilowatt-hour of IT energy consumed.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
                <div className="p-2 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300">
                  <div className="text-[10px] uppercase font-bold text-amber-400">Warning</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.WUE.warning} L/kWh</div>
                </div>
                <div className="p-2 rounded bg-red-950/40 border border-red-800/40 text-red-300">
                  <div className="text-[10px] uppercase font-bold text-red-400">Critical</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.WUE.critical} L/kWh</div>
                </div>
              </div>
            </div>

            {/* 3. Idle Server */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm flex items-center">
                  <Server className="w-4 h-4 text-purple-400 mr-2" />
                  3. Idle Server Inefficiency
                </span>
                <span className="text-[10px] font-mono bg-purple-950 text-purple-300 px-2 py-0.5 rounded border border-purple-800">
                  % of Server Draw
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Proportion of electric power consumed by servers with zero or baseline compute tasks (ghost servers).
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
                <div className="p-2 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300">
                  <div className="text-[10px] uppercase font-bold text-amber-400">Warning</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.IDLE_POWER.warning}%</div>
                </div>
                <div className="p-2 rounded bg-red-950/40 border border-red-800/40 text-red-300">
                  <div className="text-[10px] uppercase font-bold text-red-400">Critical</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.IDLE_POWER.critical}%</div>
                </div>
              </div>
            </div>

            {/* 4. Grid THD */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm flex items-center">
                  <Zap className="w-4 h-4 text-amber-400 mr-2" />
                  4. Grid THD & Intermittency
                </span>
                <span className="text-[10px] font-mono bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800">
                  Total Harmonic Distortion %
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Waveform distortion from utility grid or renewable solar/wind inverters affecting UPS and transformers.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
                <div className="p-2 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300">
                  <div className="text-[10px] uppercase font-bold text-amber-400">Warning</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.GRID_THD.warning}%</div>
                </div>
                <div className="p-2 rounded bg-red-950/40 border border-red-800/40 text-red-300">
                  <div className="text-[10px] uppercase font-bold text-red-400">Critical</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.GRID_THD.critical}%</div>
                </div>
              </div>
            </div>

            {/* 5. Server Inlet Temp */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm flex items-center">
                  <Flame className="w-4 h-4 text-rose-400 mr-2" />
                  5. Server Inlet Temp / HVAC Stress
                </span>
                <span className="text-[10px] font-mono bg-rose-950 text-rose-300 px-2 py-0.5 rounded border border-rose-800">
                  ASHRAE A1-A4 (°C)
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Front chassis intake air temperature entering compute nodes. Exceeding risks thermal throttle.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
                <div className="p-2 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300">
                  <div className="text-[10px] uppercase font-bold text-amber-400">Warning</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.INLET_TEMP.warning}°C</div>
                </div>
                <div className="p-2 rounded bg-red-950/40 border border-red-800/40 text-red-300">
                  <div className="text-[10px] uppercase font-bold text-red-400">Critical</div>
                  <div className="font-bold text-sm">&gt; {THRESHOLDS.INLET_TEMP.critical}°C</div>
                </div>
              </div>
            </div>

            {/* 6. Tenant Resource Overuse */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm flex items-center">
                  <ShieldAlert className="w-4 h-4 text-emerald-400 mr-2" />
                  6. Tenant Resource Overuse
                </span>
                <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                  Storage, Power, Temp, Net
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Guards against tenant quota exhaustion, rack breaker trip, and bandwidth saturation.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-slate-300 pt-1">
                <div className="flex justify-between">
                  <span>Storage:</span>
                  <span className="text-amber-400">&gt; 90% Warn</span>
                  <span className="text-red-400">&gt; 95% Crit</span>
                </div>
                <div className="flex justify-between">
                  <span>Power Draw:</span>
                  <span className="text-amber-400">&gt; 90% Allocated</span>
                  <span className="text-red-400">&gt; 100% Breaker Risk</span>
                </div>
                <div className="flex justify-between">
                  <span>Cabinet Temp:</span>
                  <span className="text-amber-400">&gt; 28°C Warn</span>
                  <span className="text-red-400">&gt; 32°C Crit</span>
                </div>
                <div className="flex justify-between">
                  <span>Network Uplink:</span>
                  <span className="text-amber-400">&gt; 90% Saturation</span>
                  <span className="text-red-400">&gt; 98% Drops</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60 flex items-start space-x-3 text-xs text-slate-300">
            <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block mb-0.5">Automated Remediation Engine Active</strong>
              Whenever an ingested CSV contains row values crossing these bounds, the system creates structured trouble tickets detailing the root fault, recommended engineering remedy, and business consequence if unmitigated.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Close Reference
          </button>
        </div>
      </div>
    </div>
  );
};
