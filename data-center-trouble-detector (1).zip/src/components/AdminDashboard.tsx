import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowDownToLine,
  CheckCircle2,
  Clock,
  Database,
  Filter,
  Flame,
  Gauge,
  KeyRound,
  Mail,
  RefreshCw,
  Search,
  Server,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  Waves,
  Zap,
} from 'lucide-react';
import {
  ActivityLog,
  BackendNotificationRecord,
  DetectedTrouble,
  EmailDeliveryStatus,
  UploadDataset,
  User,
} from '../types';
import {
  fetchBackendNotificationHistory,
  fetchEmailServerConfig,
  fetchEmailStatusesBatch,
  retryIncidentEmailNotification,
} from '../utils/emailService';
import {
  getActivityLogs,
  getDatasets,
  getUsers,
  logActivity,
  updateTroubleStatus,
} from '../utils/storage';
import { ActionModal } from './ActionModal';
import { EmailAlertModal } from './EmailAlertModal';
import { EmailSettingsModal } from './EmailSettingsModal';
import { TelemetryCharts } from './TelemetryCharts';
import { UserManagementModal } from './UserManagementModal';

interface AdminDashboardProps {
  currentUser: User;
  onOpenThresholds: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  onOpenThresholds,
}) => {
  const [activeTab, setActiveTab] = useState<
    'alerts' | 'activities' | 'datasets' | 'analytics' | 'emails'
  >('alerts');
  const [datasets, setDatasets] = useState<UploadDataset[]>(getDatasets());
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(getActivityLogs());
  const [userList, setUserList] = useState<User[]>(getUsers());

  // Email Notification Integration State
  const [emailStatuses, setEmailStatuses] = useState<Record<string, BackendNotificationRecord>>({});
  const [emailHistory, setEmailHistory] = useState<BackendNotificationRecord[]>([]);
  const [emailConfig, setEmailConfig] = useState<{
    configured: boolean;
    provider: 'Resend' | 'SendGrid' | 'None';
    from: string;
  }>({
    configured: false,
    provider: 'None',
    from: '',
  });
  const [retryingIncidentId, setRetryingIncidentId] = useState<string | null>(null);
  const [emailNotice, setEmailNotice] = useState<string | null>(null);

  // Filters for alerts
  const [severityFilter, setSeverityFilter] = useState<'all' | 'critical' | 'warning'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'in_progress' | 'resolved'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Activity log filter
  const [activityFilter, setActivityFilter] = useState<string>('all');

  // Modals
  const [selectedTrouble, setSelectedTrouble] = useState<DetectedTrouble | null>(null);
  const [emailTrouble, setEmailTrouble] = useState<DetectedTrouble | null>(null);
  const [isEmailSettingsOpen, setIsEmailSettingsOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);

  // Compile all troubles across all datasets
  const allTroubles: DetectedTrouble[] = datasets.flatMap((ds) => ds.troubles);

  // Sync email statuses and history from server
  const syncEmailData = async (troublesList: DetectedTrouble[]) => {
    try {
      const cfg = await fetchEmailServerConfig();
      setEmailConfig(cfg);
      const history = await fetchBackendNotificationHistory();
      setEmailHistory(history);
      const ids = troublesList.map((t) => t.id);
      if (ids.length > 0) {
        const statuses = await fetchEmailStatusesBatch(ids);
        setEmailStatuses(statuses);
      }
    } catch (e) {
      console.warn('Failed to sync email records:', e);
    }
  };

  useEffect(() => {
    syncEmailData(allTroubles);
  }, []);

  // Safe retry handler
  const handleRetryEmail = async (incidentId: string) => {
    setRetryingIncidentId(incidentId);
    setEmailNotice(null);
    try {
      const res = await retryIncidentEmailNotification(incidentId);
      if (res.success) {
        setEmailNotice(`✅ Email successfully dispatched for Incident ${incidentId}.`);
      } else {
        setEmailNotice(`⚠️ Email retry recorded: ${res.error || 'Failed to dispatch'}`);
      }
      refreshData();
    } catch (err: any) {
      setEmailNotice(`❌ Retry error: ${err.message}`);
    } finally {
      setRetryingIncidentId(null);
    }
  };

  // Refresh data
  const refreshData = () => {
    const updatedDatasets = getDatasets();
    setDatasets(updatedDatasets);
    setActivityLogs(getActivityLogs());
    setUserList(getUsers());
    const updatedTroubles = updatedDatasets.flatMap((ds) => ds.troubles);
    syncEmailData(updatedTroubles);
  };

  // Filtered troubles
  const filteredTroubles = allTroubles.filter((t) => {
    if (severityFilter !== 'all' && t.severity !== severityFilter) return false;
    if (statusFilter !== 'all' && t.status !== statusFilter) return false;
    if (categoryFilter !== 'all' && t.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.problemTitle.toLowerCase().includes(q) ||
        t.facility.toLowerCase().includes(q) ||
        t.rackOrTenant.toLowerCase().includes(q) ||
        t.metricName.toLowerCase().includes(q) ||
        t.recommendedSolution.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Filtered activities
  const filteredActivities = activityLogs.filter((a) => {
    if (activityFilter === 'all') return true;
    return a.actionType === activityFilter;
  });

  // Calculate Global KPIs
  const totalDatasets = datasets.length;
  const totalAlerts = allTroubles.length;
  const criticalCount = allTroubles.filter((t) => t.severity === 'critical').length;
  const warningCount = allTroubles.filter((t) => t.severity === 'warning').length;
  const openCount = allTroubles.filter((t) => t.status === 'open').length;
  const inProgressCount = allTroubles.filter((t) => t.status === 'in_progress').length;
  const resolvedCount = allTroubles.filter((t) => t.status === 'resolved').length;
  const totalCustomers = userList.filter((u) => u.role === 'customer').length;

  const handleStatusChange = (
    troubleId: string,
    status: 'open' | 'in_progress' | 'resolved',
    note: string
  ) => {
    updateTroubleStatus(troubleId, status, note, currentUser);
    refreshData();
  };

  // Export Audit Logs as CSV
  const exportActivityCSV = () => {
    const headers = ['Timestamp', 'Action', 'User Name', 'User Email', 'Role', 'Severity', 'Details'];
    const rows = activityLogs.map((a) => [
      a.timestamp,
      a.actionType,
      `"${a.userName}"`,
      a.userEmail,
      a.userRole,
      a.severity,
      `"${a.details.replace(/"/g, '""')}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `DataCenter_Audit_Log_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    logActivity({
      userId: currentUser.id,
      userEmail: currentUser.email,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'EXPORT_REPORT',
      details: `Administrator exported complete activity audit trail (${activityLogs.length} entries).`,
      severity: 'info',
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Admin Identity Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 border border-amber-900/50 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center shadow-lg shadow-amber-950/50 shrink-0">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">
                ROOT COMMAND & AUDIT CONSOLE
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-800">
                FULL PERMISSIONS
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">
              Welcome, Administrator {currentUser.name}
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Active monitoring across <strong className="text-slate-200">{datasets.length} facility datasets</strong>,{' '}
              <strong className="text-slate-200">{totalCustomers} registered client organizations</strong>.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsEmailSettingsOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm"
            title="Configure automated email notifications and recipients"
          >
            <Mail className="w-4 h-4 text-cyan-400" />
            <span>Email Alerts Config</span>
          </button>

          <button
            onClick={() => setIsUserModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center space-x-2 shadow-lg shadow-amber-900/40 transition-all"
          >
            <Users className="w-4 h-4" />
            <span>Manage System Users</span>
          </button>

          <button
            onClick={refreshData}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors"
            title="Refresh System Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5 sm:gap-4">
        {/* Critical Alerts */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-red-900/40 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>CRITICAL FAULTS</span>
            <ShieldAlert className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-red-400 mt-2 font-mono">
            {criticalCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-red-400 mr-1.5"></span>
            Breaches SLA thresholds
          </div>
        </div>

        {/* Warnings */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-900/40 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>WARNING ALERTS</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-400 mt-2 font-mono">
            {warningCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Nearing critical ceiling</div>
        </div>

        {/* Open Incidents */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>PENDING MITIGATION</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-cyan-400 mt-2 font-mono">
            {openCount + inProgressCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">{resolvedCount} resolved tickets</div>
        </div>

        {/* Activity Logs */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>AUDITED ACTIONS</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white mt-2 font-mono">
            {activityLogs.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">All user actions recorded</div>
        </div>

        {/* Users */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>REGISTERED USERS</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-purple-400 mt-2 font-mono">
            {userList.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {userList.filter((u) => u.status === 'active').length} active operators
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="border-b border-slate-800 flex items-center space-x-1 sm:space-x-3 text-xs sm:text-sm font-medium overflow-x-auto">
        <button
          onClick={() => setActiveTab('alerts')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'alerts'
              ? 'border-amber-400 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>System Alerts ({allTroubles.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('activities')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'activities'
              ? 'border-amber-400 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>User Activity Audit Trail ({activityLogs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('datasets')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'datasets'
              ? 'border-amber-400 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Facility Ingestions ({datasets.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'analytics'
              ? 'border-amber-400 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Gauge className="w-4 h-4" />
          <span>Telemetry Charts & Trends</span>
        </button>

        <button
          onClick={() => setActiveTab('emails')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'emails'
              ? 'border-amber-400 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Mail className="w-4 h-4" />
          <span>Customer Email Notifications ({emailHistory.length})</span>
          {emailConfig.configured ? (
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
              {emailConfig.provider} Active
            </span>
          ) : (
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-800">
              Key Required
            </span>
          )}
        </button>
      </div>

      {/* TAB 1: ALL SYSTEM ALERTS FROM CSV ANALYSIS */}
      {activeTab === 'alerts' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search across all alerts by facility, rack, problem, or mitigation..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Severity filter */}
              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 focus:outline-none"
              >
                <option value="all">All Severities</option>
                <option value="critical">Critical Only</option>
                <option value="warning">Warning Only</option>
              </select>

              {/* Status filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
              </select>

              {/* Category filter */}
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 focus:outline-none"
              >
                <option value="all">All Anomaly Types</option>
                <option value="PUE_EFFICIENCY">Excessive Power / PUE</option>
                <option value="WUE_COOLING">Cooling Water (WUE)</option>
                <option value="IDLE_SERVER_POWER">Idle Server Inefficiency</option>
                <option value="GRID_INSTABILITY">Grid Instability / THD</option>
                <option value="HVAC_STRESS">HVAC / Inlet Temp</option>
                <option value="TENANT_OVERUSE">Tenant Quota Overuse</option>
              </select>
            </div>
          </div>

          {/* Alerts List */}
          {filteredTroubles.length === 0 ? (
            <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
              <h3 className="text-base font-bold text-white">No Matching System Alerts</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                All data center telemetry is within calibrated safety thresholds or no incidents match current filter.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3.5">
              {filteredTroubles.map((trouble) => {
                const isCrit = trouble.severity === 'critical';
                return (
                  <div
                    key={trouble.id}
                    className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                      isCrit
                        ? 'bg-slate-900/95 border-red-900/60 hover:border-red-600/80 shadow-lg shadow-red-950/20'
                        : 'bg-slate-900/95 border-amber-900/60 hover:border-amber-600/80 shadow-lg shadow-amber-950/20'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider font-mono ${
                            isCrit
                              ? 'bg-red-950 text-red-400 border border-red-800 animate-pulse'
                              : 'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}
                        >
                          {trouble.severity}
                        </span>
                        <span className="text-xs font-semibold text-slate-300 font-mono">
                          {trouble.facility} • {trouble.rackOrTenant}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {new Date(trouble.timestamp).toLocaleTimeString()}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {/* Small Email Notification Status field */}
                        {(() => {
                          const notif = emailStatuses[trouble.id];
                          const emailStatus: EmailDeliveryStatus = notif?.status || 'Pending';
                          return (
                            <div
                              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${
                                emailStatus === 'Sent'
                                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                                  : emailStatus === 'Failed'
                                  ? 'bg-red-950/80 text-red-300 border-red-800'
                                  : 'bg-amber-950/80 text-amber-300 border-amber-800'
                              }`}
                              title={
                                notif
                                  ? `Status: ${notif.status} (${notif.provider}) • Recipient: ${notif.customerEmail}${
                                      notif.error ? ` • Error: ${notif.error}` : ''
                                    }`
                                  : 'Email delivery pending or in queue'
                              }
                            >
                              <span className="text-slate-400 font-sans">Email:</span>
                              {emailStatus === 'Sent' ? (
                                <span className="font-bold flex items-center space-x-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                  <span>Sent</span>
                                </span>
                              ) : emailStatus === 'Failed' ? (
                                <span className="font-bold flex items-center space-x-1">
                                  <AlertCircle className="w-3 h-3 text-red-400" />
                                  <span>Failed</span>
                                </span>
                              ) : (
                                <span className="font-bold flex items-center space-x-1">
                                  <Clock className="w-3 h-3 text-amber-400" />
                                  <span>Pending</span>
                                </span>
                              )}
                              {emailStatus === 'Failed' && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRetryEmail(trouble.id);
                                  }}
                                  disabled={retryingIncidentId === trouble.id}
                                  className="ml-1 text-[9px] px-1.5 py-0.5 rounded bg-red-900/90 hover:bg-red-800 text-white font-sans font-bold transition-all disabled:opacity-50"
                                  title="Retry dispatching email alert"
                                >
                                  {retryingIncidentId === trouble.id ? '...' : 'Retry'}
                                </button>
                              )}
                            </div>
                          );
                        })()}

                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono capitalize ${
                            trouble.status === 'resolved'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                              : trouble.status === 'in_progress'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                              : 'bg-red-950/80 text-red-300 border border-red-800'
                          }`}
                        >
                          {trouble.status.replace('_', ' ')}
                        </span>
                        <button
                          onClick={() => setEmailTrouble(trouble)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/60 text-xs font-semibold transition-colors flex items-center space-x-1"
                          title="Send email alert with recommendation to user"
                        >
                          <Mail className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Email Alert & Solution</span>
                        </button>
                        <button
                          onClick={() => setSelectedTrouble(trouble)}
                          className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors"
                        >
                          Review & Dispatch Fix
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                      {/* Metric & Title */}
                      <div className="md:col-span-2 space-y-1">
                        <h4 className="text-sm font-bold text-white flex items-center">
                          {trouble.problemTitle}
                        </h4>
                        <p className="text-slate-300 text-xs leading-relaxed">
                          {trouble.problemDescription}
                        </p>
                      </div>

                      {/* Measured vs Threshold */}
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono space-y-1">
                        <div className="text-[10px] text-slate-500 uppercase">Measured Value</div>
                        <div
                          className={`text-base font-bold ${
                            isCrit ? 'text-red-400' : 'text-amber-400'
                          }`}
                        >
                          {trouble.observedValue} {trouble.unit}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Threshold: &gt; {trouble.thresholdValue} {trouble.unit}
                        </div>
                      </div>

                      {/* Recommended Action preview */}
                      <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-[11px] space-y-1">
                        <div className="text-[10px] uppercase font-bold text-cyan-400">
                          Recommended Remedy
                        </div>
                        <p className="text-cyan-200 line-clamp-3 leading-tight">
                          {trouble.recommendedSolution}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: COMPLETE USER ACTIVITIES AUDIT TRAIL */}
      {activeTab === 'activities' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-white">Filter Action Type:</span>
              <select
                value={activityFilter}
                onChange={(e) => setActivityFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-300 focus:outline-none font-mono"
              >
                <option value="all">All Actions ({activityLogs.length})</option>
                <option value="LOGIN">LOGIN</option>
                <option value="UPLOAD_CSV">UPLOAD_CSV</option>
                <option value="DETECTION_ALERT">DETECTION_ALERT</option>
                <option value="APPLY_SOLUTION">APPLY_SOLUTION</option>
                <option value="RESOLVE_ALERT">RESOLVE_ALERT</option>
                <option value="MANAGE_USER">MANAGE_USER</option>
                <option value="REGISTER">REGISTER</option>
              </select>
            </div>

            <button
              onClick={exportActivityCSV}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all border border-slate-700"
            >
              <ArrowDownToLine className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export Audit Trail (CSV)</span>
            </button>
          </div>

          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Timestamp (UTC)</th>
                    <th className="py-3 px-4">Operator / User</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Action Event</th>
                    <th className="py-3 px-4">Severity</th>
                    <th className="py-3 px-4">Activity Audit Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredActivities.map((act) => {
                    return (
                      <tr key={act.id} className="hover:bg-slate-950/40 transition-colors">
                        <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                          {act.timestamp.includes('T')
                            ? new Date(act.timestamp).toLocaleString()
                            : act.timestamp}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-semibold text-white font-sans">{act.userName}</div>
                          <div className="text-[10px] text-slate-500">{act.userEmail}</div>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              act.userRole === 'admin'
                                ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                            }`}
                          >
                            {act.userRole.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-bold text-slate-200">{act.actionType}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              act.severity === 'critical'
                                ? 'bg-red-950 text-red-400 border border-red-800'
                                : act.severity === 'warning'
                                ? 'bg-amber-950 text-amber-400 border border-amber-800'
                                : act.severity === 'success'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            {act.severity}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-sans text-slate-300 text-xs">
                          {act.details}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: INGESTED DATASETS HUB */}
      {activeTab === 'datasets' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {datasets.map((ds) => {
              return (
                <div
                  key={ds.id}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-cyan-400 truncate max-w-[180px]">
                      {ds.fileName}
                    </span>
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                        ds.healthScore > 80
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : ds.healthScore > 50
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-red-950 text-red-300 border border-red-800'
                      }`}
                    >
                      Health: {ds.healthScore}%
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-white">{ds.facility}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Ingested by <strong className="text-slate-300">{ds.uploadedByName}</strong> (
                      {ds.uploadedBy})
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center font-mono text-xs">
                    <div>
                      <div className="text-[10px] text-slate-500">ROWS</div>
                      <div className="font-bold text-white">{ds.rowCount}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-red-400">CRITICAL</div>
                      <div className="font-bold text-red-400">{ds.criticalCount}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-amber-400">WARNING</div>
                      <div className="font-bold text-amber-400">{ds.warningCount}</div>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-500 font-mono">
                    Timestamp: {new Date(ds.uploadedAt).toLocaleString()}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: TELEMETRY CHARTS & TRENDS */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          {datasets.length > 0 ? (
            <TelemetryCharts
              records={datasets[0].records}
              facilityName={datasets[0].facility}
            />
          ) : (
            <div className="p-12 text-center text-slate-400">No datasets available.</div>
          )}
        </div>
      )}

      {/* TAB 5: AUTOMATIC CUSTOMER EMAIL NOTIFICATION HISTORY */}
      {activeTab === 'emails' && (
        <div className="space-y-5">
          {/* Email notice message banner if active */}
          {emailNotice && (
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-between text-xs text-white">
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-cyan-400" />
                <span>{emailNotice}</span>
              </div>
              <button
                onClick={() => setEmailNotice(null)}
                className="text-slate-400 hover:text-white font-mono text-xs px-2 py-0.5"
              >
                ✕
              </button>
            </div>
          )}

          {/* Email Integration Status KPI Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span>TOTAL DISPATCHED</span>
                <Mail className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="text-2xl font-black text-cyan-400 mt-2 font-mono">
                {emailHistory.length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Logged delivery attempts</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span>DELIVERED (SENT)</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400 mt-2 font-mono">
                {emailHistory.filter((e) => e.status === 'Sent').length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Confirmed customer alerts</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span>FAILED / UNCONFIGURED</span>
                <AlertCircle className="w-4 h-4 text-red-400" />
              </div>
              <div className="text-2xl font-black text-red-400 mt-2 font-mono">
                {emailHistory.filter((e) => e.status === 'Failed').length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Retry available anytime</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span>ACTIVE PROVIDER</span>
                <Zap className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-lg font-black text-white mt-2 font-mono">
                {emailConfig.configured ? emailConfig.provider : 'Not Configured'}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {emailConfig.configured ? `From: ${emailConfig.from}` : 'Requires API Key'}
              </div>
            </div>
          </div>

          {/* Infrastructure Safety Disclaimer */}
          <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-900/40 text-xs flex items-start space-x-3 text-blue-200">
            <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-white uppercase text-[11px] font-mono">
                Infrastructure Protection & Safety Policy
              </div>
              <div className="text-slate-300 text-[11px] leading-relaxed mt-0.5">
                Automated customer emails supply verified metric diagnostics, threshold breaches, impact analyses, and AI-generated prescriptive remedies.
                <strong className="text-white"> In accordance with safety protocol, no infrastructure alterations (cooling adjustments, power tripping, or rack shutdowns) are executed automatically.</strong> All remediations require human engineer sign-off.
              </div>
            </div>
          </div>

          {/* Provider Setup Notice if unconfigured */}
          {!emailConfig.configured && (
            <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-900/50 text-xs space-y-2">
              <div className="flex items-center space-x-2 text-amber-300 font-bold font-mono">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Email Provider Setup Required for External Delivery</span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                The automatic email notification router is armed and captures all detected incidents. To send real outbound emails over SMTP/HTTP API, set the following environment variable in your server environment:
              </p>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px] text-amber-300 space-y-1">
                <div>RESEND_API_KEY="re_your_api_key_here"</div>
                <div>RESEND_FROM="alerts@datacenter-trouble.com" (or your verified domain sender)</div>
                <div className="text-slate-500 pt-1"># Alternatively with SendGrid:</div>
                <div className="text-slate-400">SENDGRID_API_KEY="SG.your_api_key_here"</div>
              </div>
              <p className="text-[11px] text-slate-400">
                Notice: The system does <strong className="text-slate-300">not</strong> simulate fake success. Delivery attempts without a key are honestly marked as <span className="text-red-400 font-mono">Failed</span> with full diagnostic logs and one-click retry once configured.
              </p>
            </div>
          )}

          {/* Notification History Table */}
          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div>
                <h3 className="font-bold text-white text-sm">Customer Email Notification Audit Trail</h3>
                <p className="text-[11px] text-slate-400">
                  Every automated anomaly dispatch, recipient address, delivery status, and retry attempt.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => refreshData()}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center space-x-1.5 border border-slate-700 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Refresh Log</span>
                </button>
              </div>
            </div>

            {emailHistory.length === 0 ? (
              <div className="p-12 text-center text-slate-400 space-y-2">
                <Mail className="w-8 h-8 text-slate-600 mx-auto" />
                <div className="text-sm font-semibold text-slate-300">No Email Notifications Dispatched Yet</div>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  When anomalies are identified during CSV ingestion, automated incident notifications are dispatched to the customer's verified email.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Timestamp (UTC)</th>
                      <th className="py-3 px-4">Incident ID</th>
                      <th className="py-3 px-4">Tenant / Target</th>
                      <th className="py-3 px-4">Recipient Customer Email</th>
                      <th className="py-3 px-4">Severity</th>
                      <th className="py-3 px-4">Problem Summary</th>
                      <th className="py-3 px-4">Delivery Status</th>
                      <th className="py-3 px-4">Provider / Attempts</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {emailHistory.map((item) => {
                      const isSent = item.status === 'Sent';
                      const isFailed = item.status === 'Failed';
                      return (
                        <tr key={item.id} className="hover:bg-slate-950/40 transition-colors">
                          <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                            {new Date(item.lastAttemptAt || item.createdAt).toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-cyan-400 font-bold whitespace-nowrap">
                            {item.incidentId}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span className="text-white font-sans font-semibold">
                              {item.customerName || item.tenantId || item.facility}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-300 whitespace-nowrap">
                            {item.customerEmail}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                item.severity === 'Critical'
                                  ? 'bg-red-950 text-red-400 border border-red-800'
                                  : item.severity === 'High'
                                  ? 'bg-amber-950 text-amber-400 border border-amber-800'
                                  : 'bg-blue-950 text-cyan-300 border border-blue-800'
                              }`}
                            >
                              {item.severity}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-sans text-slate-300 max-w-xs truncate" title={item.problemTitle}>
                            {item.problemTitle}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center space-x-1 w-fit ${
                                isSent
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : isFailed
                                  ? 'bg-red-950 text-red-300 border border-red-800'
                                  : 'bg-amber-950 text-amber-300 border border-amber-800'
                              }`}
                            >
                              {isSent ? (
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              ) : isFailed ? (
                                <AlertCircle className="w-3 h-3 text-red-400" />
                              ) : (
                                <Clock className="w-3 h-3 text-amber-400" />
                              )}
                              <span>{item.status}</span>
                            </span>
                            {item.error && (
                              <div className="text-[10px] text-red-400/90 font-mono mt-1 max-w-[200px] truncate" title={item.error}>
                                {item.error}
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                            <div>{item.provider}</div>
                            <div className="text-[10px] text-slate-500">
                              {item.attempts} attempt{item.attempts > 1 ? 's' : ''}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            {isFailed && (
                              <button
                                onClick={() => handleRetryEmail(item.incidentId)}
                                disabled={retryingIncidentId === item.incidentId}
                                className="px-2.5 py-1 rounded-lg bg-red-900/80 hover:bg-red-800 text-white font-sans text-[11px] font-semibold transition-colors disabled:opacity-50"
                              >
                                {retryingIncidentId === item.incidentId ? 'Retrying...' : 'Safe Retry'}
                              </button>
                            )}
                            {isSent && (
                              <span className="text-[11px] text-emerald-400 font-sans">Delivered</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Action / Detail Modal */}
      <ActionModal
        trouble={selectedTrouble}
        currentUser={currentUser}
        onClose={() => setSelectedTrouble(null)}
        onOpenEmail={(t) => setEmailTrouble(t)}
        onUpdateStatus={handleStatusChange}
      />

      {/* User Management Modal */}
      <UserManagementModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        currentUser={currentUser}
        onUsersUpdated={refreshData}
      />

      {/* Email Alert & Corrective Solution Modal */}
      <EmailAlertModal
        isOpen={!!emailTrouble}
        onClose={() => setEmailTrouble(null)}
        trouble={emailTrouble}
        facility={emailTrouble?.facility || 'Data Center Facility'}
        currentUser={currentUser}
        onEmailSent={refreshData}
      />

      {/* Email Notification Settings Modal */}
      <EmailSettingsModal
        isOpen={isEmailSettingsOpen}
        onClose={() => setIsEmailSettingsOpen(false)}
        currentUser={currentUser}
      />
    </div>
  );
};
