import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Flame,
  Gauge,
  Radio,
  Server,
  ShieldAlert,
  Waves,
  Zap,
} from 'lucide-react';
import { TelemetryRecord } from '../types';
import { THRESHOLDS } from '../utils/detectionEngine';

interface TelemetryChartsProps {
  records: TelemetryRecord[];
  facilityName: string;
}

export const TelemetryCharts: React.FC<TelemetryChartsProps> = ({ records, facilityName }) => {
  const [selectedMetric, setSelectedMetric] = useState<'pue' | 'temp' | 'thd' | 'idle' | 'wue'>('pue');

  if (!records || records.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500 font-mono text-xs border border-dashed border-slate-800 rounded-2xl">
        No telemetry records available to render charts.
      </div>
    );
  }

  // Calculate stats
  const pueVals = records.map((r) => r.pue);
  const avgPue = pueVals.reduce((a, b) => a + b, 0) / pueVals.length;
  const maxPue = Math.max(...pueVals);

  const tempVals = records.map((r) => r.serverInletTemp);
  const avgTemp = tempVals.reduce((a, b) => a + b, 0) / tempVals.length;
  const maxTemp = Math.max(...tempVals);

  const thdVals = records.map((r) => r.gridThd);
  const maxThd = Math.max(...thdVals);

  const wueVals = records.map((r) => r.wue);
  const maxWue = Math.max(...wueVals);

  const idleVals = records.map((r) => r.idlePowerPct);
  const maxIdle = Math.max(...idleVals);

  // SVG Chart Dimensions
  const width = 800;
  const height = 260;
  const padding = { top: 30, right: 30, bottom: 40, left: 50 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  // Render SVG Line Chart for selected metric
  const getMetricData = () => {
    switch (selectedMetric) {
      case 'pue':
        return {
          title: 'Power Usage Effectiveness (PUE) Telemetry Stream',
          unit: 'ratio',
          values: pueVals,
          warnLimit: THRESHOLDS.PUE.warning,
          critLimit: THRESHOLDS.PUE.critical,
          minScale: 1.0,
          maxScale: Math.max(2.1, maxPue * 1.05),
          lineColor: '#06b6d4',
          areaColor: 'rgba(6, 182, 212, 0.15)',
        };
      case 'temp':
        return {
          title: 'Server Intake Temperature (°C) / HVAC Airflow Envelope',
          unit: '°C',
          values: tempVals,
          warnLimit: THRESHOLDS.INLET_TEMP.warning,
          critLimit: THRESHOLDS.INLET_TEMP.critical,
          minScale: 18,
          maxScale: Math.max(38, maxTemp * 1.08),
          lineColor: '#f43f5e',
          areaColor: 'rgba(244, 63, 94, 0.15)',
        };
      case 'thd':
        return {
          title: 'Grid Total Harmonic Distortion (THD %) Waveform Quality',
          unit: '%',
          values: thdVals,
          warnLimit: THRESHOLDS.GRID_THD.warning,
          critLimit: THRESHOLDS.GRID_THD.critical,
          minScale: 0,
          maxScale: Math.max(14, maxThd * 1.1),
          lineColor: '#f59e0b',
          areaColor: 'rgba(245, 158, 11, 0.15)',
        };
      case 'idle':
        return {
          title: 'Idle Server Ghost Power Draw (%) Fleet Distribution',
          unit: '%',
          values: idleVals,
          warnLimit: THRESHOLDS.IDLE_POWER.warning,
          critLimit: THRESHOLDS.IDLE_POWER.critical,
          minScale: 0,
          maxScale: Math.max(75, maxIdle * 1.1),
          lineColor: '#a855f7',
          areaColor: 'rgba(168, 85, 247, 0.15)',
        };
      case 'wue':
        return {
          title: 'Cooling Water Usage Effectiveness (WUE L/kWh)',
          unit: 'L/kWh',
          values: wueVals,
          warnLimit: THRESHOLDS.WUE.warning,
          critLimit: THRESHOLDS.WUE.critical,
          minScale: 0,
          maxScale: Math.max(3.5, maxWue * 1.1),
          lineColor: '#3b82f6',
          areaColor: 'rgba(59, 130, 246, 0.15)',
        };
    }
  };

  const metricInfo = getMetricData();
  const n = records.length;
  const stepX = n > 1 ? chartW / (n - 1) : chartW;

  const getY = (val: number) => {
    const range = metricInfo.maxScale - metricInfo.minScale;
    const norm = (val - metricInfo.minScale) / (range || 1);
    return padding.top + chartH - Math.max(0, Math.min(chartH, norm * chartH));
  };

  const points = metricInfo.values.map((v, i) => ({
    x: padding.left + i * stepX,
    y: getY(v),
    val: v,
    label: records[i].rackId || `T-${i + 1}`,
    time: records[i].timestamp,
  }));

  const pathD = points.length > 0
    ? points.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`, '')
    : '';

  const areaD = points.length > 0
    ? `${pathD} L ${points[points.length - 1].x} ${padding.top + chartH} L ${points[0].x} ${padding.top + chartH} Z`
    : '';

  const warnY = getY(metricInfo.warnLimit);
  const critY = getY(metricInfo.critLimit);

  // Tenant summary items
  const tenantRecords = records.filter((r) => !!r.tenantId);

  return (
    <div className="space-y-6">
      {/* Metric Selector Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900 border border-slate-800 rounded-2xl">
        <div className="flex flex-wrap gap-2 text-xs font-medium">
          <button
            onClick={() => setSelectedMetric('pue')}
            className={`px-3 py-2 rounded-xl flex items-center space-x-1.5 transition-all ${
              selectedMetric === 'pue'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Gauge className="w-3.5 h-3.5 text-cyan-400" />
            <span>PUE Power Efficiency</span>
            <span className="font-mono text-[10px] text-cyan-300 ml-1">
              {maxPue.toFixed(2)}
            </span>
          </button>

          <button
            onClick={() => setSelectedMetric('temp')}
            className={`px-3 py-2 rounded-xl flex items-center space-x-1.5 transition-all ${
              selectedMetric === 'temp'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Server Inlet Temp</span>
            <span className="font-mono text-[10px] text-rose-300 ml-1">
              {maxTemp.toFixed(1)}°C
            </span>
          </button>

          <button
            onClick={() => setSelectedMetric('thd')}
            className={`px-3 py-2 rounded-xl flex items-center space-x-1.5 transition-all ${
              selectedMetric === 'thd'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Grid THD Harmonics</span>
            <span className="font-mono text-[10px] text-amber-300 ml-1">
              {maxThd.toFixed(1)}%
            </span>
          </button>

          <button
            onClick={() => setSelectedMetric('idle')}
            className={`px-3 py-2 rounded-xl flex items-center space-x-1.5 transition-all ${
              selectedMetric === 'idle'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Server className="w-3.5 h-3.5 text-purple-400" />
            <span>Idle Server Draw</span>
            <span className="font-mono text-[10px] text-purple-300 ml-1">
              {maxIdle.toFixed(0)}%
            </span>
          </button>

          <button
            onClick={() => setSelectedMetric('wue')}
            className={`px-3 py-2 rounded-xl flex items-center space-x-1.5 transition-all ${
              selectedMetric === 'wue'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Waves className="w-3.5 h-3.5 text-blue-400" />
            <span>Cooling WUE</span>
            <span className="font-mono text-[10px] text-blue-300 ml-1">
              {maxWue.toFixed(2)} L/kWh
            </span>
          </button>
        </div>

        {/* Legend */}
        <div className="flex items-center space-x-3 text-[11px] font-mono text-slate-400">
          <div className="flex items-center space-x-1">
            <span className="w-3 h-0.5 bg-amber-400"></span>
            <span>Warning Line</span>
          </div>
          <div className="flex items-center space-x-1">
            <span className="w-3 h-0.5 bg-red-500"></span>
            <span>Critical Line</span>
          </div>
        </div>
      </div>

      {/* Primary SVG Chart Card */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center">
              <Activity className="w-4 h-4 text-cyan-400 mr-2" />
              {metricInfo.title}
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Target Facility: <span className="text-cyan-300">{facilityName}</span> • Points:{' '}
              {records.length}
            </p>
          </div>
          <div className="text-right font-mono text-xs">
            <div className="text-slate-400">Warning Threshold: &gt; {metricInfo.warnLimit} {metricInfo.unit}</div>
            <div className="text-red-400 font-semibold">Critical Threshold: &gt; {metricInfo.critLimit} {metricInfo.unit}</div>
          </div>
        </div>

        {/* Responsive SVG Chart */}
        <div className="w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full h-auto min-w-[620px] select-none"
          >
            <defs>
              <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={metricInfo.lineColor} stopOpacity="0.35" />
                <stop offset="100%" stopColor={metricInfo.lineColor} stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1.0].map((frac, idx) => {
              const y = padding.top + chartH * frac;
              const val = metricInfo.maxScale - frac * (metricInfo.maxScale - metricInfo.minScale);
              return (
                <g key={idx}>
                  <line
                    x1={padding.left}
                    y1={y}
                    x2={width - padding.right}
                    y2={y}
                    stroke="#1e293b"
                    strokeDasharray="4 4"
                    strokeWidth="1"
                  />
                  <text
                    x={padding.left - 8}
                    y={y + 3}
                    textAnchor="end"
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    {val.toFixed(1)}
                  </text>
                </g>
              );
            })}

            {/* Warning line */}
            {warnY >= padding.top && warnY <= padding.top + chartH && (
              <g>
                <line
                  x1={padding.left}
                  y1={warnY}
                  x2={width - padding.right}
                  y2={warnY}
                  stroke="#f59e0b"
                  strokeWidth="1.5"
                  strokeDasharray="6 3"
                />
                <rect
                  x={width - padding.right - 95}
                  y={warnY - 9}
                  width="90"
                  height="16"
                  fill="#78350f"
                  rx="3"
                />
                <text
                  x={width - padding.right - 50}
                  y={warnY + 3}
                  textAnchor="middle"
                  fill="#fef08a"
                  fontSize="9"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  WARN: {metricInfo.warnLimit}
                </text>
              </g>
            )}

            {/* Critical line */}
            {critY >= padding.top && critY <= padding.top + chartH && (
              <g>
                <line
                  x1={padding.left}
                  y1={critY}
                  x2={width - padding.right}
                  y2={critY}
                  stroke="#ef4444"
                  strokeWidth="2"
                  strokeDasharray="8 4"
                />
                <rect
                  x={width - padding.right - 95}
                  y={critY - 9}
                  width="90"
                  height="16"
                  fill="#7f1d1d"
                  rx="3"
                />
                <text
                  x={width - padding.right - 50}
                  y={critY + 3}
                  textAnchor="middle"
                  fill="#fecaca"
                  fontSize="9"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  CRITICAL: {metricInfo.critLimit}
                </text>
              </g>
            )}

            {/* Filled Area */}
            <path d={areaD} fill="url(#areaGrad)" />

            {/* Main Metric Curve */}
            <path
              d={pathD}
              fill="none"
              stroke={metricInfo.lineColor}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Data Point Dots & Labels */}
            {points.map((pt, i) => {
              const isCrit = pt.val >= metricInfo.critLimit;
              const isWarn = pt.val >= metricInfo.warnLimit && !isCrit;
              const dotColor = isCrit ? '#ef4444' : isWarn ? '#f59e0b' : metricInfo.lineColor;

              return (
                <g key={i}>
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r={isCrit || isWarn ? 5.5 : 4}
                    fill={dotColor}
                    stroke="#0f172a"
                    strokeWidth="2"
                  />
                  {/* Point Value */}
                  <text
                    x={pt.x}
                    y={pt.y - 10}
                    textAnchor="middle"
                    fill={isCrit ? '#f87171' : isWarn ? '#fbbf24' : '#cbd5e1'}
                    fontSize="10"
                    fontWeight={isCrit || isWarn ? 'bold' : 'normal'}
                    fontFamily="monospace"
                  >
                    {typeof pt.val === 'number' ? pt.val.toFixed(1) : pt.val}
                  </text>
                  {/* X Axis Label */}
                  <text
                    x={pt.x}
                    y={height - padding.bottom + 16}
                    textAnchor="middle"
                    fill="#64748b"
                    fontSize="9"
                    fontFamily="monospace"
                  >
                    {pt.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Tenant Resource Usage Matrix (if tenant telemetry present) */}
      {tenantRecords.length > 0 && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center">
              <ShieldAlert className="w-4 h-4 text-emerald-400 mr-2" />
              Tenant Resource Allocation & Quota Guard
            </h3>
            <span className="text-xs font-mono text-slate-400">
              {tenantRecords.length} Tenant Allocations Monitored
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tenantRecords.map((t, idx) => {
              const storagePct = t.tenantStoragePct ?? 50;
              const powerDraw = t.tenantPowerKw ?? 5.0;
              const powerLimit = t.tenantPowerLimitKw ?? 10.0;
              const powerPct = (powerDraw / powerLimit) * 100;
              const temp = t.tenantTempC ?? 24;
              const bw = t.tenantBandwidthGbps ?? 10;
              const bwLimit = t.tenantBandwidthLimitGbps ?? 40;
              const bwPct = (bw / bwLimit) * 100;

              const hasWarning =
                storagePct > THRESHOLDS.TENANT_STORAGE.warning ||
                powerPct > THRESHOLDS.TENANT_POWER_USAGE_PCT.warning ||
                temp > THRESHOLDS.TENANT_TEMP.warning ||
                bwPct > THRESHOLDS.TENANT_NETWORK_USAGE_PCT.warning;

              const hasCritical =
                storagePct > THRESHOLDS.TENANT_STORAGE.critical ||
                powerPct > THRESHOLDS.TENANT_POWER_USAGE_PCT.critical ||
                temp > THRESHOLDS.TENANT_TEMP.critical ||
                bwPct > THRESHOLDS.TENANT_NETWORK_USAGE_PCT.critical;

              return (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border bg-slate-950/70 transition-all ${
                    hasCritical
                      ? 'border-red-800/80 shadow-md shadow-red-950/20'
                      : hasWarning
                      ? 'border-amber-800/80 shadow-md shadow-amber-950/20'
                      : 'border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-bold text-sm text-white">{t.tenantId}</span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        hasCritical
                          ? 'bg-red-950 text-red-400 border border-red-800'
                          : hasWarning
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      }`}
                    >
                      {hasCritical ? 'Critical Alert' : hasWarning ? 'Quota Warning' : 'Healthy'}
                    </span>
                  </div>

                  <div className="space-y-2.5 text-xs font-mono">
                    {/* Storage */}
                    <div>
                      <div className="flex justify-between text-slate-400 mb-1">
                        <span>Storage ({storagePct.toFixed(1)}%):</span>
                        <span
                          className={
                            storagePct > 95
                              ? 'text-red-400 font-bold'
                              : storagePct > 90
                              ? 'text-amber-400'
                              : 'text-slate-300'
                          }
                        >
                          {storagePct.toFixed(1)}% / 100%
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full ${
                            storagePct > 95
                              ? 'bg-red-500'
                              : storagePct > 90
                              ? 'bg-amber-500'
                              : 'bg-cyan-500'
                          }`}
                          style={{ width: `${Math.min(100, storagePct)}%` }}
                        />
                      </div>
                    </div>

                    {/* Power */}
                    <div>
                      <div className="flex justify-between text-slate-400 mb-1">
                        <span>Power Draw ({powerDraw.toFixed(1)} kW):</span>
                        <span
                          className={
                            powerPct > 100
                              ? 'text-red-400 font-bold'
                              : powerPct > 90
                              ? 'text-amber-400'
                              : 'text-slate-300'
                          }
                        >
                          {powerDraw.toFixed(1)} / {powerLimit.toFixed(1)} kW
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full ${
                            powerPct > 100
                              ? 'bg-red-500'
                              : powerPct > 90
                              ? 'bg-amber-500'
                              : 'bg-blue-500'
                          }`}
                          style={{ width: `${Math.min(100, powerPct)}%` }}
                        />
                      </div>
                    </div>

                    {/* Temp & Network Bandwidth */}
                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80 text-[11px]">
                      <div>
                        <span className="text-slate-500 block">Rack Temp</span>
                        <span
                          className={`font-semibold ${
                            temp > 32
                              ? 'text-red-400 font-bold'
                              : temp > 28
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          {temp.toFixed(1)}°C
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Network Uplink</span>
                        <span
                          className={`font-semibold ${
                            bwPct > 98
                              ? 'text-red-400 font-bold'
                              : bwPct > 90
                              ? 'text-amber-400'
                              : 'text-cyan-400'
                          }`}
                        >
                          {bw.toFixed(1)} Gbps
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
