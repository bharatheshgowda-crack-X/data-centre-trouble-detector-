import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowDownToLine,
  ArrowUpToLine,
  Check,
  CheckCircle2,
  Code2,
  Copy,
  Database,
  ExternalLink,
  Layers,
  Link2,
  Radio,
  RefreshCw,
  Server,
  ShieldCheck,
  Sparkles,
  X,
  Zap,
} from 'lucide-react';
import { pushAllToSupabase, syncFromSupabase } from '../utils/storage';
import {
  SUPABASE_ANON_KEY,
  SUPABASE_PROJECT_ID,
  SUPABASE_SQL_SCHEMA,
  SUPABASE_URL,
  SupabaseHealth,
  testSupabaseConnection,
} from '../utils/supabaseClient';

interface SupabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataSynced?: () => void;
}

export const SupabaseModal: React.FC<SupabaseModalProps> = ({
  isOpen,
  onClose,
  onDataSynced,
}) => {
  const [health, setHealth] = useState<SupabaseHealth | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [copiedSQL, setCopiedSQL] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'status' | 'sql' | 'sync'>('status');

  const checkConnection = async () => {
    setIsLoading(true);
    const result = await testSupabaseConnection();
    setHealth(result);
    setIsLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      checkConnection();
    }
  }, [isOpen]);

  const handleCopySQL = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSQL(true);
    setTimeout(() => setCopiedSQL(false), 2500);
  };

  const handlePushData = async () => {
    setIsPushing(true);
    setSyncStatusMsg(null);
    const result = await pushAllToSupabase();
    setIsPushing(false);
    setSyncStatusMsg(
      `Pushed to Supabase: ${result.usersPushed} users, ${result.activitiesPushed} activity logs, ${result.datasetsPushed} datasets.`
    );
    checkConnection();
    if (onDataSynced) onDataSynced();
  };

  const handlePullData = async () => {
    setIsPulling(true);
    setSyncStatusMsg(null);
    const result = await syncFromSupabase();
    setIsPulling(false);
    setSyncStatusMsg(
      `Synced from Supabase: ${result.usersSynced} users, ${result.activitiesSynced} logs, ${result.datasetsSynced} datasets.`
    );
    if (onDataSynced) onDataSynced();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[92vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 p-5 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-bold text-white">Supabase Backend Integration</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 uppercase font-bold">
                  PROJECT LINKED
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Project ID: <span className="text-cyan-300 font-semibold">{SUPABASE_PROJECT_ID}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <div className="grid grid-cols-3 border-b border-slate-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('status')}
            className={`py-3 px-3 flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'status'
                ? 'bg-slate-800/80 text-emerald-400 border-b-2 border-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>Connection & Credentials</span>
          </button>

          <button
            onClick={() => setActiveTab('sql')}
            className={`py-3 px-3 flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'sql'
                ? 'bg-slate-800/80 text-emerald-400 border-b-2 border-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>SQL Schema Setup</span>
          </button>

          <button
            onClick={() => setActiveTab('sync')}
            className={`py-3 px-3 flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'sync'
                ? 'bg-slate-800/80 text-emerald-400 border-b-2 border-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Live Data Sync</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 text-xs">
          {/* TAB 1: STATUS & CREDENTIALS */}
          {activeTab === 'status' && (
            <div className="space-y-4">
              {/* Connection Status Box */}
              <div
                className={`p-4 rounded-xl border flex items-start justify-between ${
                  health?.connected
                    ? health.status === 'connected'
                      ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-200'
                      : 'bg-amber-950/30 border-amber-800/60 text-amber-200'
                    : 'bg-red-950/30 border-red-800/60 text-red-200'
                }`}
              >
                <div className="flex items-start space-x-3">
                  {health?.connected ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <div className="font-bold text-sm text-white flex items-center">
                      <span>
                        {isLoading
                          ? 'Pinging Supabase REST Endpoint...'
                          : health?.connected
                          ? health.status === 'connected'
                            ? 'Supabase Backend Connected & Synchronized'
                            : 'Connected to Supabase (Tables Setup Recommended)'
                          : 'Connecting to Supabase...'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      {health?.message || 'Testing project endpoint handshake...'}
                    </p>
                    {health && (
                      <div className="flex items-center space-x-3 font-mono text-[11px] text-slate-400 mt-2">
                        <span>Latency: <strong className="text-white">{health.latencyMs} ms</strong></span>
                        <span>•</span>
                        <span>Endpoint: <strong className="text-white">Active</strong></span>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  onClick={checkConnection}
                  disabled={isLoading}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-mono text-[11px] flex items-center space-x-1.5 transition-colors border border-slate-700"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>Test Ping</span>
                </button>
              </div>

              {/* Linked Credentials Card */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 font-mono">
                <div className="text-[11px] font-bold uppercase text-slate-400">
                  Configured Supabase Environment
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 uppercase block mb-0.5">
                    Supabase Project ID
                  </label>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300 select-all">
                    {SUPABASE_PROJECT_ID}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 uppercase block mb-0.5">
                    Supabase REST & Realtime URL
                  </label>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-white select-all">
                    {SUPABASE_URL}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 uppercase block mb-0.5">
                    Publishable API Anon Key
                  </label>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 break-all select-all text-[11px]">
                    {SUPABASE_ANON_KEY}
                  </div>
                </div>
              </div>

              {/* Direct Dashboard Link */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div className="text-xs text-slate-300">
                  Open your project management dashboard in Supabase:
                </div>
                <a
                  href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-md shadow-emerald-900/30"
                >
                  <span>Open Supabase Dashboard</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}

          {/* TAB 2: SQL SCHEMA SETUP */}
          {activeTab === 'sql' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm">
                    Supabase Database Tables Definition
                  </h4>
                  <p className="text-slate-400 text-xs">
                    Copy and run this in your Supabase SQL Editor to initialize <code className="text-emerald-400">dc_users</code>,{' '}
                    <code className="text-emerald-400">dc_activity_logs</code>, and{' '}
                    <code className="text-emerald-400">dc_datasets</code>.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <a
                    href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center space-x-1 border border-slate-700"
                  >
                    <span>Open SQL Editor</span>
                    <ExternalLink className="w-3.5 h-3.5 ml-1" />
                  </a>

                  <button
                    onClick={handleCopySQL}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md shadow-emerald-900/40 transition-all"
                  >
                    {copiedSQL ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-white" />
                        <span>Copied SQL!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy SQL Script</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Code viewer */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 max-h-72 overflow-y-auto leading-relaxed select-all">
                <pre>{SUPABASE_SQL_SCHEMA}</pre>
              </div>
            </div>
          )}

          {/* TAB 3: LIVE DATA SYNC */}
          {activeTab === 'sync' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="font-bold text-white text-sm">
                  Synchronize Data Between Applet and Supabase
                </h4>
                <p className="text-xs text-slate-400">
                  Every user login, activity log, and telemetry CSV upload automatically streams to Supabase in real-time. You can also trigger manual full-sync operations below:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={handlePushData}
                    disabled={isPushing}
                    className="p-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-left transition-all group disabled:opacity-50"
                  >
                    <div className="flex items-center space-x-2 text-emerald-400 font-bold mb-1">
                      <ArrowUpToLine className="w-4 h-4" />
                      <span>Push All to Supabase</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Uploads all local registered users, activity audit trails, and analyzed telemetry datasets to Supabase.
                    </p>
                    <span className="inline-block mt-2 text-[10px] font-mono text-cyan-400">
                      {isPushing ? 'Pushing Data...' : 'Click to Upload Now →'}
                    </span>
                  </button>

                  <button
                    onClick={handlePullData}
                    disabled={isPulling}
                    className="p-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-left transition-all group disabled:opacity-50"
                  >
                    <div className="flex items-center space-x-2 text-cyan-400 font-bold mb-1">
                      <ArrowDownToLine className="w-4 h-4" />
                      <span>Pull Latest from Supabase</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Downloads records created in Supabase database into the current local applet view.
                    </p>
                    <span className="inline-block mt-2 text-[10px] font-mono text-cyan-400">
                      {isPulling ? 'Fetching Data...' : 'Click to Download Now →'}
                    </span>
                  </button>
                </div>

                {syncStatusMsg && (
                  <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs flex items-center space-x-2 mt-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{syncStatusMsg}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">
            SUPABASE BACKEND ACTIVE • PROJECT: {SUPABASE_PROJECT_ID}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
