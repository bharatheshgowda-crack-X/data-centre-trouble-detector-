import React, { useState } from 'react';
import {
  Bell,
  Check,
  CheckCircle2,
  Clock,
  History,
  Mail,
  Save,
  Send,
  ShieldAlert,
  Sliders,
  Sparkles,
  X,
} from 'lucide-react';
import { EmailNotificationRecord, EmailSettings, User } from '../types';
import { getEmailHistory, getEmailSettings, saveEmailSettings } from '../utils/emailService';

interface EmailSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
}

export const EmailSettingsModal: React.FC<EmailSettingsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  if (!isOpen) return null;

  const [settings, setSettings] = useState<EmailSettings>(() => getEmailSettings(currentUser));
  const [history, setHistory] = useState<EmailNotificationRecord[]>(() =>
    getEmailHistory(currentUser)
  );
  const [activeTab, setActiveTab] = useState<'settings' | 'history'>('settings');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveEmailSettings(currentUser, settings);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 p-5 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Email Alert Notification Center</h3>
              <p className="text-xs text-slate-400">
                Configure automated email alerts and recommendations for data center threshold issues
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <div className="grid grid-cols-2 border-b border-slate-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-3 flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'settings'
                ? 'bg-slate-800/80 text-cyan-400 border-b-2 border-cyan-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Notification Settings</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('history');
              setHistory(getEmailHistory(currentUser));
            }}
            className={`py-3 px-3 flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'history'
                ? 'bg-slate-800/80 text-cyan-400 border-b-2 border-cyan-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Sent Alerts History ({history.length})</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'settings' ? (
            <form onSubmit={handleSave} className="space-y-5 text-xs">
              {/* Primary Email */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  Primary Alert Recipient Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="email"
                    value={settings.primaryEmail}
                    onChange={(e) => setSettings({ ...settings, primaryEmail: e.target.value })}
                    placeholder="e.g. bbharatheshgowdamr@gmail.com"
                    required
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-sans text-xs"
                  />
                </div>
                <p className="text-[11px] text-slate-400">
                  All critical/warning telemetry diagnostic emails will be delivered to this address.
                </p>
              </div>

              {/* Additional CC emails */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  Additional Notification Emails (Optional)
                </label>
                <input
                  type="text"
                  value={settings.additionalEmails}
                  onChange={(e) => setSettings({ ...settings, additionalEmails: e.target.value })}
                  placeholder="e.g. facilities@datacenter.net, oncall@domain.com"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-sans text-xs"
                />
                <p className="text-[11px] text-slate-400">
                  Separate multiple email addresses with commas.
                </p>
              </div>

              {/* Toggles */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-white uppercase font-mono block">
                  Automated Dispatch Rules
                </span>

                <label className="flex items-start space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoSendOnUpload}
                    onChange={(e) =>
                      setSettings({ ...settings, autoSendOnUpload: e.target.checked })
                    }
                    className="mt-1 h-4 w-4 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-400"
                  />
                  <div>
                    <span className="font-semibold text-white block">
                      Auto-Dispatch Email When CSV Upload Has Issues
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      Immediately sends an alert notification email to the configured recipient whenever a newly uploaded CSV triggers threshold violations.
                    </span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnCritical}
                    onChange={(e) =>
                      setSettings({ ...settings, notifyOnCritical: e.target.checked })
                    }
                    className="mt-1 h-4 w-4 rounded border-slate-700 bg-slate-900 text-red-500 focus:ring-red-400"
                  />
                  <div>
                    <span className="font-semibold text-red-400 block">
                      Include Critical Severity Alerts
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      PUE &gt; 1.8, WUE &gt; 2.5 L/kWh, Idle Power &gt; 60%, Temp &gt; 32°C, Grid THD &gt; 10%, Tenant Quota Breaches.
                    </span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnWarning}
                    onChange={(e) =>
                      setSettings({ ...settings, notifyOnWarning: e.target.checked })
                    }
                    className="mt-1 h-4 w-4 rounded border-slate-700 bg-slate-900 text-amber-500 focus:ring-amber-400"
                  />
                  <div>
                    <span className="font-semibold text-amber-400 block">
                      Include Warning Severity Alerts
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      PUE &gt; 1.5, WUE &gt; 1.5 L/kWh, Idle Power &gt; 40%, Temp &gt; 27°C, Grid THD &gt; 5%.
                    </span>
                  </div>
                </label>
              </div>

              {savedSuccess && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Email notification settings updated successfully!</span>
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-cyan-600/20 transition-all flex items-center space-x-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Notification Preferences</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              {history.length === 0 ? (
                <div className="p-10 text-center bg-slate-950 border border-slate-800 rounded-xl text-slate-400 text-xs">
                  <Mail className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <span>No alert notification emails dispatched yet.</span>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                  {history.map((item) => (
                    <div
                      key={item.id}
                      className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                            item.severity === 'critical'
                              ? 'bg-red-950 text-red-400 border border-red-800'
                              : 'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}
                        >
                          {item.severity}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {new Date(item.sentAt).toLocaleString()}
                        </span>
                      </div>
                      <div className="font-semibold text-white">{item.troubleTitle}</div>
                      <div className="text-[11px] text-slate-400">
                        Recipient: <strong className="text-cyan-300">{item.recipientEmail}</strong> • Facility: {item.facility}
                      </div>
                      <p className="text-slate-400 text-[11px] line-clamp-2 mt-1">
                        {item.bodyPreview}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
