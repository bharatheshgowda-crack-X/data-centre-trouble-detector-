import React, { useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  Flame,
  Gauge,
  Mail,
  Send,
  Server,
  ShieldAlert,
  Waves,
  X,
  Zap,
} from 'lucide-react';
import { DetectedTrouble, User } from '../types';
import {
  dispatchAlertEmail,
  generateAlertEmailHTML,
  generateAlertEmailText,
  getEmailSettings,
} from '../utils/emailService';

interface EmailAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  trouble: DetectedTrouble | null;
  facility: string;
  currentUser: User;
  onEmailSent?: () => void;
}

export const EmailAlertModal: React.FC<EmailAlertModalProps> = ({
  isOpen,
  onClose,
  trouble,
  facility,
  currentUser,
  onEmailSent,
}) => {
  if (!isOpen || !trouble) return null;

  const defaultSettings = getEmailSettings(currentUser);
  const [recipientEmail, setRecipientEmail] = useState(
    defaultSettings.primaryEmail || currentUser.email || 'bbharatheshgowdamr@gmail.com'
  );
  const [viewMode, setViewMode] = useState<'preview' | 'html' | 'text'>('preview');
  const [isSending, setIsSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const isCrit = trouble.severity === 'critical';
  const htmlContent = generateAlertEmailHTML(trouble, facility, recipientEmail);
  const textContent = generateAlertEmailText(trouble, facility);

  const handleSend = () => {
    if (!recipientEmail.trim() || !recipientEmail.includes('@')) {
      alert('Please enter a valid email address.');
      return;
    }

    setIsSending(true);
    setTimeout(() => {
      dispatchAlertEmail(trouble, facility, recipientEmail, currentUser);
      setIsSending(false);
      setSentSuccess(true);
      if (onEmailSent) onEmailSent();
      setTimeout(() => {
        setSentSuccess(false);
        onClose();
      }, 1500);
    }, 400);
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(textContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenMailto = () => {
    const { mailtoUrl } = dispatchAlertEmail(trouble, facility, recipientEmail, currentUser);
    window.location.href = mailtoUrl;
    if (onEmailSent) onEmailSent();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[92vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 p-5 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white">Send Email Alert & Corrective Solution</h3>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    isCrit
                      ? 'bg-red-950 text-red-400 border border-red-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}
                >
                  {trouble.severity}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Dispatches full problem description, recommendations, and risk warnings to specified email
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-5 text-xs">
          {/* Recipient Email input */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <label className="block text-xs font-semibold text-slate-300">
              Recipient Email Address
            </label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="e.g. engineer@datacenter.net or user@gmail.com"
                  required
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-sans text-xs"
                />
              </div>

              {currentUser.email && (
                <button
                  type="button"
                  onClick={() => setRecipientEmail(currentUser.email)}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono whitespace-nowrap border border-slate-700"
                >
                  My Email
                </button>
              )}
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              Email will include the full problem diagnostics, step-by-step remediation plan, and consequence assessment.
            </div>
          </div>

          {/* Incident Summary Card */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-400 uppercase font-semibold">
                {trouble.categoryLabel}
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                {facility} • {trouble.rackOrTenant}
              </span>
            </div>

            <div className="font-bold text-white text-sm">{trouble.problemTitle}</div>

            <div className="grid grid-cols-2 gap-2 font-mono text-xs">
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Recorded Reading</span>
                <span className={`font-bold ${isCrit ? 'text-red-400' : 'text-amber-400'}`}>
                  {trouble.observedValue} {trouble.unit}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Threshold Limit</span>
                <span className="text-slate-300 font-bold">
                  &gt; {trouble.thresholdValue} {trouble.unit}
                </span>
              </div>
            </div>
          </div>

          {/* Email Preview Switcher */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-semibold text-slate-300 text-xs uppercase tracking-wider">
              Email Content Preview
            </span>
            <div className="flex space-x-1 text-[11px] font-mono">
              <button
                type="button"
                onClick={() => setViewMode('preview')}
                className={`px-2.5 py-1 rounded-lg ${
                  viewMode === 'preview'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Visual Card
              </button>
              <button
                type="button"
                onClick={() => setViewMode('text')}
                className={`px-2.5 py-1 rounded-lg ${
                  viewMode === 'text'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Plain Text
              </button>
              <button
                type="button"
                onClick={() => setViewMode('html')}
                className={`px-2.5 py-1 rounded-lg ${
                  viewMode === 'html'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                HTML Template
              </button>
            </div>
          </div>

          {/* Preview Box */}
          {viewMode === 'preview' && (
            <div className="space-y-3 p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <span className="text-[10px] font-mono text-slate-500 uppercase block">SUBJECT</span>
                <span className="text-white font-semibold text-xs">
                  [{trouble.severity.toUpperCase()} ALERT] {facility}: {trouble.problemTitle}
                </span>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-500 uppercase block">PROBLEM DESCRIPTION</span>
                <p className="text-slate-300 text-xs leading-relaxed mt-0.5">
                  {trouble.problemDescription}
                </p>
              </div>

              <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-800/40">
                <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold block mb-1">
                  RECOMMENDED SOLUTION & CORRECTIVE ACTION
                </span>
                <p className="text-cyan-200 text-xs whitespace-pre-line leading-relaxed">
                  {trouble.recommendedSolution}
                </p>
              </div>

              <div className="p-3 rounded-lg bg-red-950/20 border border-red-900/40">
                <span className="text-[10px] font-mono text-red-400 uppercase font-bold block mb-1">
                  POTENTIAL CONSEQUENCES IF IGNORED
                </span>
                <p className="text-red-200/90 text-xs leading-relaxed">
                  {trouble.potentialConsequences}
                </p>
              </div>
            </div>
          )}

          {viewMode === 'text' && (
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 max-h-56 overflow-y-auto leading-relaxed select-all">
              <pre>{textContent}</pre>
            </div>
          )}

          {viewMode === 'html' && (
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-400 max-h-56 overflow-y-auto leading-relaxed select-all">
              <pre>{htmlContent}</pre>
            </div>
          )}

          {/* Feedback */}
          {sentSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-800 text-emerald-200 text-xs flex items-center space-x-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>
                Notification email successfully dispatched to <strong>{recipientEmail}</strong> and logged to audit trail!
              </span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleCopyText}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Content' : 'Copy Email Text'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenMailto}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
              title="Open email draft directly in Outlook, Gmail, or default mail app"
            >
              <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
              <span>Open in Email App</span>
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSend}
              disabled={isSending || sentSuccess}
              className="px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-cyan-600/25 transition-all flex items-center space-x-1.5 disabled:opacity-50"
            >
              <Send className={`w-3.5 h-3.5 ${isSending ? 'animate-pulse' : ''}`} />
              <span>{isSending ? 'Dispatching Email...' : 'Send Alert Email Now'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
