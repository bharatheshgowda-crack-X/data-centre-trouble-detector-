import React, { useEffect, useRef, useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowDownToLine,
  CheckCircle2,
  Clock,
  Database,
  FileSpreadsheet,
  FileText,
  Flame,
  Gauge,
  HelpCircle,
  Layers,
  Lightbulb,
  Mail,
  Radio,
  RefreshCw,
  Search,
  Server,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Upload,
  UserCheck,
  Waves,
  Zap,
} from 'lucide-react';
import {
  BackendNotificationRecord,
  DetectedTrouble,
  EmailDeliveryStatus,
  TelemetryRecord,
  UploadDataset,
  User,
} from '../types';
import { SAMPLE_DATASETS, generateTemplateCSV, parseCSV } from '../utils/csvParser';
import { analyzeTelemetryRecords } from '../utils/detectionEngine';
import {
  autoDispatchUploadAlerts,
  fetchEmailStatusesBatch,
  getEmailSettings,
  retryIncidentEmailNotification,
} from '../utils/emailService';
import {
  getDatasets,
  logActivity,
  saveDataset,
  updateTroubleStatus,
} from '../utils/storage';
import { ActionModal } from './ActionModal';
import { EmailAlertModal } from './EmailAlertModal';
import { EmailSettingsModal } from './EmailSettingsModal';
import { TelemetryCharts } from './TelemetryCharts';


interface CustomerDashboardProps {
  currentUser: User;
  onOpenThresholds: () => void;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  currentUser,
  onOpenThresholds,
}) => {
  // Customer sees ONLY their own datasets!
  const [datasets, setDatasets] = useState<UploadDataset[]>(getDatasets(currentUser));
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(
    datasets.length > 0 ? datasets[0].id : ''
  );
  const [activeTab, setActiveTab] = useState<'troubles' | 'charts' | 'raw_data' | 'upload'>('troubles');

  // Filters
  const [severityFilter, setSeverityFilter] = useState<'all' | 'critical' | 'warning'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Upload state
  const [isDragging, setIsDragging] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modals
  const [selectedTrouble, setSelectedTrouble] = useState<DetectedTrouble | null>(null);
  const [emailTrouble, setEmailTrouble] = useState<DetectedTrouble | null>(null);
  const [isEmailSettingsOpen, setIsEmailSettingsOpen] = useState(false);

  // Email Notification Integration State
  const [emailStatuses, setEmailStatuses] = useState<Record<string, BackendNotificationRecord>>({});
  const [retryingIncidentId, setRetryingIncidentId] = useState<string | null>(null);

  // Active dataset
  const activeDataset = datasets.find((d) => d.id === selectedDatasetId) || datasets[0] || null;

  // Sync email statuses for active dataset troubles
  useEffect(() => {
    if (activeDataset && activeDataset.troubles.length > 0) {
      const ids = activeDataset.troubles.map((t) => t.id);
      fetchEmailStatusesBatch(ids).then((statuses) => {
        setEmailStatuses(statuses);
      }).catch(() => {});
    }
  }, [activeDataset?.id, datasets]);

  const handleRetryEmail = async (incidentId: string) => {
    setRetryingIncidentId(incidentId);
    try {
      await retryIncidentEmailNotification(incidentId);
      if (activeDataset) {
        const statuses = await fetchEmailStatusesBatch(activeDataset.troubles.map((t) => t.id));
        setEmailStatuses(statuses);
      }
    } catch (err) {
      console.warn('Retry error:', err);
    } finally {
      setRetryingIncidentId(null);
    }
  };

  const refreshDatasets = () => {
    const updated = getDatasets(currentUser);
    setDatasets(updated);
    if (updated.length > 0 && !updated.some((d) => d.id === selectedDatasetId)) {
      setSelectedDatasetId(updated[0].id);
    }
  };

  // Process raw CSV string
  const handleProcessCSVContent = (csvText: string, fileName: string) => {
    setUploadError(null);
    setUploadSuccess(null);
    setIsProcessing(true);

    setTimeout(() => {
      try {
        const parsed = parseCSV(csvText);
        if (parsed.errors.length > 0 && parsed.records.length === 0) {
          setUploadError(parsed.errors.join(' '));
          setIsProcessing(false);
          return;
        }

        const newDatasetId = `ds-${Date.now()}`;
        const analysis = analyzeTelemetryRecords(parsed.records, newDatasetId, fileName);

        const facilityName = parsed.facilityName || `${currentUser.organization || 'Client'} Facility`;

        const newDataset: UploadDataset = {
          id: newDatasetId,
          fileName,
          uploadedAt: new Date().toISOString(),
          uploadedBy: currentUser.email,
          uploadedByName: currentUser.name,
          facility: facilityName,
          rowCount: parsed.records.length,
          criticalCount: analysis.criticalCount,
          warningCount: analysis.warningCount,
          healthyCount: analysis.healthyCount,
          healthScore: analysis.healthScore,
          records: parsed.records,
          troubles: analysis.troubles,
        };

        saveDataset(newDataset, currentUser);
        refreshDatasets();
        setSelectedDatasetId(newDataset.id);
        setActiveTab('troubles');

        // Automated Email Alert Dispatch to user's configured notification email
        let emailMsg = '';
        if (analysis.troubles.length > 0) {
          const emailRes = autoDispatchUploadAlerts(analysis.troubles, facilityName, currentUser);
          if (emailRes.emailsDispatched > 0) {
            const settings = getEmailSettings(currentUser);
            emailMsg = ` ✉️ Automatically dispatched ${emailRes.emailsDispatched} alert notification email(s) with corrective recommendations to ${settings.primaryEmail}.`;
          }
        }

        setIsProcessing(false);
        setUploadSuccess(
          `Analysis Complete: Parsed ${parsed.records.length} records. Identified ${analysis.criticalCount} Critical and ${analysis.warningCount} Warning issues.${emailMsg}`
        );
      } catch (err: any) {
        setIsProcessing(false);
        setUploadError(`Failed to process CSV file: ${err.message || 'Unknown error'}`);
      }
    }, 450);
  };

  // Handle file drop or selection
  const handleFile = (file: File) => {
    if (!file.name.endsWith('.csv') && !file.type.includes('csv') && !file.type.includes('text')) {
      setUploadError('Please upload a valid .csv format file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (content) {
        handleProcessCSVContent(content, file.name);
      }
    };
    reader.onerror = () => {
      setUploadError('Failed to read file from filesystem.');
    };
    reader.readAsText(file);
  };

  // Load sample dataset
  const handleLoadSample = (sampleKey: keyof typeof SAMPLE_DATASETS) => {
    const sample = SAMPLE_DATASETS[sampleKey];
    handleProcessCSVContent(sample.csv, sample.name);
  };

  // Download template
  const handleDownloadTemplate = () => {
    const template = generateTemplateCSV();
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'DataCenter_Metrics_Template.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  // Update status of trouble
  const handleStatusChange = (
    troubleId: string,
    status: 'open' | 'in_progress' | 'resolved',
    note: string
  ) => {
    updateTroubleStatus(troubleId, status, note, currentUser);
    refreshDatasets();
  };

  // Filter troubles
  const currentTroubles = activeDataset ? activeDataset.troubles : [];
  const filteredTroubles = currentTroubles.filter((t) => {
    if (severityFilter !== 'all' && t.severity !== severityFilter) return false;
    if (categoryFilter !== 'all' && t.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.problemTitle.toLowerCase().includes(q) ||
        t.rackOrTenant.toLowerCase().includes(q) ||
        t.metricName.toLowerCase().includes(q) ||
        t.recommendedSolution.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Customer Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900 to-slate-950 border border-cyan-800/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 flex items-center justify-center shadow-lg shadow-cyan-950/50 shrink-0">
            <Server className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400">
                CUSTOMER FACILITY MONITOR
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-800">
                RESTRICTED TENANT VIEW
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">
              {currentUser.name} • {currentUser.organization || 'Data Center Colocation'}
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Active Ingested Telemetry:{' '}
              <strong className="text-white">
                {activeDataset ? activeDataset.facility : 'No facility loaded yet'}
              </strong>
            </p>
          </div>
        </div>

        {/* Dataset Switcher & Ingest Action */}
        <div className="flex flex-wrap items-center gap-2.5">
          {datasets.length > 0 && (
            <select
              value={selectedDatasetId}
              onChange={(e) => setSelectedDatasetId(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              {datasets.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.fileName} ({new Date(d.uploadedAt).toLocaleDateString()})
                </option>
              ))}
            </select>
          )}

          <button
            onClick={() => setIsEmailSettingsOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm"
            title="Configure recipient email and automated alert notifications"
          >
            <Mail className="w-4 h-4 text-cyan-400" />
            <span>Email Alert Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('upload')}
            className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-2 shadow-lg shadow-cyan-600/25 transition-all"
          >
            <Upload className="w-4 h-4" />
            <span>Upload New CSV</span>
          </button>
        </div>
      </div>

      {/* Dataset Health Metric Overview */}
      {activeDataset && (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5 sm:gap-4">
          {/* Health Score */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg col-span-2 sm:col-span-1">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>FACILITY HEALTH</span>
              <Gauge className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="flex items-baseline space-x-2 mt-2">
              <span
                className={`text-2xl sm:text-3xl font-black font-mono ${
                  activeDataset.healthScore > 80
                    ? 'text-emerald-400'
                    : activeDataset.healthScore > 50
                    ? 'text-amber-400'
                    : 'text-red-400'
                }`}
              >
                {activeDataset.healthScore}
              </span>
              <span className="text-xs text-slate-500 font-mono">/ 100</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {activeDataset.healthScore > 80
                ? 'Optimal Operating Range'
                : activeDataset.healthScore > 50
                ? 'Degraded Performance'
                : 'Emergency Intervention Required'}
            </div>
          </div>

          {/* Critical Issues */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-red-900/40 shadow-lg">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>CRITICAL ALERTS</span>
              <ShieldAlert className="w-4 h-4 text-red-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-red-400 mt-2 font-mono">
              {activeDataset.criticalCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Breaches critical ceiling</div>
          </div>

          {/* Warning Issues */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-amber-900/40 shadow-lg">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>WARNING ALERTS</span>
              <AlertTriangle className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-400 mt-2 font-mono">
              {activeDataset.warningCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Exceeds caution limit</div>
          </div>

          {/* Telemetry Rows */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>TELEMETRY SLICES</span>
              <FileSpreadsheet className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-white mt-2 font-mono">
              {activeDataset.rowCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Timestamped data points</div>
          </div>

          {/* Ingest Date */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg col-span-2 lg:col-span-1">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>FILE SOURCE</span>
              <Database className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-sm font-bold text-white mt-2 truncate font-mono">
              {activeDataset.fileName}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {new Date(activeDataset.uploadedAt).toLocaleTimeString()}
            </div>
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="border-b border-slate-800 flex items-center space-x-1 sm:space-x-3 text-xs sm:text-sm font-medium overflow-x-auto">
        <button
          onClick={() => setActiveTab('troubles')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'troubles'
              ? 'border-cyan-400 text-cyan-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Detected Troubles & Solutions ({currentTroubles.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('charts')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'charts'
              ? 'border-cyan-400 text-cyan-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Telemetry Charts & Visualizer</span>
        </button>

        <button
          onClick={() => setActiveTab('raw_data')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'raw_data'
              ? 'border-cyan-400 text-cyan-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Raw Ingest Table</span>
        </button>

        <button
          onClick={() => setActiveTab('upload')}
          className={`py-3 px-3 sm:px-4 flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
            activeTab === 'upload'
              ? 'border-cyan-400 text-cyan-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Upload className="w-4 h-4" />
          <span>CSV Upload Dropzone</span>
        </button>
      </div>

      {/* TAB: CSV UPLOAD DROPZONE */}
      {activeTab === 'upload' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center">
                  <Upload className="w-5 h-5 text-cyan-400 mr-2" />
                  Upload Data Center Metrics CSV File
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  The detector will parse and evaluate telemetry against PUE, WUE, Idle Server Power, Grid THD, HVAC Temp, and Tenant Quotas.
                </p>
              </div>

              <button
                onClick={handleDownloadTemplate}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
              >
                <ArrowDownToLine className="w-3.5 h-3.5 text-cyan-400" />
                <span>Download Sample CSV Template</span>
              </button>
            </div>

            {/* Banners */}
            {uploadError && (
              <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-800 text-red-200 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}
            {uploadSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{uploadSuccess}</span>
              </div>
            )}

            {/* Drag & Drop Area */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                  handleFile(e.dataTransfer.files[0]);
                }
              }}
              className={`p-10 border-2 border-dashed rounded-2xl text-center transition-all ${
                isDragging
                  ? 'border-cyan-400 bg-cyan-950/30'
                  : 'border-slate-700 bg-slate-950/60 hover:border-slate-600'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,text/csv"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFile(e.target.files[0]);
                  }
                }}
                className="hidden"
              />

              <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 text-cyan-400 mx-auto flex items-center justify-center mb-3 border border-cyan-500/20">
                <Upload className="w-7 h-7" />
              </div>

              <h4 className="text-sm font-bold text-white">
                Drag and drop your facility CSV file here
              </h4>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Accepts standard telemetry exports containing PUE, WUE, Server Inlet Temps, Grid THD, and Tenant metrics.
              </p>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessing}
                className="mt-4 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all disabled:opacity-50"
              >
                {isProcessing ? 'Processing Telemetry...' : 'Browse Local Files (.csv)'}
              </button>
            </div>

            {/* Quick 1-Click Built-in Sample Datasets */}
            <div className="pt-4 border-t border-slate-800">
              <div className="text-xs font-bold text-slate-300 mb-2 flex items-center">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 mr-1.5" />
                Or Instantly Test With Pre-Configured Telemetry Samples:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => handleLoadSample('CRITICAL_STRESS')}
                  className="p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-red-900/40 text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-red-400">
                    <span>Critical Stress DC</span>
                    <span className="text-[10px] font-mono bg-red-950 px-1.5 py-0.5 rounded border border-red-800">
                      CRITICAL
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    PUE 1.94, Inlet Temp 34°C, WUE 2.85, Tenant Quota Breaches
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => handleLoadSample('WARNING_EDGE')}
                  className="p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-amber-900/40 text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-amber-400">
                    <span>Edge Modular Pod</span>
                    <span className="text-[10px] font-mono bg-amber-950 px-1.5 py-0.5 rounded border border-amber-800">
                      WARNING
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Grid THD 7.8%, Idle Server Draw 54%, Tenant Storage 93%
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => handleLoadSample('OPTIMAL_GREEN')}
                  className="p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-emerald-900/40 text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
                    <span>Green Tier-IV DC</span>
                    <span className="text-[10px] font-mono bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800">
                      OPTIMAL
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    PUE 1.18, WUE 0.35 L/kWh, Zero threshold violations
                  </p>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: DETECTED TROUBLES & CORRECTIVE SOLUTIONS */}
      {activeTab === 'troubles' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search issues by rack, metric, description, or corrective action..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 focus:outline-none"
              >
                <option value="all">All Severities</option>
                <option value="critical">Critical Only</option>
                <option value="warning">Warning Only</option>
              </select>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 focus:outline-none"
              >
                <option value="all">All Categories</option>
                <option value="PUE_EFFICIENCY">Excessive Power / PUE</option>
                <option value="WUE_COOLING">Cooling Water (WUE)</option>
                <option value="IDLE_SERVER_POWER">Idle Server Inefficiency</option>
                <option value="GRID_INSTABILITY">Grid Instability / THD</option>
                <option value="HVAC_STRESS">HVAC / Inlet Temp</option>
                <option value="TENANT_OVERUSE">Tenant Quota Overuse</option>
              </select>
            </div>
          </div>

          {/* Troubles Cards */}
          {filteredTroubles.length === 0 ? (
            <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3 opacity-80" />
              <h3 className="text-base font-bold text-white">No Troubles Detected in this Dataset</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                All metrics are operating safely within defined data center operational thresholds.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTroubles.map((trouble) => {
                const isCrit = trouble.severity === 'critical';
                return (
                  <div
                    key={trouble.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      isCrit
                        ? 'bg-slate-900/95 border-red-900/70 shadow-lg shadow-red-950/20'
                        : 'bg-slate-900/95 border-amber-900/70 shadow-lg shadow-amber-950/20'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider font-mono ${
                            isCrit
                              ? 'bg-red-950 text-red-400 border border-red-800 animate-pulse'
                              : 'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}
                        >
                          {trouble.severity}
                        </span>
                        <span className="text-xs font-semibold text-white font-mono">
                          {trouble.categoryLabel}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Target: <strong className="text-slate-200">{trouble.rackOrTenant}</strong>
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {/* Small Email Notification Status field */}
                        {(() => {
                          const notif = emailStatuses[trouble.id];
                          const emailStatus: EmailDeliveryStatus = notif?.status || 'Pending';
                          return (
                            <div
                              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${
                                emailStatus === 'Sent'
                                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                                  : emailStatus === 'Failed'
                                  ? 'bg-red-950/80 text-red-300 border-red-800'
                                  : 'bg-amber-950/80 text-amber-300 border-amber-800'
                              }`}
                              title={
                                notif
                                  ? `Status: ${notif.status} (${notif.provider}) • Sent to: ${notif.customerEmail}${
                                      notif.error ? ` • ${notif.error}` : ''
                                    }`
                                  : 'Email dispatch queued upon anomaly detection'
                              }
                            >
                              <span className="text-slate-400 font-sans">Email:</span>
                              {emailStatus === 'Sent' ? (
                                <span className="font-bold flex items-center space-x-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                  <span>Sent</span>
                                </span>
                              ) : emailStatus === 'Failed' ? (
                                <span className="font-bold flex items-center space-x-1">
                                  <AlertCircle className="w-3 h-3 text-red-400" />
                                  <span>Failed</span>
                                </span>
                              ) : (
                                <span className="font-bold flex items-center space-x-1">
                                  <Clock className="w-3 h-3 text-amber-400" />
                                  <span>Pending</span>
                                </span>
                              )}
                              {emailStatus === 'Failed' && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRetryEmail(trouble.id);
                                  }}
                                  disabled={retryingIncidentId === trouble.id}
                                  className="ml-1 text-[9px] px-1.5 py-0.5 rounded bg-red-900/90 hover:bg-red-800 text-white font-sans font-bold transition-all disabled:opacity-50"
                                  title="Retry dispatching email notification"
                                >
                                  {retryingIncidentId === trouble.id ? '...' : 'Retry'}
                                </button>
                              )}
                            </div>
                          );
                        })()}

                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono capitalize ${
                            trouble.status === 'resolved'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                              : trouble.status === 'in_progress'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                              : 'bg-red-950/80 text-red-300 border border-red-800'
                          }`}
                        >
                          {trouble.status.replace('_', ' ')}
                        </span>
                        <button
                          onClick={() => setEmailTrouble(trouble)}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/60 text-xs font-semibold transition-all flex items-center space-x-1 shadow-sm"
                          title="Send email alert with recommendation to user"
                        >
                          <Mail className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Email Alert & Solution</span>
                        </button>
                        <button
                          onClick={() => setSelectedTrouble(trouble)}
                          className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-600/20 transition-all flex items-center space-x-1"
                        >
                          <span>Manage Mitigation</span>
                        </button>
                      </div>
                    </div>

                    {/* Problem Title & Readings */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 py-3 text-xs">
                      <div className="md:col-span-3 space-y-1">
                        <h4 className="text-base font-bold text-white">{trouble.problemTitle}</h4>
                        <p className="text-slate-300 text-xs leading-relaxed">
                          {trouble.problemDescription}
                        </p>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono space-y-1 text-center md:text-right">
                        <div className="text-[10px] text-slate-500 uppercase">Observed Value</div>
                        <div
                          className={`text-xl font-black ${
                            isCrit ? 'text-red-400' : 'text-amber-400'
                          }`}
                        >
                          {trouble.observedValue} {trouble.unit}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Threshold: &gt; {trouble.thresholdValue} {trouble.unit}
                        </div>
                      </div>
                    </div>

                    {/* Recommended Solution & Potential Consequences */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-slate-800/80 text-xs">
                      {/* Solution */}
                      <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 space-y-1">
                        <div className="text-[10px] uppercase font-bold text-cyan-400 flex items-center">
                          <Lightbulb className="w-3.5 h-3.5 mr-1 text-cyan-400" />
                          Recommended Corrective Action
                        </div>
                        <p className="text-cyan-200 text-xs whitespace-pre-line leading-relaxed">
                          {trouble.recommendedSolution}
                        </p>
                      </div>

                      {/* Consequences */}
                      <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-900/40 space-y-1">
                        <div className="text-[10px] uppercase font-bold text-red-400 flex items-center">
                          <ShieldAlert className="w-3.5 h-3.5 mr-1 text-red-400" />
                          Potential Consequences if Ignored
                        </div>
                        <p className="text-red-200/90 text-xs leading-relaxed">
                          {trouble.potentialConsequences}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB: CHARTS & VISUALIZER */}
      {activeTab === 'charts' && (
        <div className="space-y-6">
          {activeDataset ? (
            <TelemetryCharts
              records={activeDataset.records}
              facilityName={activeDataset.facility}
            />
          ) : (
            <div className="p-12 text-center text-slate-400">No telemetry dataset loaded.</div>
          )}
        </div>
      )}

      {/* TAB: RAW DATA TABLE */}
      {activeTab === 'raw_data' && (
        <div className="space-y-4">
          {activeDataset ? (
            <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
              <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-bold text-white">
                  Ingested Telemetry Matrix ({activeDataset.records.length} Records)
                </span>
                <span className="font-mono text-slate-400">{activeDataset.fileName}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-950/90 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">Timestamp</th>
                      <th className="py-2.5 px-3">Rack ID</th>
                      <th className="py-2.5 px-3">PUE</th>
                      <th className="py-2.5 px-3">WUE (L/kWh)</th>
                      <th className="py-2.5 px-3">Idle Power %</th>
                      <th className="py-2.5 px-3">Grid THD %</th>
                      <th className="py-2.5 px-3">Inlet Temp (°C)</th>
                      <th className="py-2.5 px-3">Tenant</th>
                      <th className="py-2.5 px-3">Storage %</th>
                      <th className="py-2.5 px-3">Power kW</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {activeDataset.records.map((r) => {
                      const pueCrit = r.pue > 1.8;
                      const pueWarn = r.pue > 1.5 && !pueCrit;
                      const tempCrit = r.serverInletTemp > 32;
                      const tempWarn = r.serverInletTemp > 27 && !tempCrit;
                      const thdCrit = r.gridThd > 10;
                      const thdWarn = r.gridThd > 5 && !thdCrit;
                      const idleCrit = r.idlePowerPct > 60;
                      const idleWarn = r.idlePowerPct > 40 && !idleCrit;

                      return (
                        <tr key={r.id} className="hover:bg-slate-950/50 transition-colors">
                          <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                            {r.timestamp}
                          </td>
                          <td className="py-2.5 px-3 font-semibold text-white">{r.rackId}</td>
                          <td
                            className={`py-2.5 px-3 font-bold ${
                              pueCrit ? 'text-red-400' : pueWarn ? 'text-amber-400' : 'text-slate-300'
                            }`}
                          >
                            {r.pue.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-slate-300">{r.wue.toFixed(2)}</td>
                          <td
                            className={`py-2.5 px-3 ${
                              idleCrit
                                ? 'text-red-400 font-bold'
                                : idleWarn
                                ? 'text-amber-400'
                                : 'text-slate-300'
                            }`}
                          >
                            {r.idlePowerPct.toFixed(1)}%
                          </td>
                          <td
                            className={`py-2.5 px-3 ${
                              thdCrit
                                ? 'text-red-400 font-bold'
                                : thdWarn
                                ? 'text-amber-400'
                                : 'text-slate-300'
                            }`}
                          >
                            {r.gridThd.toFixed(1)}%
                          </td>
                          <td
                            className={`py-2.5 px-3 font-bold ${
                              tempCrit
                                ? 'text-red-400'
                                : tempWarn
                                ? 'text-amber-400'
                                : 'text-slate-300'
                            }`}
                          >
                            {r.serverInletTemp.toFixed(1)}°C
                          </td>
                          <td className="py-2.5 px-3 text-cyan-300">{r.tenantId || '—'}</td>
                          <td className="py-2.5 px-3 text-slate-300">
                            {r.tenantStoragePct ? `${r.tenantStoragePct}%` : '—'}
                          </td>
                          <td className="py-2.5 px-3 text-slate-300">
                            {r.tenantPowerKw ? `${r.tenantPowerKw} kW` : '—'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-slate-400">No records found.</div>
          )}
        </div>
      )}

      {/* Action / Mitigation Modal */}
      <ActionModal
        trouble={selectedTrouble}
        currentUser={currentUser}
        onClose={() => setSelectedTrouble(null)}
        onOpenEmail={(t) => setEmailTrouble(t)}
        onUpdateStatus={handleStatusChange}
      />

      {/* Email Alert & Corrective Solution Modal */}
      <EmailAlertModal
        isOpen={!!emailTrouble}
        onClose={() => setEmailTrouble(null)}
        trouble={emailTrouble}
        facility={activeDataset ? activeDataset.facility : 'Data Center Facility'}
        currentUser={currentUser}
      />

      {/* Email Notification Settings Modal */}
      <EmailSettingsModal
        isOpen={isEmailSettingsOpen}
        onClose={() => setIsEmailSettingsOpen(false)}
        currentUser={currentUser}
      />
    </div>
  );
};

