import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Flame,
  Gauge,
  Lightbulb,
  Mail,
  Server,
  ShieldAlert,
  Waves,
  X,
  Zap,
} from 'lucide-react';
import { DetectedTrouble, User } from '../types';

interface ActionModalProps {
  trouble: DetectedTrouble | null;
  currentUser: User;
  onClose: () => void;
  onOpenEmail?: (trouble: DetectedTrouble) => void;
  onUpdateStatus: (
    troubleId: string,
    status: 'open' | 'in_progress' | 'resolved',
    note: string
  ) => void;
}

export const ActionModal: React.FC<ActionModalProps> = ({
  trouble,
  currentUser,
  onClose,
  onOpenEmail,
  onUpdateStatus,
}) => {
  if (!trouble) return null;

  const [status, setStatus] = useState<'open' | 'in_progress' | 'resolved'>(trouble.status);
  const [note, setNote] = useState<string>(
    trouble.resolutionNotes ||
      (status === 'resolved'
        ? 'Mitigation protocol applied. Parameters restored to normal operating range.'
        : 'Engineering team dispatched to investigate telemetry variance.')
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateStatus(trouble.id, status, note);
    onClose();
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'PUE_EFFICIENCY':
        return <Gauge className="w-5 h-5 text-cyan-400" />;
      case 'WUE_COOLING':
        return <Waves className="w-5 h-5 text-blue-400" />;
      case 'IDLE_SERVER_POWER':
        return <Server className="w-5 h-5 text-purple-400" />;
      case 'GRID_INSTABILITY':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'HVAC_STRESS':
        return <Flame className="w-5 h-5 text-rose-400" />;
      case 'TENANT_OVERUSE':
        return <ShieldAlert className="w-5 h-5 text-emerald-400" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 p-5 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-slate-800 border border-slate-700">
              {getCategoryIcon(trouble.category)}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    trouble.severity === 'critical'
                      ? 'bg-red-950 text-red-400 border border-red-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}
                >
                  {trouble.severity}
                </span>
                <span className="text-xs font-mono text-slate-400">{trouble.categoryLabel}</span>
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">{trouble.problemTitle}</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Diagnostic Metrics */}
          <div className="grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[10px]">FACILITY / TARGET</span>
              <span className="text-white font-medium truncate block">{trouble.rackOrTenant}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">RECORDED VALUE</span>
              <span
                className={`font-bold text-sm ${
                  trouble.severity === 'critical' ? 'text-red-400' : 'text-amber-400'
                }`}
              >
                {trouble.observedValue} {trouble.unit}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">ENGINE THRESHOLD</span>
              <span className="text-slate-300 font-semibold">
                &gt; {trouble.thresholdValue} {trouble.unit}
              </span>
            </div>
          </div>

          {/* Problem Description */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1 flex items-center">
              <AlertTriangle className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
              Problem Description
            </h4>
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 leading-relaxed">
              {trouble.problemDescription}
            </div>
          </div>

          {/* Recommended Corrective Action */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-1 flex items-center">
              <Lightbulb className="w-3.5 h-3.5 mr-1.5 text-cyan-400" />
              Recommended Corrective Action
            </h4>
            <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-200 whitespace-pre-line leading-relaxed">
              {trouble.recommendedSolution}
            </div>
          </div>

          {/* Potential Consequences if Ignored */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-red-400 mb-1 flex items-center">
              <ShieldAlert className="w-3.5 h-3.5 mr-1.5 text-red-400" />
              Potential Consequences if Ignored
            </h4>
            <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-900/40 text-xs text-red-200/90 leading-relaxed">
              {trouble.potentialConsequences}
            </div>
          </div>

          {/* Mitigation Form: Update Status */}
          <div className="pt-2 border-t border-slate-800 space-y-3">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
              Update Incident Mitigation Status
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setStatus('open')}
                className={`p-2.5 rounded-xl border flex items-center justify-center space-x-1.5 transition-all ${
                  status === 'open'
                    ? 'bg-rose-950 text-rose-300 border-rose-600 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>Open Incident</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('in_progress')}
                className={`p-2.5 rounded-xl border flex items-center justify-center space-x-1.5 transition-all ${
                  status === 'in_progress'
                    ? 'bg-amber-950 text-amber-300 border-amber-600 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>In Progress</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('resolved')}
                className={`p-2.5 rounded-xl border flex items-center justify-center space-x-1.5 transition-all ${
                  status === 'resolved'
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-600 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Mark Resolved</span>
              </button>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Engineering Log / Mitigation Notes
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="Detail corrective actions implemented (e.g. chilled water valve reset, VM migration, tenant contacted)..."
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-sans"
              />
            </div>
          </div>

          {/* Action Footer */}
          <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-800 gap-2">
            <span className="text-[11px] font-mono text-slate-500">
              LOGGED AS: {currentUser.name} ({currentUser.role.toUpperCase()})
            </span>
            <div className="flex items-center space-x-2">
              {onOpenEmail && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenEmail(trouble);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold rounded-xl border border-cyan-800/60 transition-colors flex items-center space-x-1.5 shadow-sm"
                  title="Send email alert with recommendation to user or engineer"
                >
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Send Email Alert</span>
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-cyan-600/20 transition-all flex items-center space-x-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Save & Log Action</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
