import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Database,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  Mail,
  Server,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  User as UserIcon,
} from 'lucide-react';
import { User } from '../types';
import { ADMIN_CREDENTIALS, getUsers, logActivity, saveUsers, setCurrentUser } from '../utils/storage';

interface AuthPortalProps {
  onLoginSuccess: (user: User) => void;
  defaultTab?: 'customer' | 'admin';
}

export const AuthPortal: React.FC<AuthPortalProps> = ({ onLoginSuccess, defaultTab = 'customer' }) => {
  const [activeTab, setActiveTab] = useState<'customer_login' | 'customer_register' | 'admin_login'>(
    defaultTab === 'admin' ? 'admin_login' : 'customer_login'
  );

  // Customer Login Form State
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPassword, setCustomerPassword] = useState('');
  const [showCustomerPassword, setShowCustomerPassword] = useState(false);

  // Customer Register Form State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regOrg, setRegOrg] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  // Admin Login Form State
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  // General Status
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Quick auto-fill admin credentials
  const handleAutoFillAdmin = () => {
    setAdminUsername(ADMIN_CREDENTIALS.username);
    setAdminPassword(ADMIN_CREDENTIALS.password);
    setErrorMsg(null);
  };

  // Quick fill customer demo
  const handleQuickCustomer = (email: string, pass: string) => {
    setCustomerEmail(email);
    setCustomerPassword(pass);
    setErrorMsg(null);
  };

  // Handle Customer Login
  const handleCustomerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!customerEmail.trim() || !customerPassword.trim()) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const users = getUsers();
      const cleanEmail = customerEmail.trim().toLowerCase();
      const found = users.find((u) => u.email.toLowerCase() === cleanEmail && u.role === 'customer');

      if (!found) {
        setIsLoading(false);
        setErrorMsg('Customer account not found. Please register or check your credentials.');
        return;
      }

      if (found.status === 'suspended') {
        setIsLoading(false);
        setErrorMsg('Your customer account has been suspended by system administrator.');
        return;
      }

      // Update last login
      found.lastLoginAt = new Date().toISOString();
      saveUsers(users);
      setCurrentUser(found);

      logActivity({
        userId: found.id,
        userEmail: found.email,
        userName: found.name,
        userRole: 'customer',
        actionType: 'LOGIN',
        details: `Customer "${found.name}" signed into Customer Telemetry Portal.`,
        severity: 'info',
      });

      setIsLoading(false);
      setSuccessMsg('Authentication successful. Redirecting to Customer Portal...');
      setTimeout(() => onLoginSuccess(found), 500);
    }, 400);
  };

  // Handle Customer Register
  const handleCustomerRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!regName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setErrorMsg('All fields are required.');
      return;
    }

    if (regPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    const cleanEmail = regEmail.trim().toLowerCase();
    const users = getUsers();

    if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      setErrorMsg('An account with this email address already exists. Please login instead.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const newUser: User = {
        id: `usr-${Date.now()}`,
        email: cleanEmail,
        name: regName.trim(),
        organization: regOrg.trim() || 'Data Center Colocation Client',
        role: 'customer',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
        status: 'active',
      };

      const updatedUsers = [...users, newUser];
      saveUsers(updatedUsers);
      setCurrentUser(newUser);

      logActivity({
        userId: newUser.id,
        userEmail: newUser.email,
        userName: newUser.name,
        userRole: 'customer',
        actionType: 'REGISTER',
        details: `New customer registered: ${newUser.name} (${newUser.organization}).`,
        severity: 'info',
      });

      setIsLoading(false);
      setSuccessMsg('Account registered successfully! Loading workspace...');
      setTimeout(() => onLoginSuccess(newUser), 500);
    }, 400);
  };

  // Handle Admin Login
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanUser = adminUsername.trim();
    const cleanPass = adminPassword.trim();

    if (!cleanUser || !cleanPass) {
      setErrorMsg('Please enter both Admin Username and Password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      // Prompt specification:
      // Username: Bharathesh Gowda M R
      // Password: bharath2008
      const matchesUsername =
        cleanUser.toLowerCase() === ADMIN_CREDENTIALS.username.toLowerCase();
      const matchesPassword = cleanPass === ADMIN_CREDENTIALS.password;

      if (!matchesUsername || !matchesPassword) {
        setIsLoading(false);
        setErrorMsg('Invalid Administrator credentials. Access denied.');
        // Log security alert
        logActivity({
          userId: 'anonymous',
          userEmail: cleanUser || 'unknown_admin',
          userName: 'Unauthorized Attempt',
          userRole: 'admin',
          actionType: 'LOGIN',
          details: `FAILED Root Administrator login attempt with username "${cleanUser}".`,
          severity: 'critical',
        });
        return;
      }

      // Find or build admin record
      const users = getUsers();
      let adminRecord = users.find((u) => u.role === 'admin');
      if (!adminRecord) {
        adminRecord = {
          id: 'usr-admin-bharathesh',
          email: ADMIN_CREDENTIALS.email,
          name: ADMIN_CREDENTIALS.name,
          role: 'admin',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          status: 'active',
          organization: 'Global Command Center',
        };
        users.push(adminRecord);
      } else {
        adminRecord.lastLoginAt = new Date().toISOString();
      }

      saveUsers(users);
      setCurrentUser(adminRecord);

      logActivity({
        userId: adminRecord.id,
        userEmail: adminRecord.email,
        userName: adminRecord.name,
        userRole: 'admin',
        actionType: 'LOGIN',
        details: `Administrator "${ADMIN_CREDENTIALS.name}" successfully authenticated into High-Security Admin Terminal.`,
        severity: 'info',
      });

      setIsLoading(false);
      setSuccessMsg('Admin credentials authorized. Initializing Global Command Center...');
      setTimeout(() => onLoginSuccess(adminRecord!), 500);
    }, 450);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4 sm:p-6 lg:p-8 relative overflow-hidden bg-slate-950">
      {/* Background cyber grid & glow effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,165,233,0.15),rgba(255,255,255,0))] pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-xl relative z-10">
        {/* Portal Card Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300 font-mono mb-3">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            <span>DATA CENTER DIAGNOSTIC TELEMETRY GATEWAY</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Data Center Trouble Detector
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-md mx-auto">
            Real-time threshold violation auditing, PUE/WUE analysis, HVAC stress diagnostics, and tenant quota security.
          </p>
        </div>

        {/* Portal Box */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden">
          {/* Top Portal Switcher Tabs */}
          <div className="grid grid-cols-3 border-b border-slate-800 text-xs sm:text-sm font-medium">
            <button
              onClick={() => {
                setActiveTab('customer_login');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-3.5 px-3 flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'customer_login'
                  ? 'bg-slate-800 text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <UserIcon className="w-4 h-4" />
              <span>Customer Login</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('customer_register');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-3.5 px-3 flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'customer_register'
                  ? 'bg-slate-800 text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Register</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('admin_login');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-3.5 px-3 flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'admin_login'
                  ? 'bg-amber-950/40 text-amber-300 border-b-2 border-amber-400 font-semibold shadow-inner'
                  : 'text-slate-400 hover:text-amber-200 hover:bg-amber-950/20'
              }`}
            >
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Admin Portal</span>
            </button>
          </div>

          <div className="p-6 sm:p-8">
            {/* Feedback Banners */}
            {errorMsg && (
              <div className="mb-5 p-3.5 rounded-xl bg-red-950/60 border border-red-800/60 text-red-200 text-xs sm:text-sm flex items-start space-x-2.5">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}
            {successMsg && (
              <div className="mb-5 p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-200 text-xs sm:text-sm flex items-start space-x-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* TAB 1: CUSTOMER LOGIN */}
            {activeTab === 'customer_login' && (
              <form onSubmit={handleCustomerLogin} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-white flex items-center">
                    <Server className="w-4 h-4 text-cyan-400 mr-2" />
                    Customer Facility Access
                  </h3>
                  <span className="text-[11px] font-mono text-cyan-400">TELEMETRY INGESTION</span>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Operator Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="e.g. operator@datacenter.net"
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all font-sans"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Password</label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type={showCustomerPassword ? 'text' : 'password'}
                      value={customerPassword}
                      onChange={(e) => setCustomerPassword(e.target.value)}
                      placeholder="••••••••••••"
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCustomerPassword(!showCustomerPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                    >
                      {showCustomerPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-sm font-semibold rounded-xl shadow-lg shadow-cyan-600/20 focus:outline-none focus:ring-2 focus:ring-cyan-400 disabled:opacity-50 transition-all"
                >
                  {isLoading ? 'Verifying Customer Token...' : 'Enter Customer Portal'}
                </button>

                {/* Demo Quick Logins */}
                <div className="pt-4 border-t border-slate-800/80">
                  <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
                    <span>QUICK TEST CUSTOMER ACCOUNTS:</span>
                    <span className="text-cyan-400 text-[10px]">1-Click Populate</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleQuickCustomer('operator@datacenter.net', 'operator123')}
                      className="text-left p-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 transition-colors text-xs"
                    >
                      <div className="font-semibold text-slate-200">Alex Mercer</div>
                      <div className="text-[10px] text-slate-400 truncate">operator@datacenter.net</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickCustomer('facilities@cloudhub.io', 'cloudhub2024')}
                      className="text-left p-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 transition-colors text-xs"
                    >
                      <div className="font-semibold text-slate-200">Elena Rostova</div>
                      <div className="text-[10px] text-slate-400 truncate">facilities@cloudhub.io</div>
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* TAB 2: CUSTOMER REGISTER */}
            {activeTab === 'customer_register' && (
              <form onSubmit={handleCustomerRegister} className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-white flex items-center">
                    <Sparkles className="w-4 h-4 text-cyan-400 mr-2" />
                    New Customer Registration
                  </h3>
                  <span className="text-[11px] font-mono text-slate-400">SELF-SERVICE</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. Maya Chen"
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Company / Organization</label>
                    <input
                      type="text"
                      value={regOrg}
                      onChange={(e) => setRegOrg(e.target.value)}
                      placeholder="e.g. NextGen Cloud DC"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Work Email</label>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="e.g. maya@nextgencloud.com"
                    required
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
                    <div className="relative">
                      <input
                        type={showRegPassword ? 'text' : 'password'}
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="Min 6 chars"
                        required
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 pr-8 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegPassword(!showRegPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                      >
                        {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Confirm Password</label>
                    <input
                      type="password"
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      placeholder="Repeat password"
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-sm font-semibold rounded-xl shadow-lg shadow-cyan-600/20 focus:outline-none focus:ring-2 focus:ring-cyan-400 disabled:opacity-50 transition-all"
                >
                  {isLoading ? 'Creating Account...' : 'Create Customer Account'}
                </button>

                <p className="text-center text-xs text-slate-400 mt-2">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setActiveTab('customer_login')}
                    className="text-cyan-400 hover:underline font-medium"
                  >
                    Log In
                  </button>
                </p>
              </form>
            )}

            {/* TAB 3: ADMIN LOGIN PORTAL (CRITICAL FEATURE 1) */}
            {activeTab === 'admin_login' && (
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/40 flex items-start space-x-3 mb-2">
                  <Shield className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-semibold text-amber-300 block">
                      Restricted Administrator Access
                    </span>
                    <span className="text-slate-300">
                      Authorizes global visibility into all user activities, system-wide alerts, and user management.
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-medium text-slate-300">
                      Admin Username
                    </label>
                    <span className="text-[10px] font-mono text-amber-400/90">SPECIFIED CREDENTIAL</span>
                  </div>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="text"
                      value={adminUsername}
                      onChange={(e) => setAdminUsername(e.target.value)}
                      placeholder="e.g. Bharathesh Gowda M R"
                      required
                      className="w-full bg-slate-950 border border-amber-900/60 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Admin Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type={showAdminPassword ? 'text' : 'password'}
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      placeholder="••••••••••••"
                      required
                      className="w-full bg-slate-950 border border-amber-900/60 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPassword(!showAdminPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                    >
                      {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={handleAutoFillAdmin}
                    className="text-xs text-amber-400 hover:text-amber-300 font-medium underline flex items-center"
                  >
                    <KeyRound className="w-3.5 h-3.5 mr-1" />
                    Auto-Fill Assigned Admin Credentials
                  </button>
                  <span className="text-[10px] text-slate-500 font-mono">TLS 1.3 SECURED</span>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white text-sm font-semibold rounded-xl shadow-lg shadow-amber-900/40 focus:outline-none focus:ring-2 focus:ring-amber-400 disabled:opacity-50 transition-all flex items-center justify-center space-x-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isLoading ? 'Authorizing Admin Token...' : 'Authorize Admin Session'}</span>
                </button>

                <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-[11px] text-slate-400 font-mono">
                  <div className="font-semibold text-slate-300 mb-0.5">Assigned Admin Credentials:</div>
                  <div className="flex items-center justify-between">
                    <span>Username: <strong className="text-amber-300">{ADMIN_CREDENTIALS.username}</strong></span>
                    <span>Password: <strong className="text-amber-300">{ADMIN_CREDENTIALS.password}</strong></span>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Security Disclaimers & Portal Status */}
        <div className="mt-6 flex flex-wrap items-center justify-between text-xs text-slate-500 font-mono px-2 gap-2">
          <div className="flex items-center space-x-1.5">
            <Lock className="w-3.5 h-3.5 text-cyan-500" />
            <span>Role-Based Access Control (RBAC) Active</span>
          </div>
          <div>Audit Logging: <span className="text-emerald-400">Continuous Monitoring</span></div>
        </div>
      </div>
    </div>
  );
};
