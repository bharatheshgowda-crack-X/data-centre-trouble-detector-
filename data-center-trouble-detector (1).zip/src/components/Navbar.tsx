import React, { useEffect, useState } from 'react';
import { Activity, Bell, Database, Download, LogOut, Shield, ShieldCheck, UserCheck, Zap } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentUser: User | null;
  onLogout: () => void;
  onOpenThresholds: () => void;
  onOpenSupabase: () => void;
  onOpenEmailSettings?: () => void;
  activeAlertsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  onOpenThresholds,
  onOpenSupabase,
  onOpenEmailSettings,
  activeAlertsCount = 0,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          timeZoneName: 'short',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/20 text-white font-bold">
            <Database className="w-5 h-5 text-white" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center">
                DATA CENTER
                <span className="ml-1.5 text-cyan-400">TROUBLE DETECTOR</span>
              </span>
              <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-950/80 text-cyan-300 border border-cyan-800/60 uppercase tracking-wider">
                v2.6 Enterprise
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Mission-Critical Telemetry Analysis & Anomaly Diagnostics
            </p>
          </div>
        </div>

        {/* Status and User Section */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* GitHub Export Zip Button */}
          <a
            href="/api/download-source"
            download="data-center-trouble-detector.zip"
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium shadow-sm transition-colors border border-blue-400/30"
            title="Download full project code as a ZIP archive for your GitHub repository"
          >
            <Download className="w-3.5 h-3.5 text-white" />
            <span className="font-semibold">Download .ZIP</span>
          </a>

          {/* Email Notifications Button */}
          {onOpenEmailSettings && (
            <button
              onClick={onOpenEmailSettings}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-medium transition-colors"
              title="Configure Email Alerts & Recommendations Notifications"
            >
              <Bell className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Email Alerts</span>
            </button>
          )}

          {/* Supabase Backend Live Status Button */}
          <button
            onClick={onOpenSupabase}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/50 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800/60 text-xs font-mono transition-colors shadow-sm"
            title="Supabase Backend: Project ctyxrwzmugfgvjxqwpzv linked"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold hidden sm:inline">SUPABASE:</span>
            <span className="text-emerald-400 font-bold">ctyxrwzmugfg</span>
          </button>

          {/* Thresholds Quick Button */}
          <button
            onClick={onOpenThresholds}
            className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-medium transition-colors"
            title="View Detection Threshold Rules"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Thresholds</span>
          </button>

          {currentUser ? (
            <div className="flex items-center space-x-2 sm:space-x-3">
              {/* User badge */}
              <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800">
                {currentUser.role === 'admin' ? (
                  <div className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-300 flex items-center justify-center border border-amber-500/30">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                ) : (
                  <div className="w-6 h-6 rounded-md bg-cyan-500/20 text-cyan-300 flex items-center justify-center border border-cyan-500/30">
                    <UserCheck className="w-3.5 h-3.5" />
                  </div>
                )}
                <div className="text-left">
                  <div className="text-xs font-semibold text-slate-200 leading-none">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] font-mono leading-tight mt-0.5">
                    {currentUser.role === 'admin' ? (
                      <span className="text-amber-400 font-semibold">ROOT ADMIN</span>
                    ) : (
                      <span className="text-cyan-400">CUSTOMER PORTAL</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Logout button */}
              <button
                onClick={onLogout}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/40 text-xs font-medium transition-colors"
                title="Log out of current session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center text-xs text-slate-400 font-mono">
              <Shield className="w-4 h-4 text-cyan-400 mr-1.5" />
              AUTHENTICATION REQUIRED
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
