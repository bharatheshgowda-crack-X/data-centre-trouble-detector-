import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle,
  KeyRound,
  Shield,
  Trash2,
  UserCheck,
  UserPlus,
  UserX,
  Users,
  X,
} from 'lucide-react';
import { User } from '../types';
import { ADMIN_CREDENTIALS, getUsers, logActivity, saveUsers } from '../utils/storage';

interface UserManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onUsersUpdated: () => void;
}

export const UserManagementModal: React.FC<UserManagementModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUsersUpdated,
}) => {
  if (!isOpen) return null;

  const [users, setUsers] = useState<User[]>(getUsers());
  const [showAddForm, setShowAddForm] = useState(false);
  const [resettingUserId, setResettingUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');

  // New user form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [org, setOrg] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'customer' | 'admin'>('customer');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!name.trim() || !cleanEmail || !password.trim()) {
      setErrorMsg('Name, email, and password are required.');
      return;
    }

    if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      setErrorMsg('A user with this email already exists.');
      return;
    }

    const newUser: User = {
      id: `usr-${Date.now()}`,
      email: cleanEmail,
      name: name.trim(),
      role,
      organization: org.trim() || 'Data Center Operations',
      createdAt: new Date().toISOString(),
      lastLoginAt: 'Never',
      status: 'active',
    };

    const updated = [...users, newUser];
    setUsers(updated);
    saveUsers(updated);

    logActivity({
      userId: currentUser.id,
      userEmail: currentUser.email,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'MANAGE_USER',
      details: `Administrator created user account for ${newUser.name} (${newUser.email}) with role [${newUser.role.toUpperCase()}].`,
      severity: 'info',
    });

    setName('');
    setEmail('');
    setOrg('');
    setPassword('');
    setShowAddForm(false);
    setSuccessMsg(`User "${newUser.name}" created successfully.`);
    onUsersUpdated();
  };

  const handleToggleStatus = (targetUser: User) => {
    if (targetUser.role === 'admin' && targetUser.name === ADMIN_CREDENTIALS.name) {
      setErrorMsg('Root Administrator account cannot be suspended.');
      return;
    }

    const nextStatus: 'active' | 'suspended' = targetUser.status === 'active' ? 'suspended' : 'active';
    const updated: User[] = users.map((u) => (u.id === targetUser.id ? { ...u, status: nextStatus } : u));
    setUsers(updated);
    saveUsers(updated);

    logActivity({
      userId: currentUser.id,
      userEmail: currentUser.email,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'MANAGE_USER',
      details: `User "${targetUser.name}" status changed to [${nextStatus.toUpperCase()}].`,
      severity: nextStatus === 'suspended' ? 'warning' : 'info',
    });

    setSuccessMsg(`User status updated to ${nextStatus}.`);
    onUsersUpdated();
  };

  const handleDeleteUser = (targetUser: User) => {
    if (targetUser.role === 'admin' && targetUser.name === ADMIN_CREDENTIALS.name) {
      setErrorMsg('Cannot delete the primary root administrator account.');
      return;
    }

    if (!confirm(`Are you sure you want to delete user "${targetUser.name}"?`)) return;

    const updated = users.filter((u) => u.id !== targetUser.id);
    setUsers(updated);
    saveUsers(updated);

    logActivity({
      userId: currentUser.id,
      userEmail: currentUser.email,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'MANAGE_USER',
      details: `User account "${targetUser.name}" (${targetUser.email}) was DELETED.`,
      severity: 'critical',
    });

    setSuccessMsg(`User "${targetUser.name}" deleted.`);
    onUsersUpdated();
  };

  const handleSaveResetPassword = (userId: string) => {
    if (!newPassword.trim()) return;

    const targetUser = users.find((u) => u.id === userId);
    if (!targetUser) return;

    logActivity({
      userId: currentUser.id,
      userEmail: currentUser.email,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'MANAGE_USER',
      details: `Administrator performed credential reset for user "${targetUser.name}".`,
      severity: 'warning',
    });

    setResettingUserId(null);
    setNewPassword('');
    setSuccessMsg(`Password successfully reset for "${targetUser.name}".`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 p-5 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center">
                User Management & Access Control
                <span className="ml-2 text-xs font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                  ADMIN ONLY
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Create, audit, toggle authorization, or reset credentials for facility operators and customers
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Notifications */}
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-950/60 border border-red-800 text-red-200 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Top Actions */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400">
              TOTAL USERS: <strong className="text-white">{users.length}</strong> (
              {users.filter((u) => u.role === 'admin').length} Admins,{' '}
              {users.filter((u) => u.role === 'customer').length} Customers)
            </span>
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md shadow-cyan-600/20 transition-all"
            >
              <UserPlus className="w-4 h-4" />
              <span>{showAddForm ? 'Cancel Add User' : 'Add New Operator / Customer'}</span>
            </button>
          </div>

          {/* Add User Drawer */}
          {showAddForm && (
            <form
              onSubmit={handleAddUser}
              className="p-4 rounded-xl bg-slate-950 border border-cyan-800/60 space-y-3"
            >
              <div className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center">
                <UserPlus className="w-3.5 h-3.5 mr-1.5" />
                Provision New Account
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Samuel Green"
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. samuel@datacenter.net"
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Organization</label>
                  <input
                    type="text"
                    value={org}
                    onChange={(e) => setOrg(e.target.value)}
                    placeholder="e.g. Nordic Cloud DC"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Initial Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Role Permission</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  >
                    <option value="customer">Customer (Upload & View Own)</option>
                    <option value="admin">Administrator (Global Access)</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg shadow-sm"
                >
                  Confirm & Provision User
                </button>
              </div>
            </form>
          )}

          {/* Users Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900/90 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Organization</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Last Login</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono">
                  {users.map((u) => {
                    const isRoot = u.role === 'admin' && u.name === ADMIN_CREDENTIALS.name;
                    return (
                      <tr key={u.id} className="hover:bg-slate-900/40 transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-white font-sans">{u.name}</div>
                          <div className="text-[11px] text-slate-400">{u.email}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-300 font-sans">{u.organization || '—'}</td>
                        <td className="py-3 px-4">
                          {u.role === 'admin' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                              ADMIN
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                              CUSTOMER
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {u.status === 'active' ? (
                            <span className="inline-flex items-center text-emerald-400 text-[11px]">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5"></span>
                              Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center text-red-400 text-[11px]">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-400 mr-1.5"></span>
                              Suspended
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-[11px] text-slate-400">
                          {u.lastLoginAt.includes('T')
                            ? new Date(u.lastLoginAt).toLocaleString()
                            : u.lastLoginAt}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end space-x-1.5">
                            {/* Reset Password */}
                            {resettingUserId === u.id ? (
                              <div className="flex items-center space-x-1">
                                <input
                                  type="text"
                                  value={newPassword}
                                  onChange={(e) => setNewPassword(e.target.value)}
                                  placeholder="New password"
                                  className="w-24 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-[10px] text-white"
                                />
                                <button
                                  onClick={() => handleSaveResetPassword(u.id)}
                                  className="p-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px]"
                                >
                                  Save
                                </button>
                                <button
                                  onClick={() => setResettingUserId(null)}
                                  className="p-1 text-slate-400 hover:text-white text-[10px]"
                                >
                                  ✕
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => {
                                  setResettingUserId(u.id);
                                  setNewPassword('');
                                }}
                                className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800"
                                title="Reset User Password"
                              >
                                <KeyRound className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Toggle Suspend/Active */}
                            {!isRoot && (
                              <button
                                onClick={() => handleToggleStatus(u)}
                                className={`p-1.5 rounded-lg border text-xs ${
                                  u.status === 'active'
                                    ? 'bg-amber-950/40 text-amber-300 border-amber-800 hover:bg-amber-900/60'
                                    : 'bg-emerald-950/40 text-emerald-300 border-emerald-800 hover:bg-emerald-900/60'
                                }`}
                                title={u.status === 'active' ? 'Suspend User' : 'Reactivate User'}
                              >
                                {u.status === 'active' ? (
                                  <UserX className="w-3.5 h-3.5" />
                                ) : (
                                  <UserCheck className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}

                            {/* Delete User */}
                            {!isRoot && (
                              <button
                                onClick={() => handleDeleteUser(u)}
                                className="p-1.5 rounded-lg bg-red-950/40 text-red-400 hover:bg-red-900/60 border border-red-800"
                                title="Permanently Delete User"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Close User Hub
          </button>
        </div>
      </div>
    </div>
  );
};
