export type UserRole = 'admin' | 'customer';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt: string;
  lastLoginAt: string;
  status: 'active' | 'suspended';
  organization?: string;
}

export type ActionType =
  | 'LOGIN'
  | 'LOGOUT'
  | 'REGISTER'
  | 'UPLOAD_CSV'
  | 'DETECTION_ALERT'
  | 'APPLY_SOLUTION'
  | 'RESOLVE_ALERT'
  | 'MANAGE_USER'
  | 'EXPORT_REPORT'
  | 'SEND_EMAIL_ALERT';

export interface ActivityLog {
  id: string;
  timestamp: string;
  userId: string;
  userEmail: string;
  userName: string;
  userRole: UserRole;
  actionType: ActionType;
  details: string;
  severity: 'info' | 'warning' | 'critical' | 'success';
  facilityId?: string;
  metadata?: Record<string, string | number | boolean>;
}

export interface TelemetryRecord {
  id: string;
  timestamp: string;
  facility: string;
  rackId: string;
  pue: number; // Power Usage Effectiveness
  wue: number; // Water Usage Effectiveness in L/kWh
  idlePowerPct: number; // Idle server power draw %
  gridThd: number; // Grid Total Harmonic Distortion %
  serverInletTemp: number; // Server Inlet Temp in °C
  tenantId?: string;
  tenantStoragePct?: number; // %
  tenantPowerKw?: number; // kW
  tenantPowerLimitKw?: number; // kW
  tenantTempC?: number; // °C
  tenantBandwidthGbps?: number; // Gbps
  tenantBandwidthLimitGbps?: number; // Gbps
}

export type TroubleCategory =
  | 'PUE_EFFICIENCY'
  | 'WUE_COOLING'
  | 'IDLE_SERVER_POWER'
  | 'GRID_INSTABILITY'
  | 'HVAC_STRESS'
  | 'TENANT_OVERUSE';

export type TroubleSeverity = 'warning' | 'critical';

export interface DetectedTrouble {
  id: string;
  recordId: string;
  datasetId: string;
  timestamp: string;
  facility: string;
  rackOrTenant: string;
  category: TroubleCategory;
  categoryLabel: string;
  metricName: string;
  observedValue: number | string;
  thresholdValue: number | string;
  unit: string;
  severity: TroubleSeverity;
  problemTitle: string;
  problemDescription: string;
  recommendedSolution: string;
  potentialConsequences: string;
  status: 'open' | 'in_progress' | 'resolved';
  resolutionNotes?: string;
  resolvedAt?: string;
  resolvedBy?: string;
  emailStatus?: 'Sent' | 'Pending' | 'Failed';
  emailError?: string;
  emailRecipient?: string;
  emailSentAt?: string;
}

export type EmailDeliveryStatus = 'Sent' | 'Pending' | 'Failed';

export interface BackendNotificationRecord {
  id: string;
  incidentId: string;
  facility: string;
  tenantId?: string;
  customerEmail: string;
  customerName: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  problemTitle: string;
  status: EmailDeliveryStatus;
  provider: 'Resend' | 'SendGrid' | 'None';
  providerMessageId?: string;
  error?: string;
  attempts: number;
  createdAt: string;
  lastAttemptAt: string;
  payload?: any;
}

export interface UploadDataset {
  id: string;
  fileName: string;
  uploadedAt: string;
  uploadedBy: string; // user email
  uploadedByName: string;
  facility: string;
  rowCount: number;
  criticalCount: number;
  warningCount: number;
  healthyCount: number;
  healthScore: number; // 0 - 100
  records: TelemetryRecord[];
  troubles: DetectedTrouble[];
}

export interface EmailNotificationRecord {
  id: string;
  sentAt: string;
  recipientEmail: string;
  facility: string;
  troubleTitle: string;
  severity: TroubleSeverity;
  subject: string;
  bodyPreview: string;
  status: 'sent' | 'delivered';
  troubleId?: string;
}

export interface EmailSettings {
  primaryEmail: string;
  additionalEmails: string; // comma separated
  notifyOnCritical: boolean;
  notifyOnWarning: boolean;
  autoSendOnUpload: boolean;
}
