# Data Center Trouble Detector 🏢⚡

An enterprise-grade data center telemetry monitoring, fault detection, and automated customer alerting web application.

Built for mission-critical infrastructure facilities to detect power inefficiencies, cooling water anomalies, server idle power drain, grid harmonic distortion (THD), and tenant quota overruns.

---

## 🚀 Key Features

### 1. Dual-Role Authentication Portals
- **Admin Operations Portal**:
  - Secure credentials login:
    - **Username**: `Bharathesh Gowda M R`
    - **Password**: `bharath2008`
  - Real-time facility overview with health scores and critical alert tickers.
  - Multi-tab management:
    - **Activity Logs**: Full audit trail of user logins, CSV uploads, resolutions, and system alerts.
    - **System Alerts**: Global trouble board with severity filtering and instant mitigation workflows.
    - **Telemetry Radar**: Live charts for PUE, WUE, Rack Inlet Temp, Grid THD, and Idle Power Draw.
    - **Tenant Management**: User status controls and quota thresholds.
    - **Customer Email Notifications**: Centralized delivery ledger with status badges, auto-retry mechanisms, and provider metrics.
- **Customer / Tenant Self-Service Portal**:
  - Email + Password registration and authenticated sign-in.
  - Pre-configured enterprise tenant profiles (Acme-AI, Fintech-Core, BioGenomics, StreamMedia, etc.).
  - CSV telemetry ingestion with instant client-side analysis against engineering thresholds.
  - Individual problem cards with:
    - Problem description & breach metrics.
    - Recommended corrective actions.
    - Potential consequences if unaddressed.
    - Live **Email Notification Status** badge (`Sent`, `Pending`, or `Failed`).

### 2. Engineering Anomaly Detection Thresholds
| Parameter | Optimal / Baseline | Warning Threshold | Critical Threshold |
| :--- | :--- | :--- | :--- |
| **PUE (Power Usage Effectiveness)** | < 1.4 | > 1.5 | > 1.8 |
| **WUE (Water Usage Effectiveness)** | < 1.2 L/kWh | > 1.5 L/kWh | > 2.5 L/kWh |
| **Idle Server Power Draw** | < 25% | > 40% | > 60% |
| **Grid THD (Harmonic Distortion)** | < 3% | > 5% | > 10% |
| **Rack Inlet Temperature** | 18°C – 24°C | > 27°C | > 32°C |
| **Tenant Quotas** | Contract limits | > 85% storage / power | > 95% storage / over-limit power |

### 3. Automated Customer Email Notifications
- Automatically sends notifications upon CSV upload when an anomaly is detected.
- Secure server-side dispatch using **Resend** or **SendGrid** via `/api/email/notify`.
- **Zero Duplication**: Idempotency tracking prevents spamming customers for the same incident.
- **Safe Retries**: Transient failures can be retried directly from the UI or via API.
- Customer verified email resolution using tenant directories or session identity.
- Explicit safety guard: Infrastructure changes are never executed automatically without human approval.

### 4. Supabase Cloud Integration
- Integrated SQL schema for storing telemetry records, activity logs, user profiles, and incident histories.
- Run `supabase_schema.sql` in your Supabase SQL Editor for instant cloud persistence.

---

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Motion.
- **Backend**: Node.js, Express, tsx.
- **Email Service**: Resend API / SendGrid API (server-side environment variable driven).
- **Database**: Supabase PostgreSQL (optional) & resilient disk-backed local storage.
- **AI Assist**: Google Gemini 2.5 Flash via `@google/genai` (optional for deeper root-cause analysis).

---

## 📦 Getting Started & Local Installation

### Prerequisites
- Node.js 18+ or 20+
- npm or bun

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/data-center-trouble-detector.git
cd data-center-trouble-detector
```

### 2. Install dependencies
```bash
npm install
```

### 3. Setup Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Update `.env` with your desired configuration:
```env
PORT=3000
EMAIL_PROVIDER=resend
RESEND_API_KEY=re_your_api_key_here
EMAIL_FROM="Data Center Alerts <alerts@yourdatacenter.net>"
```

### 4. Run Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:3000`.

### 5. Build for Production
```bash
npm run build
npm start
```

---

## 📁 Repository Structure

```
├── server.ts                  # Express server & email notification API
├── supabase_schema.sql        # Supabase PostgreSQL tables & security policies
├── package.json               # Node dependencies and scripts
├── vite.config.ts             # Vite configuration with Tailwind v4
├── src/
│   ├── App.tsx                # Main application component & routing
│   ├── main.tsx               # React entry point
│   ├── index.css              # Tailwind imports
│   ├── types/
│   │   └── index.ts           # TypeScript interfaces (Telemetry, Trouble, User, Logs)
│   ├── utils/
│   │   ├── csvParser.ts       # CSV parser and sample generator
│   │   ├── detectionEngine.ts # Rule-based threshold detection engine
│   │   ├── emailService.ts    # Frontend email notification service
│   │   ├── storage.ts         # LocalStorage persistence & logger
│   │   └── supabaseClient.ts  # Supabase client wrapper
│   └── components/
│       ├── AdminDashboard.tsx           # Admin multi-tab dashboard
│       ├── CustomerDashboard.tsx        # Customer self-service dashboard
│       ├── AuthPortal.tsx               # Dual login & registration modal
│       ├── ActionModal.tsx              # Incident details & mitigation modal
│       ├── EmailAlertModal.tsx          # Manual email composer dialog
│       ├── EmailSettingsModal.tsx       # Email settings configuration
│       ├── Navbar.tsx                   # Top navigation bar
│       ├── SupabaseModal.tsx            # Supabase config dialog
│       ├── TelemetryCharts.tsx          # Real-time telemetry visualization
│       ├── ThresholdReferenceModal.tsx  # Engineering threshold reference
│       └── UserManagementModal.tsx      # Admin user management
```

---

## 🛡️ License
Apache-2.0
