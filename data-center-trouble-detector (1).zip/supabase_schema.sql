-- ============================================================
-- DATA CENTER TROUBLE DETECTOR - SUPABASE SCHEMA SETUP
-- Project ID: ctyxrwzmugfgvjxqwpzv
-- Paste and run this script in the Supabase SQL Editor:
-- https://supabase.com/dashboard/project/ctyxrwzmugfgvjxqwpzv/sql
-- ============================================================

-- 1. Users Table
CREATE TABLE IF NOT EXISTS public.dc_users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'customer',
    organization TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_login_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Activity Logs Table (Admin Auditing)
CREATE TABLE IF NOT EXISTS public.dc_activity_logs (
    id TEXT PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    user_id TEXT NOT NULL,
    user_email TEXT NOT NULL,
    user_name TEXT NOT NULL,
    user_role TEXT NOT NULL,
    action_type TEXT NOT NULL,
    details TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info',
    facility_id TEXT,
    metadata JSONB
);

-- 3. Telemetry Datasets & Analyzed Troubles Table
CREATE TABLE IF NOT EXISTS public.dc_datasets (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    uploaded_at TIMESTAMPTZ DEFAULT NOW(),
    uploaded_by TEXT NOT NULL,
    uploaded_by_name TEXT NOT NULL,
    facility TEXT NOT NULL,
    row_count INTEGER NOT NULL DEFAULT 0,
    critical_count INTEGER NOT NULL DEFAULT 0,
    warning_count INTEGER NOT NULL DEFAULT 0,
    healthy_count INTEGER NOT NULL DEFAULT 0,
    health_score INTEGER NOT NULL DEFAULT 100,
    records JSONB NOT NULL DEFAULT '[]'::jsonb,
    troubles JSONB NOT NULL DEFAULT '[]'::jsonb
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.dc_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dc_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dc_datasets ENABLE ROW LEVEL SECURITY;

-- Allow public / anon read and write for this application
CREATE POLICY "Public Read dc_users" ON public.dc_users FOR SELECT USING (true);
CREATE POLICY "Public Insert dc_users" ON public.dc_users FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Update dc_users" ON public.dc_users FOR UPDATE USING (true);

CREATE POLICY "Public Read dc_activity_logs" ON public.dc_activity_logs FOR SELECT USING (true);
CREATE POLICY "Public Insert dc_activity_logs" ON public.dc_activity_logs FOR INSERT WITH CHECK (true);

CREATE POLICY "Public Read dc_datasets" ON public.dc_datasets FOR SELECT USING (true);
CREATE POLICY "Public Insert dc_datasets" ON public.dc_datasets FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Update dc_datasets" ON public.dc_datasets FOR UPDATE USING (true);
CREATE POLICY "Public Delete dc_datasets" ON public.dc_datasets FOR DELETE USING (true);

-- Seed Administrator User
INSERT INTO public.dc_users (id, email, name, role, organization, status, created_at)
VALUES (
    'usr-admin-bharathesh',
    'bharathesh.admin@datacenter.gov',
    'Bharathesh Gowda M R',
    'admin',
    'Global Command Center',
    'active',
    NOW()
)
ON CONFLICT (email) DO NOTHING;
