import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// -------------------------------------------------------------
// Tenant to Customer Email Mapping Directory
// -------------------------------------------------------------
const TENANT_CUSTOMER_DIRECTORY: Record<string, { email: string; name: string; org: string }> = {
  'Acme-AI': { email: 'acme-ops@acmecorp.com', name: 'Acme AI Systems', org: 'Acme Artificial Intelligence' },
  'Fintech-Core': { email: 'infra@fintechcore.io', name: 'Fintech Core Ops', org: 'Fintech Core Financial' },
  'StreamMedia': { email: 'ops@streammedia.cloud', name: 'StreamMedia CDN', org: 'StreamMedia Networks' },
  'GovCloud-Sec': { email: 'security-ops@govcloud.gov', name: 'GovCloud Security', org: 'GovCloud Federal Services' },
  'BioGenomics': { email: 'lab-infra@biogenomics.org', name: 'BioGenomics Lab', org: 'BioGenomics Research Institute' },
  'HPC-Quantum': { email: 'quantum-lab@apexcomputing.com', name: 'Quantum HPC Lab', org: 'Apex Computing' },
  'DevCluster': { email: 'devops@hyperscale.io', name: 'DevCluster Cloud', org: 'DevCluster Systems' },
  'LogiTrans': { email: 'telemetry@logitrans.eu', name: 'LogiTrans Edge', org: 'LogiTrans Logistics' },
  'UrbanSmart': { email: 'smartgrid@urbansmart.de', name: 'UrbanSmart Grid', org: 'UrbanSmart Infrastructure' },
  'AutonomousDrive': { email: 'av-fleet@autonomousdrive.tech', name: 'AV Fleet Systems', org: 'Autonomous Drive Inc' },
  'GlobalBanking': { email: 'core-systems@globalbanking.is', name: 'Global Banking Corp', org: 'Global Banking Nordic' },
  'HealthCloud': { email: 'hipaa-cluster@healthcloud.org', name: 'HealthCloud HealthTech', org: 'HealthCloud HIPAA Systems' },
  'ResearchAI': { email: 'hpc-cluster@researchai.is', name: 'Nordic Research AI', org: 'Nordic Research AI' },
};

export interface IncidentNotificationPayload {
  incidentId: string;
  troubleId?: string;
  datasetId?: string;
  facility: string;
  rackOrTenant: string;
  tenantId?: string;
  category: string;
  categoryLabel?: string;
  metricName: string;
  observedValue: number | string;
  thresholdValue: number | string;
  unit: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  problemTitle: string;
  problemDescription: string;
  potentialConsequences: string;
  recommendedSolution: string;
  timestamp: string;
  customerEmail?: string;
  customerName?: string;
}

export interface StoredNotification {
  id: string;
  incidentId: string;
  facility: string;
  tenantId?: string;
  customerEmail: string;
  customerName: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  problemTitle: string;
  status: 'Sent' | 'Pending' | 'Failed';
  provider: 'Resend' | 'SendGrid' | 'None';
  providerMessageId?: string;
  error?: string;
  attempts: number;
  createdAt: string;
  lastAttemptAt: string;
  payload: IncidentNotificationPayload;
}

// In-memory notifications store backed by a local json file for resilience
const STORAGE_FILE = path.join(__dirname, '.email_notifications_store.json');
let notificationsStore: Map<string, StoredNotification> = new Map();

function loadNotificationsFromDisk() {
  try {
    if (fs.existsSync(STORAGE_FILE)) {
      const data = JSON.parse(fs.readFileSync(STORAGE_FILE, 'utf-8'));
      if (Array.isArray(data)) {
        notificationsStore = new Map(data.map((item: StoredNotification) => [item.incidentId, item]));
      }
    }
  } catch (err) {
    console.warn('[Storage] Could not load notifications from disk:', err);
  }
}

function persistNotificationsToDisk() {
  try {
    const list = Array.from(notificationsStore.values());
    fs.writeFileSync(STORAGE_FILE, JSON.stringify(list, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[Storage] Could not persist notifications to disk:', err);
  }
}

loadNotificationsFromDisk();

/**
 * Resolves verified customer email from tenant ID or customer directory
 */
function resolveCustomerEmail(payload: IncidentNotificationPayload): { email: string; name: string } {
  // 1. Direct tenant match
  if (payload.tenantId && TENANT_CUSTOMER_DIRECTORY[payload.tenantId]) {
    return {
      email: TENANT_CUSTOMER_DIRECTORY[payload.tenantId].email,
      name: TENANT_CUSTOMER_DIRECTORY[payload.tenantId].name,
    };
  }

  // 2. Check if rackOrTenant matches a known tenant key
  if (payload.rackOrTenant) {
    const clean = payload.rackOrTenant.replace(/^Tenant:\s*/i, '').trim();
    if (TENANT_CUSTOMER_DIRECTORY[clean]) {
      return {
        email: TENANT_CUSTOMER_DIRECTORY[clean].email,
        name: TENANT_CUSTOMER_DIRECTORY[clean].name,
      };
    }
  }

  // 3. Fallback to customerEmail passed from the verified login session
  if (payload.customerEmail && payload.customerEmail.includes('@')) {
    return {
      email: payload.customerEmail,
      name: payload.customerName || 'Data Center Customer',
    };
  }

  // 4. Default fallback to system primary operator
  return {
    email: 'operator@datacenter.net',
    name: 'Authorized Operations Team',
  };
}

/**
 * Normalizes severity into Critical, High, Medium, or Low
 */
function normalizeSeverityLevel(raw: string, observed?: number | string, threshold?: number | string): 'Critical' | 'High' | 'Medium' | 'Low' {
  const s = (raw || '').toLowerCase();
  if (s === 'critical') return 'Critical';
  if (s === 'high') return 'High';
  if (s === 'medium') return 'Medium';
  if (s === 'low') return 'Low';

  if (s === 'warning') {
    // If numerical value significantly exceeds threshold, treat as High, otherwise Medium
    if (typeof observed === 'number' && typeof threshold === 'number' && threshold > 0) {
      if (observed >= threshold * 1.25) return 'High';
    }
    return 'High';
  }

  return 'Medium';
}

/**
 * Generates formatted HTML email body adhering to all requirements
 */
function buildEmailHtml(payload: IncidentNotificationPayload, customerName: string): string {
  const severityColors = {
    Critical: { bg: '#7f1d1d', text: '#fecaca', border: '#ef4444' },
    High: { bg: '#78350f', text: '#fef08a', border: '#f59e0b' },
    Medium: { bg: '#1e3a8a', text: '#bfdbfe', border: '#3b82f6' },
    Low: { bg: '#14532d', text: '#bbf7d0', border: '#22c55e' },
  };

  const colors = severityColors[payload.severity] || severityColors.High;

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${payload.problemTitle}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #0b0f19; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f1f5f9;">
  <div style="max-width: 650px; margin: 24px auto; background-color: #0f172a; border-radius: 16px; border: 1px solid #1e293b; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
    
    <!-- Top Brand & Severity Header -->
    <div style="background-color: #020617; padding: 18px 24px; border-bottom: 1px solid #1e293b; display: flex; align-items: center; justify-content: space-between;">
      <div>
        <span style="font-size: 13px; font-weight: 800; color: #38bdf8; letter-spacing: 0.1em; text-transform: uppercase;">DATA CENTER TROUBLE DETECTOR</span>
        <div style="font-size: 11px; color: #94a3b8; font-family: monospace; margin-top: 2px;">AUTOMATIC CUSTOMER ANOMALY NOTIFICATION</div>
      </div>
      <div style="background-color: ${colors.bg}; color: ${colors.text}; border: 1px solid ${colors.border}; padding: 4px 12px; border-radius: 6px; font-size: 11px; font-weight: 800; font-family: monospace; text-transform: uppercase;">
        SEVERITY: ${payload.severity}
      </div>
    </div>

    <!-- Incident Summary Banner -->
    <div style="padding: 24px; border-bottom: 1px solid #1e293b; background: linear-gradient(180deg, rgba(15,23,42,0.9) 0%, rgba(2,6,23,0.95) 100%);">
      <div style="font-size: 12px; color: #94a3b8; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
        ATTN: <strong style="color: #ffffff;">${customerName}</strong> • FACILITY: <strong style="color: #38bdf8;">${payload.facility}</strong>
      </div>
      <h1 style="margin: 0 0 10px 0; font-size: 20px; font-weight: 800; color: #ffffff; line-height: 1.3;">
        ${payload.problemTitle}
      </h1>
      <p style="margin: 0; font-size: 13px; color: #cbd5e1; line-height: 1.6;">
        An automated telemetry anomaly has been detected affecting your infrastructure allocation. Please review the diagnostic details and recommended corrective steps below.
      </p>
    </div>

    <div style="padding: 24px;">
      <!-- Incident & Metric Identification Table -->
      <table style="width: 100%; border-collapse: separate; border-spacing: 0; margin-bottom: 20px; border: 1px solid #1e293b; border-radius: 12px; overflow: hidden; background-color: #020617;">
        <tr style="border-bottom: 1px solid #1e293b;">
          <td style="padding: 12px 16px; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase; width: 40%; border-bottom: 1px solid #1e293b;">Unique Incident ID</td>
          <td style="padding: 12px 16px; font-size: 12px; font-weight: 700; color: #38bdf8; font-family: monospace; border-bottom: 1px solid #1e293b;">${payload.incidentId}</td>
        </tr>
        <tr>
          <td style="padding: 12px 16px; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase; border-bottom: 1px solid #1e293b;">Data-Centre & Tenant / Rack</td>
          <td style="padding: 12px 16px; font-size: 12px; font-weight: 600; color: #f1f5f9; border-bottom: 1px solid #1e293b;">${payload.facility} (${payload.rackOrTenant})</td>
        </tr>
        <tr>
          <td style="padding: 12px 16px; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase; border-bottom: 1px solid #1e293b;">Affected Metric</td>
          <td style="padding: 12px 16px; font-size: 12px; font-weight: 600; color: #f1f5f9; border-bottom: 1px solid #1e293b;">${payload.metricName}</td>
        </tr>
        <tr>
          <td style="padding: 12px 16px; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase; border-bottom: 1px solid #1e293b;">Detected Value vs Threshold</td>
          <td style="padding: 12px 16px; font-size: 13px; font-family: monospace; border-bottom: 1px solid #1e293b;">
            <strong style="color: ${colors.border};">${payload.observedValue} ${payload.unit}</strong> 
            <span style="color: #64748b;">(Expected: &le; ${payload.thresholdValue} ${payload.unit})</span>
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 16px; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase;">Detection Timestamp</td>
          <td style="padding: 12px 16px; font-size: 11px; color: #94a3b8; font-family: monospace;">${payload.timestamp}</td>
        </tr>
      </table>

      <!-- Detailed Description -->
      <div style="background-color: #020617; border: 1px solid #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 700; color: #94a3b8; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
          Detailed Anomaly Description
        </div>
        <div style="font-size: 13px; color: #e2e8f0; line-height: 1.6;">
          ${payload.problemDescription}
        </div>
      </div>

      <!-- AI-Generated Recommended Solution & Corrective Steps -->
      <div style="background-color: rgba(6, 182, 212, 0.08); border: 1px solid rgba(6, 182, 212, 0.35); border-radius: 12px; padding: 18px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 700; color: #38bdf8; font-family: monospace; text-transform: uppercase; margin-bottom: 8px;">
          ⚡ AI-Recommended Solution & Suggested Corrective Steps
        </div>
        <div style="font-size: 13px; color: #e0f2fe; line-height: 1.7; white-space: pre-line;">
          ${payload.recommendedSolution}
        </div>
      </div>

      <!-- Potential Consequences -->
      <div style="background-color: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 20px;">
        <div style="font-size: 11px; font-weight: 700; color: #f87171; font-family: monospace; text-transform: uppercase; margin-bottom: 6px;">
          ⚠️ Potential Consequences if Unresolved
        </div>
        <div style="font-size: 13px; color: #fecaca; line-height: 1.6;">
          ${payload.potentialConsequences}
        </div>
      </div>

      <!-- Safety Notice: Requirement 8 -->
      <div style="background-color: #020617; border-left: 3px solid #38bdf8; padding: 12px 16px; border-radius: 0 8px 8px 0; font-size: 11px; color: #94a3b8; line-height: 1.5;">
        <strong style="color: #e2e8f0;">Operational Notice:</strong> In accordance with safety policies, suggested infrastructure changes are <strong>not executed automatically</strong>. Please review these steps with your infrastructure engineering team.
      </div>
    </div>

    <!-- Footer -->
    <div style="background-color: #020617; border-top: 1px solid #1e293b; padding: 16px 24px; text-align: center; font-size: 11px; color: #64748b;">
      <div>Data Center Trouble Detector • Automated Operations Gateway</div>
      <div style="color: #475569; margin-top: 4px;">Incident Reference ID: ${payload.incidentId}</div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Dispatch email via Resend API
 */
async function sendViaResend(apiKey: string, toEmail: string, subject: string, html: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const fromAddress = process.env.RESEND_FROM || process.env.EMAIL_FROM || 'Data Center Trouble Detector <onboarding@resend.dev>';
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [toEmail],
        subject,
        html,
      }),
    });

    const data = await response.json();
    if (response.ok && data?.id) {
      return { success: true, messageId: data.id };
    } else {
      const errMsg = data?.message || data?.error || `Resend returned HTTP ${response.status}`;
      return { success: false, error: errMsg };
    }
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed connecting to Resend API' };
  }
}

/**
 * Dispatch email via SendGrid API
 */
async function sendViaSendGrid(apiKey: string, toEmail: string, subject: string, html: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const fromAddress = process.env.SENDGRID_FROM || process.env.EMAIL_FROM || 'alerts@datacenter-detector.com';
    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: toEmail }] }],
        from: { email: fromAddress, name: 'Data Center Trouble Detector' },
        subject,
        content: [{ type: 'text/html', value: html }],
      }),
    });

    if (response.status === 200 || response.status === 202) {
      const messageId = response.headers.get('x-message-id') || `sg-${Date.now()}`;
      return { success: true, messageId };
    } else {
      let errText = '';
      try {
        const errJson = await response.json();
        errText = JSON.stringify(errJson);
      } catch {
        errText = await response.text();
      }
      return { success: false, error: errText || `SendGrid returned HTTP ${response.status}` };
    }
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed connecting to SendGrid API' };
  }
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// 1. Provider configuration status (Never exposes secrets to frontend!)
app.get('/api/email/config', (req: Request, res: Response) => {
  const hasResend = !!process.env.RESEND_API_KEY;
  const hasSendGrid = !!process.env.SENDGRID_API_KEY;

  res.json({
    configured: hasResend || hasSendGrid,
    provider: hasResend ? 'resend' : hasSendGrid ? 'sendgrid' : 'none',
    providerName: hasResend ? 'Resend' : hasSendGrid ? 'SendGrid' : 'None Configured',
    fromAddress: process.env.RESEND_FROM || process.env.SENDGRID_FROM || process.env.EMAIL_FROM || null,
  });
});

// 2. Email notification history for administrators
app.get('/api/email/history', (req: Request, res: Response) => {
  const list = Array.from(notificationsStore.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  res.json({ notifications: list });
});

// 3. Status for a specific incident
app.get('/api/email/status/:incidentId', (req: Request, res: Response) => {
  const incidentId = req.params.incidentId;
  const record = notificationsStore.get(incidentId);
  if (!record) {
    return res.json({ found: false, status: 'Pending' });
  }
  return res.json({ found: true, ...record });
});

// 4. Batch query status for multiple incidents
app.post('/api/email/status-batch', (req: Request, res: Response) => {
  const { incidentIds } = req.body;
  if (!Array.isArray(incidentIds)) {
    return res.status(400).json({ error: 'incidentIds must be an array' });
  }

  const result: Record<string, { status: 'Sent' | 'Pending' | 'Failed'; error?: string; attempts: number; customerEmail: string }> = {};
  for (const id of incidentIds) {
    const item = notificationsStore.get(id);
    if (item) {
      result[id] = {
        status: item.status,
        error: item.error,
        attempts: item.attempts,
        customerEmail: item.customerEmail,
      };
    } else {
      result[id] = {
        status: 'Pending',
        attempts: 0,
        customerEmail: '',
      };
    }
  }

  res.json({ statuses: result });
});

// 5. Automatic Anomaly Email Dispatch Handler
app.post('/api/email/notify', async (req: Request, res: Response) => {
  const payload: IncidentNotificationPayload = req.body;

  if (!payload || !payload.incidentId || !payload.problemTitle) {
    return res.status(400).json({ error: 'Missing required incident notification fields.' });
  }

  const incidentId = payload.incidentId;

  // Requirement 5: Prevent duplicate emails for the same incident
  const existing = notificationsStore.get(incidentId);
  if (existing && existing.status === 'Sent') {
    return res.json({
      success: true,
      duplicate: true,
      status: 'Sent',
      message: 'Email notification has already been sent for this incident.',
      record: existing,
    });
  }

  // Requirement 2: Automatically identify the correct customer's verified email address
  const recipient = resolveCustomerEmail(payload);
  payload.customerEmail = recipient.email;
  payload.customerName = recipient.name;

  // Normalize severity
  payload.severity = normalizeSeverityLevel(payload.severity, payload.observedValue, payload.thresholdValue);

  const subject = `[${payload.severity.toUpperCase()} ALERT] ${payload.facility}: ${payload.problemTitle}`;
  const htmlBody = buildEmailHtml(payload, recipient.name);

  const resendKey = process.env.RESEND_API_KEY;
  const sendgridKey = process.env.SENDGRID_API_KEY;

  let stored: StoredNotification = existing || {
    id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    incidentId,
    facility: payload.facility,
    tenantId: payload.tenantId,
    customerEmail: recipient.email,
    customerName: recipient.name,
    severity: payload.severity,
    problemTitle: payload.problemTitle,
    status: 'Pending',
    provider: resendKey ? 'Resend' : sendgridKey ? 'SendGrid' : 'None',
    attempts: 0,
    createdAt: new Date().toISOString(),
    lastAttemptAt: new Date().toISOString(),
    payload,
  };

  stored.attempts += 1;
  stored.lastAttemptAt = new Date().toISOString();

  // CRITICAL REQUIREMENT: "Do not simulate successful email delivery when no email provider is configured."
  if (!resendKey && !sendgridKey) {
    stored.status = 'Failed';
    stored.provider = 'None';
    stored.error = 'No email provider configured. Please set RESEND_API_KEY or SENDGRID_API_KEY in server environment variables.';

    notificationsStore.set(incidentId, stored);
    persistNotificationsToDisk();

    return res.status(200).json({
      success: false,
      status: 'Failed',
      error: stored.error,
      customerEmail: recipient.email,
      record: stored,
    });
  }

  // Execute delivery via configured provider
  let dispatchResult: { success: boolean; messageId?: string; error?: string } = { success: false };

  if (resendKey) {
    dispatchResult = await sendViaResend(resendKey, recipient.email, subject, htmlBody);
    stored.provider = 'Resend';
  } else if (sendgridKey) {
    dispatchResult = await sendViaSendGrid(sendgridKey, recipient.email, subject, htmlBody);
    stored.provider = 'SendGrid';
  }

  if (dispatchResult.success) {
    stored.status = 'Sent';
    stored.providerMessageId = dispatchResult.messageId;
    stored.error = undefined;
  } else {
    stored.status = 'Failed';
    stored.error = dispatchResult.error || 'Provider rejected email transmission.';
  }

  notificationsStore.set(incidentId, stored);
  persistNotificationsToDisk();

  return res.json({
    success: dispatchResult.success,
    status: stored.status,
    customerEmail: recipient.email,
    customerName: recipient.name,
    error: stored.error,
    record: stored,
  });
});

// 6. Safe Retry Endpoint (Requirement 5)
app.post('/api/email/retry', async (req: Request, res: Response) => {
  const { incidentId } = req.body;

  if (!incidentId) {
    return res.status(400).json({ error: 'incidentId is required to retry notification.' });
  }

  const existing = notificationsStore.get(incidentId);
  if (!existing) {
    return res.status(404).json({ error: `Incident ${incidentId} not found in notification registry.` });
  }

  if (existing.status === 'Sent') {
    return res.json({
      success: true,
      duplicate: true,
      status: 'Sent',
      message: 'This incident was already delivered successfully.',
      record: existing,
    });
  }

  // Re-run dispatch with stored payload
  const payload = existing.payload;
  const resendKey = process.env.RESEND_API_KEY;
  const sendgridKey = process.env.SENDGRID_API_KEY;

  existing.attempts += 1;
  existing.lastAttemptAt = new Date().toISOString();

  if (!resendKey && !sendgridKey) {
    existing.status = 'Failed';
    existing.error = 'No email provider configured. Please set RESEND_API_KEY or SENDGRID_API_KEY in server environment variables.';
    notificationsStore.set(incidentId, existing);
    persistNotificationsToDisk();

    return res.status(200).json({
      success: false,
      status: 'Failed',
      error: existing.error,
      record: existing,
    });
  }

  const subject = `[${payload.severity.toUpperCase()} ALERT] ${payload.facility}: ${payload.problemTitle}`;
  const htmlBody = buildEmailHtml(payload, existing.customerName);

  let dispatchResult: { success: boolean; messageId?: string; error?: string } = { success: false };
  if (resendKey) {
    dispatchResult = await sendViaResend(resendKey, existing.customerEmail, subject, htmlBody);
    existing.provider = 'Resend';
  } else if (sendgridKey) {
    dispatchResult = await sendViaSendGrid(sendgridKey, existing.customerEmail, subject, htmlBody);
    existing.provider = 'SendGrid';
  }

  if (dispatchResult.success) {
    existing.status = 'Sent';
    existing.providerMessageId = dispatchResult.messageId;
    existing.error = undefined;
  } else {
    existing.status = 'Failed';
    existing.error = dispatchResult.error || 'Provider rejected email transmission.';
  }

  notificationsStore.set(incidentId, existing);
  persistNotificationsToDisk();

  return res.json({
    success: dispatchResult.success,
    status: existing.status,
    customerEmail: existing.customerEmail,
    error: existing.error,
    record: existing,
  });
});

// -------------------------------------------------------------
// Source Code Zip Download for GitHub Export
// -------------------------------------------------------------
app.get('/api/download-source', (req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'data-center-trouble-detector.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="data-center-trouble-detector.zip"');
    const stream = fs.createReadStream(zipPath);
    return stream.pipe(res);
  } else {
    return res.status(404).json({ error: 'Source archive not found. Please regenerate.' });
  }
});

// Also support direct .zip path
app.get('/data-center-trouble-detector.zip', (req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'data-center-trouble-detector.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="data-center-trouble-detector.zip"');
    return fs.createReadStream(zipPath).pipe(res);
  } else {
    return res.status(404).json({ error: 'Source archive not found.' });
  }
});

// -------------------------------------------------------------
// Vite Middlewares in Dev / Static dist in Prod
// -------------------------------------------------------------
async function setupServer() {
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(__dirname, 'dist'))) {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[Data Center Trouble Detector Server] Running on http://0.0.0.0:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error('[Server Setup Error]', err);
});
